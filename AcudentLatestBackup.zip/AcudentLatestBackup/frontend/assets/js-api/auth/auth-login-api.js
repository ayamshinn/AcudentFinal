document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#adminLoginForm"); // Select the form inside signIn
    if (!loginForm) return;

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = document.getElementById("login-email").value.trim(); // Changed variable name
        const password = document.getElementById("login-password").value.trim();

        // Create error message element if it doesn't exist
        let errorMsg = document.querySelector(".error-msg");
        if (!errorMsg) {
            errorMsg = document.createElement("div");
            errorMsg.className = "error-msg";
            errorMsg.style.color = "red";
            errorMsg.style.marginTop = "10px";
            loginForm.querySelector(".log-in-container").prepend(errorMsg);
        }

        if (!username || !password) {
            errorMsg.textContent = "Please enter username and password."; // Updated message
            return;
        }

        try {
            const response = await fetch("/Acudent/backend/api/auth/auth-login.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password }) // Changed from 'email' to 'username'
            });

            const result = await response.json();

            if (!result.success) {
                errorMsg.textContent = result.message || "Invalid login.";
                return;
            }

            if (result.token) {
                localStorage.setItem("authToken", result.token);
            }

            window.location.href = result.redirect;

        } catch (err) {
            console.error(err);
            errorMsg.textContent = "Error connecting to server.";
        }
    });
});


document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#adminLoginForm");
    if (!loginForm) return;

    // Create error container
    let errorMsg = document.querySelector(".error-msg");
    if (!errorMsg) {
        errorMsg = document.createElement("div");
        errorMsg.className = "error-msg";
        errorMsg.style.cssText = `
            color: #dc3545;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
            padding: 12px 15px;
            margin: 15px 0;
            display: none;
        `;
        loginForm.querySelector(".log-in-container").prepend(errorMsg);
    }

    // Create success container
    let successMsg = document.querySelector(".success-msg");
    if (!successMsg) {
        successMsg = document.createElement("div");
        successMsg.className = "success-msg";
        successMsg.style.cssText = `
            color: #155724;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            padding: 12px 15px;
            margin: 15px 0;
            display: none;
        `;
        loginForm.querySelector(".log-in-container").prepend(successMsg);
    }

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = document.getElementById("login-email").value.trim();
        const password = document.getElementById("login-password").value.trim();

        // Hide all messages
        errorMsg.style.display = "none";
        successMsg.style.display = "none";

        if (!username || !password) {
            errorMsg.innerHTML = "<strong><i class='fa-solid fa-exclamation-triangle'></i> Required Fields:</strong> Please enter both username and password.";
            errorMsg.style.display = "block";
            return;
        }

        try {
            const response = await fetch("/Acudent/backend/api/auth/auth-login.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (!result.success) {
                errorMsg.innerHTML = `<strong><i class='fa-solid fa-times-circle'></i> Authentication Failed:</strong> ${result.message || "Invalid username or password."}`;
                errorMsg.style.display = "block";
                errorMsg.scrollIntoView({ behavior: "smooth", block: "center" });
                return;
            }

            // Success
            successMsg.innerHTML = "<strong><i class='fa-solid fa-check-circle'></i> Login Successful!</strong> Redirecting...";
            successMsg.style.display = "block";

            if (result.token) {
                localStorage.setItem("authToken", result.token);
            }

            setTimeout(() => {
                window.location.href = result.redirect;
            }, 1000);

        } catch (err) {
            console.error(err);
            errorMsg.innerHTML = "<strong><i class='fa-solid fa-exclamation-circle'></i> Server Error:</strong> Unable to connect to the server. Please check your internet connection and try again.";
            errorMsg.style.display = "block";
            errorMsg.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    });
});