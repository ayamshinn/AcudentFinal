// ===================== DENTIST ACCOUNT REGISTRATION API =====================
// Handles ONLY: Account creation API call

(function() {
    'use strict';
    
    if (window.dentistAccountAPIInitialized) {
        return;
    }
    window.dentistAccountAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const ACCOUNT_API_ENDPOINT = "/Acudent/backend/api/register/register-user-dentist.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== CREATE ACCOUNT FUNCTION WITH IMAGE ====================
    /**
     * Creates a dentist user account with profile picture
     * @param {FormData} formData - FormData containing account info and profile_picture file
     * @returns {Promise<Object>} - { success, message, dentist: { user_id, ... } }
     */
    window.createDentistAccountWithImage = async function(formData) {
        try {
            if (DEBUG_MODE) console.log('📤 Creating dentist account with image');
            
            const response = await fetch(ACCOUNT_API_ENDPOINT, {
                method: "POST",
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create account");
            }

            if (DEBUG_MODE) console.log('✅ Account created successfully');
            return result;

        } catch (error) {
            console.error("Account creation failed:", error.message);
            throw error;
        }
    };

    // ==================== CREATE ACCOUNT FUNCTION (BACKWARD COMPATIBILITY) ====================
    /**
     * Creates a dentist user account (JSON version for backward compatibility)
     * @param {Object} accountData - { first_name, last_name, login_email, contact_email, password }
     * @returns {Promise<Object>} - { success, message, dentist: { user_id, ... } }
     */
    window.createDentistAccount = async function(accountData) {
        try {
            if (DEBUG_MODE) console.log('📤 Creating dentist account (JSON)');
            
            const response = await fetch(ACCOUNT_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(accountData)
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create account");
            }

            if (DEBUG_MODE) console.log('✅ Account created successfully');
            return result;

        } catch (error) {
            console.error("Account creation failed:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates account data before submission
     * @param {Object} data - Account data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAccountData = function(data) {
        const errors = [];

        if (!data.first_name || data.first_name.trim() === '') {
            errors.push("First name is required");
        }
        
        if (!data.last_name || data.last_name.trim() === '') {
            errors.push("Last name is required");
        }
        
        if (!data.login_email || data.login_email.trim() === '') {
            errors.push("Login email is required");
        }
        
        if (!data.contact_email || data.contact_email.trim() === '') {
            errors.push("Contact email is required");
        }
        
        if (!data.password || data.password.trim() === '') {
            errors.push("Password is required");
        }

        // Email format validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (data.login_email && !emailRegex.test(data.login_email)) {
            errors.push("Invalid login email format");
        }
        
        if (data.contact_email && !emailRegex.test(data.contact_email)) {
            errors.push("Invalid contact email format");
        }

        // Password validation
        if (data.password && data.password.length < 8) {
            errors.push("Password must be at least 8 characters");
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    if (DEBUG_MODE) console.log('✅ Dentist Account API loaded');

})();