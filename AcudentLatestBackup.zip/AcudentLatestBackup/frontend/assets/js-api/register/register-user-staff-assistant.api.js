// ===================== ASSISTANT ACCOUNT REGISTRATION API =====================
// Handles ONLY: Account creation API call with profile picture support

(function() {
    'use strict';
    
    if (window.assistantAccountAPIInitialized) {
        return;
    }
    window.assistantAccountAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const ACCOUNT_API_ENDPOINT = "/Acudent/backend/api/register/register-user-assistant.php";

    // ==================== CREATE ACCOUNT FUNCTION WITH IMAGE ====================
    /**
     * Creates an assistant user account with profile picture
     * @param {FormData} formData - FormData containing account info and profile_picture file
     * @returns {Promise<Object>} - { success, message, assistant: { user_id, ... } }
     */
    window.createAssistantAccountWithImage = async function(formData) {
        try {
            console.log('📤 Creating assistant account with image');
            
            const response = await fetch(ACCOUNT_API_ENDPOINT, {
                method: "POST",
                body: formData
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            console.log('📥 API Response:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to create account");
            }

            console.log('✅ Account created successfully with user_id:', result.assistant?.user_id);
            return result;

        } catch (error) {
            console.error("❌ Account creation error:", error.message);
            throw error;
        }
    };

    // ==================== CREATE ACCOUNT FUNCTION (BACKWARD COMPATIBILITY) ====================
    /**
     * Creates an assistant user account (JSON version for backward compatibility)
     * @param {Object} accountData - { first_name, last_name, login_email, contact_email, password }
     * @returns {Promise<Object>} - { success, message, assistant: { user_id, ... } }
     */
    window.createAssistantAccount = async function(accountData) {
        try {
            console.log('📤 Creating assistant account (JSON)');
            
            // ✅ VALIDATE BEFORE SENDING
            const validation = window.validateAssistantAccountData(accountData);
            if (!validation.isValid) {
                console.error('❌ Validation errors:', validation.errors);
                throw new Error(validation.errors.join(', '));
            }
            
            const response = await fetch(ACCOUNT_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(accountData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error response:', errorText);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();
            console.log('📥 API Response:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to create account");
            }

            console.log('✅ Account created successfully with user_id:', result.assistant?.user_id);
            return result;

        } catch (error) {
            console.error("❌ Account creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates account data before submission
     * @param {Object} data - Account data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantAccountData = function(data) {
        const errors = [];

        // Log what we're validating
        console.log('🔍 Validating account data:', {
            has_first_name: !!data.first_name,
            has_last_name: !!data.last_name,
            has_login_email: !!data.login_email,
            has_contact_email: !!data.contact_email,
            has_password: !!data.password
        });

        // Required fields
        if (!data.first_name || data.first_name.trim() === '') {
            errors.push("First name is required");
        }
        
        if (!data.last_name || data.last_name.trim() === '') {
            errors.push("Last name is required");
        }
        
        if (!data.login_email || data.login_email.trim() === '') {
            errors.push("Login email is required");
        }
        
        if (!data.contact_email || data.contact_email.trim() === '') {
            errors.push("Contact email is required");
        }
        
        if (!data.password || data.password.trim() === '') {
            errors.push("Password is required");
        }

        // Email format validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (data.login_email && !emailRegex.test(data.login_email)) {
            errors.push("Invalid login email format");
        }
        
        if (data.contact_email && !emailRegex.test(data.contact_email)) {
            errors.push("Invalid contact email format");
        }

        // Password validation
        if (data.password && data.password.length < 8) {
            errors.push("Password must be at least 8 characters");
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    // ==================== CLEANUP FUNCTION ====================
    window.cleanupAssistantAccountAPI = function() {
        delete window.assistantAccountAPIInitialized;
        delete window.createAssistantAccount;
        delete window.createAssistantAccountWithImage;
        delete window.validateAssistantAccountData;
        delete window.cleanupAssistantAccountAPI;
        console.log('🧹 Assistant Account API cleaned up');
    };

    console.log('✅ Assistant Account API loaded');

})();