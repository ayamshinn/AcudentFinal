// ===================== DENTIST RECORD REGISTRATION API =====================
// Handles ONLY: Dentist professional record creation API call

(function() {
    'use strict';
    
    if (window.dentistRecordAPIInitialized) {
        return;
    }
    window.dentistRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const DENTIST_RECORD_API_ENDPOINT = "/Acudent/backend/api/register/add-dentist-record.php";

    // ==================== CREATE DENTIST RECORD WITH IMAGE ====================
    /**
     * Creates a dentist record with professional profile picture
     * @param {FormData} formData - FormData containing dentist info and professional_photo file
     * @returns {Promise<Object>} - { success, message, data: { user_id, staff_profile_id, dentist_id } }
     */
    window.createDentistRecordWithImage = async function(formData) {
        try {
            console.log('📤 Creating dentist record with image');
            
            const response = await fetch(DENTIST_RECORD_API_ENDPOINT, {
                method: "POST",
                // Don't set Content-Type - browser sets it with boundary for multipart/form-data
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create dentist record");
            }

            console.log('✅ Dentist record created:', result);
            return result;

        } catch (error) {
            console.error("❌ Dentist record creation error:", error);
            throw error;
        }
    };

    // ==================== CREATE DENTIST RECORD (BACKWARD COMPATIBILITY) ====================
    /**
     * Creates a dentist record (JSON version for backward compatibility)
     * @param {Object} recordData - Dentist record data
     * @returns {Promise<Object>} - { success, message, data: { user_id, staff_profile_id, dentist_id } }
     */
    window.createDentistRecord = async function(recordData) {
        try {
            console.log('📤 Creating dentist record (JSON)');
            
            const response = await fetch(DENTIST_RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            if (!response.ok) {
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create dentist record");
            }

            console.log('✅ Dentist record created:', result);
            return result;

        } catch (error) {
            console.error("❌ Dentist record creation error:", error);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates dentist record data before submission
     * @param {Object} data - Dentist record data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateDentistRecordData = function(data) {
        const errors = [];

        if (!data.user_id) {
            errors.push("User ID is required");
        }
        
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push("First name is required");
        }
        
        if (!data.lastName || data.lastName.trim() === '') {
            errors.push("Last name is required");
        }
        
        if (!data.licenseNumber || data.licenseNumber.trim() === '') {
            errors.push("License number is required");
        }
        
        if (!data.specialization || data.specialization.trim() === '') {
            errors.push("Specialization is required");
        }
        
        if (!data.education || data.education.trim() === '') {
            errors.push("Education is required");
        }
        
        if (!data.dateOfBirth) {
            errors.push("Date of birth is required");
        }
        
        if (!data.gender) {
            errors.push("Gender is required");
        }

        // Phone validation
        if (data.phone && !data.phone.match(/^\+?[0-9\s\-()]+$/)) {
            errors.push("Invalid phone number format");
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (data.email && !emailRegex.test(data.email)) {
            errors.push("Invalid email format");
        }

        // Working days validation
        if (!data.workingDays || !Array.isArray(data.workingDays) || data.workingDays.length === 0) {
            errors.push("At least one working day is required");
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Dentist Record API loaded');

})();