// ===================== ADMIN MAIN API JS =====================
// Handles dynamic loading of ALL API handlers

const DEBUG_MODE = false; // Set to false in production

function log(...args) {
    if (DEBUG_MODE) {
        console.log(...args);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    log('DOMContentLoaded - Initializing API handlers');
    initAPIHandlers();
});

// ===================== LISTEN FOR PAGE LOAD EVENTS =====================
function initAPIHandlers() {
    log('Setting up pageLoaded event listener');
    
    document.addEventListener('pageLoaded', (event) => {
        log('pageLoaded event received');
        
        const pageUrl = event.detail?.pageUrl;
        if (!pageUrl) {
            console.error('Invalid pageLoaded event - missing pageUrl');
            return;
        }
        
        log('Page URL:', pageUrl);
        initPageAPIScript(pageUrl);
    });
}

// ===================== PAGE API SCRIPT INITIALIZER =====================
async function initPageAPIScript(pageUrl) {
    log('Checking page URL:', pageUrl);
    
    try {
        await cleanupAllAPIHandlers();

        // ========== ADD NEW PATIENT RECORD ==========
        if (pageUrl.includes('add-new-patient-record.html')) {
            log('Loading Patient Record API...');
            await loadAPIScript(
                'patientRecordApi',
                '../../assets/js-api/patient-record/add-patient-record.api.js',
                'Patient Record API'
            );
            if (typeof window.createPatientRecord !== 'function') {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Patient Record API loaded successfully');
        }

        // ========== PATIENT MANAGEMENT - GET ALL PATIENTS ==========
        else if (pageUrl.includes('admin-patient-management.html')) {
            log('Loading Get All Patients API...');
            await loadAPIScript(
                'getAllPatientsApi',
                '../../assets/js-api/patient-record/get-all-patient.api.js',
                'Get All Patients API'
            );
            if (typeof window.getAllPatients !== 'function') {
                console.error('❌ API script loaded but getAllPatients function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Get All Patients API loaded successfully');
        }

        // ========== PATIENT DETAILED VIEW ==========


        // ========== PATIENT DETAILED VIEW ==========
else if (pageUrl.includes('admin-patient-management-detailed.html')) {
    await loadAPIScript(
        'getPatientByIdApi',
        '../../assets/js-api/patient-record/get-patient.api.js',
        'Get Patient By ID API'
    );
    if (typeof window.getPatientById !== 'function') {
        await new Promise(resolve => setTimeout(resolve, 100));
    }
}

        // ========== DENTIST MANAGEMENT - GET ALL DENTISTS ==========
        else if (pageUrl.includes('admin-dentist-management.html')) {
            log('Loading Dentist Management API...');
            await loadAPIScript(
                'getAllDentistsApi',
                '../../assets/js-api/admin-api/clinic-dentist-record/admin-get-all-dentist.api.js',
                'Get All Dentists API'
            );
            if (typeof window.getAllDentists !== 'function') {
                console.error('❌ API script loaded but function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Dentist Management API loaded successfully');
        }

        // ========== DENTIST DETAIL VIEW ==========
        else if (pageUrl.includes('admin-dentist-management-detailed.html')) {
            log('Loading Dentist Detail View API...');
            await loadAPIScript(
                'getDentistByIdApi',
                '../../assets/js-api/admin-api/clinic-dentist-record/admin-get-dentist.api.js',
                'Get Dentist By ID API'
            );
            if (typeof window.getDentistById !== 'function') {
                console.error('❌ API script loaded but getDentistById function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Dentist Detail View API loaded successfully');
        }

        // ========== FRONTDESK MANAGEMENT ==========
        else if (pageUrl.includes('admin-staff-frontdesk-management.html')) {
            log('Loading Frontdesk Management API...');
            await loadAPIScript(
                'getAllFrontdeskApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-frontdesk.api.js',
                'Get All Frontdesk API'
            );
            if (typeof window.getAllFrontdesk !== 'function') {
                console.error('❌ API script loaded but function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Frontdesk Management API loaded successfully');
        }

        // ========== FRONTDESK DETAILED VIEW ==========
        else if (pageUrl.includes('admin-staff-frontdesk-management-detailed.html')) {
            log('Loading Frontdesk Detail View API...');
            await loadAPIScript(
                'getAllFrontdeskApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-frontdesk.api.js',
                'Get All Frontdesk API (for Detail View)'
            );
            if (typeof window.getFrontdeskById !== 'function') {
                console.error('❌ API script loaded but getFrontdeskById function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Frontdesk Detail View API loaded successfully');
        }

        // ========== ASSISTANT MANAGEMENT ==========
        else if (pageUrl.includes('admin-staff-assistant-management.html')) {
            log('Loading Assistant Management API...');
            await loadAPIScript(
                'getAllAssistantsApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-assistant.api.js',
                'Get All Assistants API'
            );
            if (typeof window.getAllAssistants !== 'function') {
                console.error('❌ API script loaded but function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Assistant Management API loaded successfully');
        }

        // ========== ASSISTANT DETAILED VIEW ==========
        else if (pageUrl.includes('admin-staff-assistant-management-detailed.html')) {
            log('Loading Assistant Detail View API...');
            await loadAPIScript(
                'getAllAssistantsApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-get-all-assistant.api.js',
                'Get All Assistants API (for Detail View)'
            );
            if (typeof window.getAssistantById !== 'function') {
                console.error('❌ API script loaded but getAssistantById function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Assistant Detail View API loaded successfully');
        }

        // ========== DENTIST REGISTRATION ==========
        else if (pageUrl.includes('admin-dentist-register.html')) {
            log('Loading Dentist Registration APIs (2 files)...');
            await loadAPIScript(
                'dentistAccountApi',
                '../../assets/js-api/register/register-user-dentist.api.js',
                'Dentist Account API'
            );
            await loadAPIScript(
                'dentistRecordApi',
                '../../assets/js-api/admin-api/clinic-dentist-record/admin-add-dentist-record.api.js',
                'Dentist Record API'
            );
            log('Both Dentist APIs loaded successfully');
        }

        // ========== ASSISTANT REGISTRATION ==========
        else if (pageUrl.includes('admin-staff-assistant-register.html')) {
            log('Loading Assistant Registration APIs (2 files)...');
            await loadAPIScript(
                'assistantRegisterApi',
                '../../assets/js-api/register/register-user-staff-assistant.api.js',
                'Assistant Registration'
            );
            await loadAPIScript(
                'asRecordApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-add-assistant-record.api.js',
                'Assistant Record API'
            );
            log('Both Assistant APIs loaded successfully');
        }

        // ========== FRONTDESK REGISTRATION ==========
        else if (pageUrl.includes('admin-staff-frontdesk-register.html')) {
            log('Loading Frontdesk Registration APIs (2 files)...');
            await loadAPIScript(
                'frontdeskRegisterApi',
                '../../assets/js-api/register/register-user-staff-frontdesk.api.js',
                'Frontdesk Registration'
            );
            await loadAPIScript(
                'frontdeskRecordApi',
                '../../assets/js-api/admin-api/clinic-staff-record/admin-add-frontdesk-record.api.js',
                'Frontdesk Record API'
            );
            log('Both Frontdesk APIs loaded successfully');
        }

        else {
            log('No API handler needed for this page');
        }
        
    } catch (error) {
        console.error('❌ Failed to initialize page API:', error);
    }
}

// ===================== CLEANUP ALL API HANDLERS =====================
async function cleanupAllAPIHandlers() {
    log('Cleaning up all API handlers');
    
    await new Promise(resolve => setTimeout(resolve, 50));
    
    const cleanupFunctions = [
        'cleanupDentistAccountAPI',
        'cleanupDentistRecordAPI',
        'cleanupGetAllDentistsAPI',
        'cleanupGetAllFrontdeskAPI',
        'cleanupGetAllAssistantsAPI',
        'cleanupGetAssistantByIdAPI',
        'cleanupAssistantAPIHandler',
        'cleanupFrontdeskAPIHandler',
        'cleanupDentistRegistration',
        'cleanupPatientRecordAPI',
        'cleanupGetAllPatientsAPI'
    ];
    
    cleanupFunctions.forEach(funcName => {
        if (typeof window[funcName] === 'function') {
            try {
                window[funcName]();
                log(`${funcName} executed`);
            } catch (error) {
                console.error(`Error in ${funcName}:`, error);
            }
        }
    });
    
    const apiHandlers = [
        'dentistAccountApi',
        'dentistRecordApi',
        'getAllDentistsApi',
        'getDentistByIdApi',
        'getAllFrontdeskApi',
        'getAllAssistantsApi',
        'getAssistantByIdApi',
        'assistantRegisterApi',
        'frontdeskRegisterApi',
        'asRecordApi',
        'frontdeskRecordApi',
        'patientRecordApi',
        'getAllPatientsApi'     // ✅ Added
    ];
    
    apiHandlers.forEach(flagName => {
        const loadedFlag = `${flagName}Loaded`;
        
        const existingScript = document.querySelector(`script[data-api="${flagName}"]`);
        if (existingScript) {
            log(`Removing script: ${flagName}`);
            existingScript.remove();
        }
        
        if (window[loadedFlag]) {
            delete window[loadedFlag];
            log(`Cleared flag: ${loadedFlag}`);
        }
    });

    // ✅ Reset IIFE guard flags so API scripts re-initialize properly on next load
    const iifleFlags = [
        'getAllPatientsAPIInitialized',
        'patientRecordAPIInitialized',
        'getAllDentistsAPIInitialized',
        'getAllFrontdeskAPIInitialized',
        'getAllAssistantsAPIInitialized'
    ];
    iifleFlags.forEach(flag => {
        if (window[flag]) {
            delete window[flag];
            log(`Cleared IIFE flag: ${flag}`);
        }
    });
    
    log('Cleanup complete');
}

// ===================== REUSABLE API SCRIPT LOADER =====================
function loadAPIScript(flagName, scriptPath, displayName) {
    return new Promise((resolve, reject) => {
        log(`Loading ${displayName}...`);
        
        const loadedFlag = `${flagName}Loaded`;
        
        if (window[loadedFlag]) {
            log(`${displayName} already loaded`);
            resolve();
            return;
        }

        const script = document.createElement('script');
        script.src = scriptPath + '?v=' + Date.now();
        script.setAttribute('data-api', flagName);
        script.setAttribute('type', 'text/javascript');
        
        const metaNonce = document.querySelector('meta[name="csp-nonce"]');
        if (metaNonce) {
            script.setAttribute('nonce', metaNonce.getAttribute('content'));
        }
        
        script.onload = () => {
            setTimeout(() => {
                window[loadedFlag] = true;
                log(`✅ ${displayName} loaded successfully`);
                resolve();
            }, 100);
        };
        
        script.onerror = () => {
            console.error(`❌ Failed to load ${displayName} from ${scriptPath}`);
            if (!DEBUG_MODE) {
                showErrorNotification(`Failed to load ${displayName}. Please refresh the page.`);
            }
            reject(new Error(`Failed to load ${displayName}`));
        };
        
        document.body.appendChild(script);
        log(`Script tag appended: ${scriptPath}`);
    });
}

// ===================== ERROR NOTIFICATION HELPER =====================
function showErrorNotification(message) {
    if (document.querySelector('.api-load-error')) return;
    
    const errorMsg = document.createElement('div');
    errorMsg.className = 'api-load-error';
    errorMsg.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: #dc3545; color: white;
        padding: 15px 20px; border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 9999; max-width: 350px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        animation: slideIn 0.3s ease-out;
    `;
    errorMsg.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
            <i class="fa-solid fa-circle-exclamation" style="font-size:20px;"></i>
            <div>
                <strong style="display:block; margin-bottom:4px;">Error</strong>
                <span style="font-size:14px;">${message}</span>
            </div>
        </div>`;
    
    const style = document.createElement('style');
    style.textContent = `@keyframes slideIn { from { transform: translateX(400px); opacity:0; } to { transform: translateX(0); opacity:1; } }`;
    document.head.appendChild(style);
    document.body.appendChild(errorMsg);
    
    setTimeout(() => {
        errorMsg.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => errorMsg.remove(), 300);
    }, 5000);
}

// ===================== CLEANUP ON PAGE UNLOAD =====================
window.addEventListener('beforeunload', () => {
    log('Page unload - cleaning up API handlers');
    cleanupAllAPIHandlers();
});

window.adminApiReady = Promise.resolve();