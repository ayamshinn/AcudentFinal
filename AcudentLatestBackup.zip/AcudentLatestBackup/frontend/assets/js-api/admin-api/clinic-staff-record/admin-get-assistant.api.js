// ==================== ASSISTANT API FUNCTIONS (UPDATED) ====================
/**
 * Updated to match the PHP API which queries by staff_profile_id and role
 * Database Structure:
 * - Staff_Profile_tb: Contains staff_profile_id, user_id, role_id, personal info
 * - Roles_tb: Contains role_id, role_name (role_id for 'Assistant')
 * - Users_tb: Contains user_id, user_code, username, email, profile_picture
 * - Staff_Base_Schedule_tb: Contains schedule data linked by staff_profile_id
 */

const DEBUG_MODE = true; // Set to false in production

// ==================== GET ALL ASSISTANT STAFF ====================
/**
 * Gets all assistant staff members
 * @param {Object} options - Query options (search, order_by, limit, offset)
 * @returns {Promise<Object>} - Array of assistant staff with schedule
 */
window.getAllAssistants = async function(options = {}) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching all assistant staff with options:', options);

        // Build query parameters
        const params = new URLSearchParams();
        if (options.search) params.append('search', options.search);
        if (options.order_by) params.append('order_by', options.order_by);
        if (options.limit) params.append('limit', options.limit);
        if (options.offset) params.append('offset', options.offset);

        const url = `/Acudent/backend/api/clinic-staff/admin-get-all-assistant.php${params.toString() ? '?' + params.toString() : ''}`;
        
        if (DEBUG_MODE) console.log('📡 Request URL:', url);

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (DEBUG_MODE) console.log('📥 Response:', result);

        if (!result.success) {
            throw new Error(result.message || 'Failed to fetch assistant staff');
        }

        return result;

    } catch (error) {
        console.error("❌ Failed to fetch assistant staff:", error.message);
        throw error;
    }
};

// ==================== GET ASSISTANT BY STAFF_PROFILE_ID (OPTIMIZED WITH FALLBACK) ====================
/**
 * Gets a single assistant staff member by staff_profile_id - tries dedicated endpoint first, falls back to all assistants
 * @param {number} staffProfileId - Staff Profile ID
 * @returns {Promise<Object>} - Single assistant staff data with schedule
 */
window.getAssistantById = async function(staffProfileId) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching assistant by staff_profile_id:', staffProfileId);

        if (!staffProfileId) {
            throw new Error("Staff Profile ID is required");
        }

        // Validate that staffProfileId is numeric
        const numericId = parseInt(staffProfileId);
        if (isNaN(numericId)) {
            throw new Error("Invalid staff profile ID format");
        }

        // ✅ TRY THE DEDICATED ENDPOINT FIRST
        try {
            const url = `/Acudent/backend/api/clinic-staff/admin-get-assistant.php?staff_profile_id=${numericId}`;
            
            if (DEBUG_MODE) console.log('📡 Request URL (dedicated endpoint):', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    if (DEBUG_MODE) console.log('✅ Assistant fetched from dedicated endpoint');
                    return result;
                }
            }
        } catch (endpointError) {
            if (DEBUG_MODE) console.warn('⚠️ Dedicated endpoint failed, falling back to all assistants');
        }

        // ✅ FALLBACK: GET ALL ASSISTANTS AND FILTER BY staff_profile_id
        if (DEBUG_MODE) console.log('📡 Using fallback method (all assistants)');
        
        const result = await window.getAllAssistants();
        
        if (!result.success || !result.data) {
            throw new Error("Failed to fetch assistant staff");
        }

        const assistant = result.data.find(a => a.staff_profile_id === parseInt(staffProfileId));
        
        if (!assistant) {
            throw new Error(`Assistant staff with staff_profile_id ${staffProfileId} not found`);
        }

        return {
            success: true,
            message: "Assistant staff retrieved successfully",
            data: assistant
        };

    } catch (error) {
        console.error("❌ Failed to fetch assistant by ID:", error.message);
        throw error;
    }
};

// ==================== HELPER: FORMAT ASSISTANT FOR DISPLAY ====================
/**
 * Formats assistant data for display in UI
 * @param {Object} assistant - Raw assistant data from API
 * @returns {Object} - Formatted assistant data
 */
window.formatAssistantForDisplay = function(assistant) {
    if (!assistant) return null;

    const personalInfo = assistant.personal_info || {};
    const workInfo = assistant.work_info || {};

    return {
        staff_profile_id: assistant.staff_profile_id,
        code: assistant.assistant_code || 'N/A',
        name: personalInfo.full_name || 'N/A',
        first_name: personalInfo.first_name || '',
        last_name: personalInfo.last_name || '',
        email: personalInfo.email || 'Not provided',
        phone: personalInfo.phone || 'Not provided',
        gender: personalInfo.gender || 'Not specified',
        birthdate: personalInfo.birthdate || null,
        address: personalInfo.address || 'Not provided',
        shift: workInfo.shift || 'Not set',
        schedule: workInfo.schedule || [],
        profile_picture: assistant.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg',
        username: assistant.username || '',
        role_name: assistant.role_name || 'Assistant',
        created_at: assistant.created_at || null
    };
};

// ==================== HELPER: GET ASSISTANT PROFILE PICTURE ====================
/**
 * Gets the profile picture URL for an assistant staff member
 * @param {Object} assistant - Assistant data object
 * @returns {string} - Profile picture URL or default
 */
window.getAssistantProfilePicture = function(assistant) {
    if (!assistant) return '/Acudent/frontend/assets/images/default-pfp.jpg';
    
    if (assistant.profile_picture && assistant.profile_picture !== '') {
        return assistant.profile_picture;
    }
    
    return '/Acudent/frontend/assets/images/default-pfp.jpg';
};

// ==================== HELPER: CALCULATE AGE ====================
/**
 * Calculates age from birthdate
 * @param {string} birthdate - Birthdate in YYYY-MM-DD format
 * @returns {number|string} - Age in years or 'N/A'
 */
window.calculateAge = function(birthdate) {
    if (!birthdate) return 'N/A';
    
    const birth = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
};

// ==================== HELPER: FORMAT SCHEDULE ====================
/**
 * Formats schedule data for display
 * @param {Array} schedule - Array of schedule objects
 * @returns {Object} - Formatted schedule with working days and hours
 */
window.formatAssistantSchedule = function(schedule) {
    if (!schedule || !Array.isArray(schedule) || schedule.length === 0) {
        return {
            workingDays: 'Not set',
            workingHours: 'Not set',
            shift: 'Not set'
        };
    }

    // Get working days
    const workingDays = schedule
        .filter(s => s.is_working)
        .map(s => s.day)
        .join(', ');

    // Get working hours (from first working day)
    const firstWorkingDay = schedule.find(s => s.is_working);
    const workingHours = firstWorkingDay 
        ? `${firstWorkingDay.start_time} - ${firstWorkingDay.end_time}`
        : 'Not set';

    // Determine shift based on start time
    let shift = 'Not set';
    if (firstWorkingDay) {
        const startHour = parseInt(firstWorkingDay.start_time.split(':')[0]);
        if (startHour < 12) {
            shift = 'MORNING';
        } else if (startHour < 17) {
            shift = 'AFTERNOON';
        } else {
            shift = 'EVENING';
        }
    }

    return {
        workingDays: workingDays || 'Not set',
        workingHours: workingHours,
        shift: shift
    };
};

// ==================== API AVAILABILITY CHECK ====================
/**
 * Checks if all assistant API functions are available
 * @returns {boolean} - True if all APIs are ready
 */
window.isAssistantAPIReady = function() {
    return (
        typeof window.getAllAssistants === 'function' &&
        typeof window.getAssistantById === 'function' &&
        typeof window.formatAssistantForDisplay === 'function' &&
        typeof window.getAssistantProfilePicture === 'function'
    );
};

// Log API ready status
if (DEBUG_MODE) {
    console.log('✅ Assistant API functions loaded');
    console.log('   - getAllAssistants()');
    console.log('   - getAssistantById(staffProfileId)');
    console.log('   - formatAssistantForDisplay(assistant)');
    console.log('   - getAssistantProfilePicture(assistant)');
    console.log('   - calculateAge(birthdate)');
    console.log('   - formatAssistantSchedule(schedule)');
    console.log('   - isAssistantAPIReady()');
}

// Export for module systems (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getAllAssistants: window.getAllAssistants,
        getAssistantById: window.getAssistantById,
        formatAssistantForDisplay: window.formatAssistantForDisplay,
        getAssistantProfilePicture: window.getAssistantProfilePicture,
        calculateAge: window.calculateAge,
        formatAssistantSchedule: window.formatAssistantSchedule,
        isAssistantAPIReady: window.isAssistantAPIReady
    };
}