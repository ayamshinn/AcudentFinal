// ==================== FRONTDESK API FUNCTIONS (UPDATED) ====================
/**
 * Updated to match the PHP API which queries by staff_profile_id and role
 * Database Structure:
 * - Staff_Profile_tb: Contains staff_profile_id, user_id, role_id, personal info
 * - Roles_tb: Contains role_id, role_name (role_id 3 = 'Frontdesk')
 * - Users_tb: Contains user_id, user_code, username, email, profile_picture
 * - Staff_Base_Schedule_tb: Contains schedule data linked by staff_profile_id
 */

const DEBUG_MODE = true; // Set to false in production

// ==================== GET ALL FRONTDESK STAFF ====================
/**
 * Gets all frontdesk staff members
 * @param {Object} options - Query options (search, order_by, limit, offset)
 * @returns {Promise<Object>} - Array of frontdesk staff with schedule
 */
window.getAllFrontdesk = async function(options = {}) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching all frontdesk staff with options:', options);

        // Build query parameters
        const params = new URLSearchParams();
        if (options.search) params.append('search', options.search);
        if (options.order_by) params.append('order_by', options.order_by);
        if (options.limit) params.append('limit', options.limit);
        if (options.offset) params.append('offset', options.offset);

        const url = `/Acudent/backend/api/clinic-staff/admin-get-all-frontdesk.php${params.toString() ? '?' + params.toString() : ''}`;
        
        if (DEBUG_MODE) console.log('📡 Request URL:', url);

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (DEBUG_MODE) console.log('📥 Response:', result);

        if (!result.success) {
            throw new Error(result.message || 'Failed to fetch frontdesk staff');
        }

        return result;

    } catch (error) {
        console.error("❌ Failed to fetch frontdesk staff:", error.message);
        throw error;
    }
};

// ==================== GET FRONTDESK BY STAFF_PROFILE_ID ====================
/**
 * Gets a single frontdesk by staff_profile_id
 * Matches the PHP API endpoint: admin-get-frontdesk-by-id.php
 * 
 * Query: Joins Staff_Profile_tb with Users_tb and Roles_tb WHERE role_name = 'Frontdesk'
 * 
 * @param {number} staffProfileId - Staff Profile ID
 * @returns {Promise<Object>} - Single frontdesk data with schedule
 */
window.getFrontdeskById = async function(staffProfileId) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching frontdesk by staff_profile_id:', staffProfileId);

        if (!staffProfileId) {
            throw new Error("Staff Profile ID is required");
        }

        // Validate that staffProfileId is numeric
        const numericId = parseInt(staffProfileId);
        if (isNaN(numericId)) {
            throw new Error("Invalid staff profile ID format");
        }

        // ✅ Use staff_profile_id parameter (with backwards compatibility for frontdesk_id)
        const url = `/Acudent/backend/api/clinic-staff/admin-get-frontdesk-by-id.php?staff_profile_id=${numericId}`;
        
        if (DEBUG_MODE) console.log('📡 Request URL:', url);

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (DEBUG_MODE) console.log('📥 Response:', result);

        if (!result.success) {
            throw new Error(result.message || 'Failed to fetch frontdesk');
        }

        return result;

    } catch (error) {
        console.error("❌ Failed to fetch frontdesk by ID:", error.message);
        throw error;
    }
};

// ==================== HELPER: FORMAT FRONTDESK FOR DISPLAY ====================
/**
 * Formats frontdesk data for display in UI
 * @param {Object} frontdesk - Raw frontdesk data from API
 * @returns {Object} - Formatted frontdesk data
 */
window.formatFrontdeskForDisplay = function(frontdesk) {
    if (!frontdesk) return null;

    const personalInfo = frontdesk.personal_info || {};
    const workInfo = frontdesk.work_info || {};

    return {
        staff_profile_id: frontdesk.staff_profile_id,
        code: frontdesk.frontdesk_code || 'N/A',
        name: personalInfo.full_name || 'N/A',
        first_name: personalInfo.first_name || '',
        last_name: personalInfo.last_name || '',
        email: personalInfo.email || 'Not provided',
        phone: personalInfo.phone || 'Not provided',
        gender: personalInfo.gender || 'Not specified',
        birthdate: personalInfo.birthdate || null,
        address: personalInfo.address || 'Not provided',
        shift: workInfo.shift || 'Not set',
        schedule: workInfo.schedule || [],
        profile_picture: frontdesk.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg',
        username: frontdesk.username || '',
        role_name: frontdesk.role_name || 'Frontdesk',
        created_at: frontdesk.created_at || null
    };
};

// ==================== HELPER: GET FRONTDESK PROFILE PICTURE ====================
/**
 * Gets the profile picture URL for a frontdesk staff member
 * @param {Object} frontdesk - Frontdesk data object
 * @returns {string} - Profile picture URL or default
 */
window.getFrontdeskProfilePicture = function(frontdesk) {
    if (!frontdesk) return '/Acudent/frontend/assets/images/default-pfp.jpg';
    
    if (frontdesk.profile_picture && frontdesk.profile_picture !== '') {
        return frontdesk.profile_picture;
    }
    
    return '/Acudent/frontend/assets/images/default-pfp.jpg';
};

// ==================== HELPER: CALCULATE AGE ====================
/**
 * Calculates age from birthdate
 * @param {string} birthdate - Birthdate in YYYY-MM-DD format
 * @returns {number|string} - Age in years or 'N/A'
 */
window.calculateAge = function(birthdate) {
    if (!birthdate) return 'N/A';
    
    const birth = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
};

// ==================== HELPER: FORMAT SCHEDULE ====================
/**
 * Formats schedule data for display
 * @param {Array} schedule - Array of schedule objects
 * @returns {Object} - Formatted schedule with working days and hours
 */
window.formatSchedule = function(schedule) {
    if (!schedule || !Array.isArray(schedule) || schedule.length === 0) {
        return {
            workingDays: 'Not set',
            workingHours: 'Not set',
            shift: 'Not set'
        };
    }

    // Get working days
    const workingDays = schedule
        .filter(s => s.is_working)
        .map(s => s.day)
        .join(', ');

    // Get working hours (from first working day)
    const firstWorkingDay = schedule.find(s => s.is_working);
    const workingHours = firstWorkingDay 
        ? `${firstWorkingDay.start_time} - ${firstWorkingDay.end_time}`
        : 'Not set';

    // Determine shift based on start time
    let shift = 'Not set';
    if (firstWorkingDay) {
        const startHour = parseInt(firstWorkingDay.start_time.split(':')[0]);
        if (startHour < 12) {
            shift = 'MORNING';
        } else if (startHour < 17) {
            shift = 'AFTERNOON';
        } else {
            shift = 'EVENING';
        }
    }

    return {
        workingDays: workingDays || 'Not set',
        workingHours: workingHours,
        shift: shift
    };
};

// ==================== API AVAILABILITY CHECK ====================
/**
 * Checks if all frontdesk API functions are available
 * @returns {boolean} - True if all APIs are ready
 */
window.isFrontdeskAPIReady = function() {
    return (
        typeof window.getAllFrontdesk === 'function' &&
        typeof window.getFrontdeskById === 'function' &&
        typeof window.formatFrontdeskForDisplay === 'function' &&
        typeof window.getFrontdeskProfilePicture === 'function'
    );
};

// Log API ready status
if (DEBUG_MODE) {
    console.log('✅ Frontdesk API functions loaded');
    console.log('   - getAllFrontdesk()');
    console.log('   - getFrontdeskById(staffProfileId)');
    console.log('   - formatFrontdeskForDisplay(frontdesk)');
    console.log('   - getFrontdeskProfilePicture(frontdesk)');
    console.log('   - calculateAge(birthdate)');
    console.log('   - formatSchedule(schedule)');
    console.log('   - isFrontdeskAPIReady()');
}

// Export for module systems (if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getAllFrontdesk: window.getAllFrontdesk,
        getFrontdeskById: window.getFrontdeskById,
        formatFrontdeskForDisplay: window.formatFrontdeskForDisplay,
        getFrontdeskProfilePicture: window.getFrontdeskProfilePicture,
        calculateAge: window.calculateAge,
        formatSchedule: window.formatSchedule,
        isFrontdeskAPIReady: window.isFrontdeskAPIReady
    };
}