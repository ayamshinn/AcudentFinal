// ===================== ASSISTANT RECORD API =====================
// Handles ONLY: Assistant staff record creation API call
// Tailored to assistant_tb schema: certification, notes

(function() {
    'use strict';
    
    if (window.assistantRecordAPIInitialized) {
        return;
    }
    window.assistantRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-add-assistant-record.php";

    // ==================== CREATE ASSISTANT RECORD FUNCTION ====================
    /**
     * Creates assistant staff record
     * @param {Object} recordData - Assistant staff information
     * @returns {Promise<Object>} - API response
     */
    window.createAssistantRecord = async function(recordData) {
        try {
            console.log('📤 Creating assistant record...');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error - Status:', response.status);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create assistant record");
            }

            console.log('✅ Assistant record created successfully');
            return result;

        } catch (error) {
            console.error("❌ Assistant record creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates assistant record data before submission
     * @param {Object} data - Assistant data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID (from account creation)
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Personal Information (for staff_profile_tb)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // Phone is required in HTML
        if (!data.phone || data.phone.trim() === '') {
            errors.push('Phone number is required');
        }

        // Email is required in HTML
        if (!data.email || data.email.trim() === '') {
            errors.push('Email is required');
        }

        // Address is required in HTML
        if (!data.address || data.address.trim() === '') {
            errors.push('Address is required');
        }

        // Start date is required in HTML
        if (!data.startDate || data.startDate.trim() === '') {
            errors.push('Start date is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Working days validation (for staff_base_schedule_tb)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (for staff_base_schedule_tb)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Assistant staff must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Assistant Record API loaded');

})();// ===================== ASSISTANT RECORD API =====================
// Handles ONLY: Assistant staff record creation API call
// Tailored to assistant_tb schema: certification, notes

(function() {
    'use strict';
    
    if (window.assistantRecordAPIInitialized) {
        return;
    }
    window.assistantRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-add-assistant-record.php";

    // ==================== CREATE ASSISTANT RECORD FUNCTION ====================
    /**
     * Creates assistant staff record
     * @param {Object} recordData - Assistant staff information
     * @returns {Promise<Object>} - API response
     */
    window.createAssistantRecord = async function(recordData) {
        try {
            console.log('📤 Creating assistant record...');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error - Status:', response.status);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create assistant record");
            }

            console.log('✅ Assistant record created successfully');
            return result;

        } catch (error) {
            console.error("❌ Assistant record creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates assistant record data before submission
     * @param {Object} data - Assistant data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID (from account creation)
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Personal Information (for staff_profile_tb)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // Phone is required in HTML
        if (!data.phone || data.phone.trim() === '') {
            errors.push('Phone number is required');
        }

        // Email is required in HTML
        if (!data.email || data.email.trim() === '') {
            errors.push('Email is required');
        }

        // Address is required in HTML
        if (!data.address || data.address.trim() === '') {
            errors.push('Address is required');
        }

        // Start date is required in HTML
        if (!data.startDate || data.startDate.trim() === '') {
            errors.push('Start date is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Working days validation (for staff_base_schedule_tb)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (for staff_base_schedule_tb)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Assistant staff must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Assistant Record API loaded');

})();// ===================== ASSISTANT RECORD API =====================
// Handles ONLY: Assistant staff record creation API call
// Tailored to assistant_tb schema: certification, notes

(function() {
    'use strict';
    
    if (window.assistantRecordAPIInitialized) {
        return;
    }
    window.assistantRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-add-assistant-record.php";

    // ==================== CREATE ASSISTANT RECORD FUNCTION ====================
    /**
     * Creates assistant staff record
     * @param {Object} recordData - Assistant staff information
     * @returns {Promise<Object>} - API response
     */
    window.createAssistantRecord = async function(recordData) {
        try {
            console.log('📤 Creating assistant record...');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error - Status:', response.status);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create assistant record");
            }

            console.log('✅ Assistant record created successfully');
            return result;

        } catch (error) {
            console.error("❌ Assistant record creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates assistant record data before submission
     * @param {Object} data - Assistant data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID (from account creation)
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Personal Information (for staff_profile_tb)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // Phone is required in HTML
        if (!data.phone || data.phone.trim() === '') {
            errors.push('Phone number is required');
        }

        // Email is required in HTML
        if (!data.email || data.email.trim() === '') {
            errors.push('Email is required');
        }

        // Address is required in HTML
        if (!data.address || data.address.trim() === '') {
            errors.push('Address is required');
        }

        // Start date is required in HTML
        if (!data.startDate || data.startDate.trim() === '') {
            errors.push('Start date is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Working days validation (for staff_base_schedule_tb)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (for staff_base_schedule_tb)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Assistant staff must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Assistant Record API loaded');

})();// ===================== ASSISTANT RECORD API =====================
// Handles ONLY: Assistant staff record creation API call
// Tailored to assistant_tb schema: certification, notes

(function() {
    'use strict';
    
    if (window.assistantRecordAPIInitialized) {
        return;
    }
    window.assistantRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-add-assistant-record.php";

    // ==================== CREATE ASSISTANT RECORD FUNCTION ====================
    /**
     * Creates assistant staff record
     * @param {Object} recordData - Assistant staff information
     * @returns {Promise<Object>} - API response
     */
    window.createAssistantRecord = async function(recordData) {
        try {
            console.log('📤 Creating assistant record...');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error - Status:', response.status);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create assistant record");
            }

            console.log('✅ Assistant record created successfully');
            return result;

        } catch (error) {
            console.error("❌ Assistant record creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates assistant record data before submission
     * @param {Object} data - Assistant data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID (from account creation)
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Personal Information (for staff_profile_tb)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // Phone is required in HTML
        if (!data.phone || data.phone.trim() === '') {
            errors.push('Phone number is required');
        }

        // Email is required in HTML
        if (!data.email || data.email.trim() === '') {
            errors.push('Email is required');
        }

        // Address is required in HTML
        if (!data.address || data.address.trim() === '') {
            errors.push('Address is required');
        }

        // Start date is required in HTML
        if (!data.startDate || data.startDate.trim() === '') {
            errors.push('Start date is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Working days validation (for staff_base_schedule_tb)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (for staff_base_schedule_tb)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Assistant staff must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Assistant Record API loaded');

})();// ===================== ASSISTANT RECORD API =====================
// Handles ONLY: Assistant staff record creation API call
// Tailored to assistant_tb schema: certification, notes

(function() {
    'use strict';
    
    if (window.assistantRecordAPIInitialized) {
        return;
    }
    window.assistantRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/clinic-staff/admin-add-assistant-record.php";

    // ==================== CREATE ASSISTANT RECORD FUNCTION ====================
    /**
     * Creates assistant staff record
     * @param {Object} recordData - Assistant staff information
     * @returns {Promise<Object>} - API response
     */
    window.createAssistantRecord = async function(recordData) {
        try {
            console.log('📤 Creating assistant record...');

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(recordData)
            });

            console.log('📥 Response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Server error - Status:', response.status);
                throw new Error(`Server returned ${response.status}: ${response.statusText}`);
            }

            const result = await response.json();

            if (!result.success) {
                throw new Error(result.message || "Failed to create assistant record");
            }

            console.log('✅ Assistant record created successfully');
            return result;

        } catch (error) {
            console.error("❌ Assistant record creation error:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    /**
     * Validates assistant record data before submission
     * @param {Object} data - Assistant data to validate
     * @returns {Object} - { isValid: boolean, errors: string[] }
     */
    window.validateAssistantData = function(data) {
        const errors = [];

        // ========== REQUIRED FIELDS ==========
        
        // User ID (from account creation)
        if (!data.user_id) {
            errors.push('User ID is required');
        }

        // Personal Information (for staff_profile_tb)
        if (!data.firstName || data.firstName.trim() === '') {
            errors.push('First name is required');
        }

        if (!data.lastName || data.lastName.trim() === '') {
            errors.push('Last name is required');
        }

        if (!data.dateOfBirth || data.dateOfBirth.trim() === '') {
            errors.push('Date of birth is required');
        }

        if (!data.gender || data.gender.trim() === '') {
            errors.push('Gender is required');
        }

        // Phone is required in HTML
        if (!data.phone || data.phone.trim() === '') {
            errors.push('Phone number is required');
        }

        // Email is required in HTML
        if (!data.email || data.email.trim() === '') {
            errors.push('Email is required');
        }

        // Address is required in HTML
        if (!data.address || data.address.trim() === '') {
            errors.push('Address is required');
        }

        // Start date is required in HTML
        if (!data.startDate || data.startDate.trim() === '') {
            errors.push('Start date is required');
        }

        // ========== OPTIONAL FIELD VALIDATION ==========

        // Phone validation
        if (data.phone && data.phone.trim() !== '' && !/^\+?[0-9\s\-()]+$/.test(data.phone)) {
            errors.push('Invalid phone number format');
        }

        // Email validation
        if (data.email && data.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
            errors.push('Invalid email format');
        }

        // Working days validation (for staff_base_schedule_tb)
        if (data.workingDays) {
            if (!Array.isArray(data.workingDays)) {
                errors.push('Working days must be an array');
            } else if (data.workingDays.length === 0) {
                errors.push('Please select at least one working day');
            } else {
                const validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
                const invalidDays = data.workingDays.filter(day => !validDays.includes(day));
                if (invalidDays.length > 0) {
                    errors.push(`Invalid working days: ${invalidDays.join(', ')}`);
                }
            }
        }

        // Time validation (for staff_base_schedule_tb)
        if (data.startTime && data.startTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.startTime)) {
            errors.push('Invalid start time format (use HH:MM)');
        }

        if (data.endTime && data.endTime.trim() !== '' && !/^([01]\d|2[0-3]):([0-5]\d)$/.test(data.endTime)) {
            errors.push('Invalid end time format (use HH:MM)');
        }

        // Date validation
        if (data.startDate && data.startDate.trim() !== '') {
            const startDate = new Date(data.startDate);
            if (isNaN(startDate.getTime())) {
                errors.push('Invalid start date format');
            }
        }

        if (data.dateOfBirth && data.dateOfBirth.trim() !== '') {
            const birthDate = new Date(data.dateOfBirth);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid date of birth format');
            } else {
                // Check if person is at least 18 years old
                const today = new Date();
                const age = today.getFullYear() - birthDate.getFullYear();
                if (age < 18) {
                    errors.push('Assistant staff must be at least 18 years old');
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    console.log('✅ Assistant Record API loaded');

})();