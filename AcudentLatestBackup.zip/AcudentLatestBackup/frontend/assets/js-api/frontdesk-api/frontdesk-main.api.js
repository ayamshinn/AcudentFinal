// ===================== FRONTDESK MAIN API JS =====================
// Handles dynamic loading of ALL API handlers for the Frontdesk portal

const DEBUG_MODE = false; // Set to true for development

function log(...args) {
    if (DEBUG_MODE) {
        console.log(...args);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    log('DOMContentLoaded - Initializing Frontdesk API handlers');
    initAPIHandlers();
});

// ===================== LISTEN FOR PAGE LOAD EVENTS =====================
function initAPIHandlers() {
    log('Setting up pageLoaded event listener');

    document.addEventListener('pageLoaded', (event) => {
        log('pageLoaded event received');

        const pageUrl = event.detail?.pageUrl;
        if (!pageUrl) {
            console.error('Invalid pageLoaded event - missing pageUrl');
            return;
        }

        log('Page URL:', pageUrl);
        initPageAPIScript(pageUrl);
    });
}

// ===================== PAGE API SCRIPT INITIALIZER =====================
async function initPageAPIScript(pageUrl) {
    log('Checking page URL:', pageUrl);

    try {
        await cleanupAllAPIHandlers();

        // ========== PATIENT RECORDS LIST ==========
        if (pageUrl.includes('staff-frontdesk-patient-records.html')) {
            log('Loading Get All Patients API...');
            await loadAPIScript(
                'getAllPatientsApi',
                '../../assets/js-api/patient-record/get-all-patient.api.js',
                'Get All Patients API'
            );
            if (typeof window.getAllPatients !== 'function') {
                console.error('❌ API script loaded but getAllPatients function not available');
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Get All Patients API loaded successfully');
        }

        // ========== ADD NEW PATIENT RECORD ==========
        else if (pageUrl.includes('add-new-patient-record.html')) {
            log('Loading Patient Record API...');
            await loadAPIScript(
                'patientRecordApi',
                '../../assets/js-api/patient-record/add-patient-record.api.js',
                'Patient Record API'
            );
            if (typeof window.createPatientRecord !== 'function') {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Patient Record API loaded successfully');
        }

        // ========== PATIENT DETAILED VIEW ==========
        else if (pageUrl.includes('staff-frontdesk-patient-records-detailed.html')) {
            log('Loading Get Patient By ID API...');
            await loadAPIScript(
                'getPatientByIdApi',
                '../../assets/js-api/patient-record/get-patient.api.js',
                'Get Patient By ID API'
            );
            if (typeof window.getPatientById !== 'function') {
                await new Promise(resolve => setTimeout(resolve, 100));
            }
            log('Get Patient By ID API loaded successfully');
        }

        else {
            log('No API handler needed for this page');
        }

    } catch (error) {
        console.error('❌ Failed to initialize page API:', error);
    }
}

// ===================== CLEANUP ALL API HANDLERS =====================
async function cleanupAllAPIHandlers() {
    log('Cleaning up all API handlers');

    await new Promise(resolve => setTimeout(resolve, 50));

    const cleanupFunctions = [
        'cleanupPatientRecordAPI',
        'cleanupGetAllPatientsAPI',
        'cleanupGetPatientByIdAPI'
    ];

    cleanupFunctions.forEach(funcName => {
        if (typeof window[funcName] === 'function') {
            try {
                window[funcName]();
                log(`${funcName} executed`);
            } catch (error) {
                console.error(`Error in ${funcName}:`, error);
            }
        }
    });

    const apiHandlers = [
        'getAllPatientsApi',
        'patientRecordApi',
        'getPatientByIdApi'
    ];

    apiHandlers.forEach(flagName => {
        const loadedFlag = `${flagName}Loaded`;

        const existingScript = document.querySelector(`script[data-api="${flagName}"]`);
        if (existingScript) {
            log(`Removing script: ${flagName}`);
            existingScript.remove();
        }

        if (window[loadedFlag]) {
            delete window[loadedFlag];
            log(`Cleared flag: ${loadedFlag}`);
        }
    });

    // Reset IIFE guard flags so API scripts re-initialize on next load
    const iifleFlags = [
        'getAllPatientsAPIInitialized',
        'patientRecordAPIInitialized',
        'getPatientByIdAPIInitialized'
    ];
    iifleFlags.forEach(flag => {
        if (window[flag]) {
            delete window[flag];
            log(`Cleared IIFE flag: ${flag}`);
        }
    });

    log('Cleanup complete');
}

// ===================== REUSABLE API SCRIPT LOADER =====================
function loadAPIScript(flagName, scriptPath, displayName) {
    return new Promise((resolve, reject) => {
        log(`Loading ${displayName}...`);

        const loadedFlag = `${flagName}Loaded`;

        if (window[loadedFlag]) {
            log(`${displayName} already loaded`);
            resolve();
            return;
        }

        const script = document.createElement('script');
        script.src = scriptPath + '?v=' + Date.now();
        script.setAttribute('data-api', flagName);
        script.setAttribute('type', 'text/javascript');

        const metaNonce = document.querySelector('meta[name="csp-nonce"]');
        if (metaNonce) {
            script.setAttribute('nonce', metaNonce.getAttribute('content'));
        }

        script.onload = () => {
            setTimeout(() => {
                window[loadedFlag] = true;
                log(`✅ ${displayName} loaded successfully`);
                resolve();
            }, 100);
        };

        script.onerror = () => {
            console.error(`❌ Failed to load ${displayName} from ${scriptPath}`);
            showFrontdeskErrorNotification(`Failed to load ${displayName}. Please refresh the page.`);
            reject(new Error(`Failed to load ${displayName}`));
        };

        document.body.appendChild(script);
        log(`Script tag appended: ${scriptPath}`);
    });
}

// ===================== ERROR NOTIFICATION HELPER =====================
function showFrontdeskErrorNotification(message) {
    if (document.querySelector('.api-load-error')) return;

    const errorMsg = document.createElement('div');
    errorMsg.className = 'api-load-error';
    errorMsg.style.cssText = `
        position: fixed; top: 20px; right: 20px;
        background: #dc3545; color: white;
        padding: 15px 20px; border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        z-index: 9999; max-width: 350px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        animation: slideIn 0.3s ease-out;
    `;
    errorMsg.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
            <i class="fa-solid fa-circle-exclamation" style="font-size:20px;"></i>
            <div>
                <strong style="display:block; margin-bottom:4px;">Error</strong>
                <span style="font-size:14px;">${message}</span>
            </div>
        </div>`;

    const style = document.createElement('style');
    style.textContent = `@keyframes slideIn { from { transform: translateX(400px); opacity:0; } to { transform: translateX(0); opacity:1; } }`;
    document.head.appendChild(style);
    document.body.appendChild(errorMsg);

    setTimeout(() => {
        errorMsg.style.animation = 'slideIn 0.3s ease-out reverse';
        setTimeout(() => errorMsg.remove(), 300);
    }, 5000);
}

// ===================== CLEANUP ON PAGE UNLOAD =====================
window.addEventListener('beforeunload', () => {
    log('Page unload - cleaning up API handlers');
    cleanupAllAPIHandlers();
});