// ===================== GET ALL PATIENTS API =====================
// Handles ONLY: Fetching all patient records
// Patients have no user accounts — data comes from patients_tb only

(function() {
    'use strict';

    if (window.getAllPatientsAPIInitialized) {
        return;
    }
    window.getAllPatientsAPIInitialized = true;

    const GET_ALL_PATIENTS_API_ENDPOINT = "/Acudent/backend/api/patient-record/get-all-patient.php";
    const DEBUG_MODE = false;

    // ==================== GET ALL PATIENTS ====================
    window.getAllPatients = async function(options = {}) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching all patients with options:', options);

            const params = new URLSearchParams();
            if (options.search)   params.append('search',   options.search);
            if (options.order_by) params.append('order_by', options.order_by);
            if (options.page)     params.append('page',     options.page);
            if (options.limit)    params.append('limit',    options.limit);

            const url = `${GET_ALL_PATIENTS_API_ENDPOINT}?${params.toString()}`;
            if (DEBUG_MODE) console.log('📡 Request URL:', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });

            const rawText = await response.text();
            if (DEBUG_MODE) console.log('📥 Raw response:', rawText.substring(0, 300));
            const jsonStart = rawText.indexOf('{');
            if (jsonStart === -1) {
                // Likely a 404 (wrong path) or empty PHP response
                const preview = rawText.substring(0, 200).replace(/\n/g, ' ');
                throw new Error(
                    `No JSON in response (HTTP ${response.status}). ` +
                    `Check PHP file path. Response preview: ${preview}`
                );
            }

            let result;
            try {
                result = JSON.parse(rawText.substring(jsonStart));
            } catch (e) {
                throw new Error('Server returned an invalid response.');
            }

            if (DEBUG_MODE) console.log('📥 Response data:', result);
            if (!result.success) throw new Error(result.message || 'Failed to fetch patients');

            return result;

        } catch (error) {
            console.error('Failed to fetch patients:', error.message);
            throw error;
        }
    };

    // ==================== GET PATIENT BY ID ====================
    window.getPatientById = async function(patientId) {
        try {
            if (!patientId) throw new Error('Patient ID is required');

            const result = await window.getAllPatients();
            if (!result.success || !result.data) throw new Error('Failed to fetch patients');

            const patient = result.data.find(p => p.patient_id === parseInt(patientId));
            if (!patient) throw new Error(`Patient with ID ${patientId} not found`);

            return { success: true, message: 'Patient retrieved successfully', data: patient };

        } catch (error) {
            console.error('Failed to fetch patient by ID:', error.message);
            throw error;
        }
    };

    // ==================== SEARCH PATIENTS ====================
    window.searchPatients = async function(searchTerm) {
        try {
            return await window.getAllPatients({ search: searchTerm });
        } catch (error) {
            console.error('Search failed:', error.message);
            throw error;
        }
    };

    // ==================== GET PATIENTS PAGINATED ====================
    window.getPatientsPaginated = async function(page = 1, limit = 10) {
        try {
            return await window.getAllPatients({ page, limit });
        } catch (error) {
            console.error('Pagination failed:', error.message);
            throw error;
        }
    };

    // ==================== FORMAT PATIENT FOR DISPLAY ====================
    window.formatPatientForDisplay = function(patient) {
        const info = patient.personal_info || {};
        return {
            id:                patient.patient_id,
            code:              patient.patient_code,
            fullName:          info.full_name   || '',
            firstName:         info.first_name  || '',
            lastName:          info.last_name   || '',
            middleName:        info.middle_name || '',
            age:               info.age,
            gender:            info.gender      || '',
            birthdate:         info.birthdate   || '',
            phone:             info.phone       || 'N/A',
            email:             info.email       || 'N/A',
            address:           info.address     || 'N/A',
            profilePicture:    window.getPatientProfilePicture(patient),
            status:            patient.status,
            totalAppointments: patient.total_appointments || 0,
            hasHMO:            patient.hmo !== null,
            hmo:               patient.hmo,
            hasGuardian:       patient.guardian !== null,
            guardian:          patient.guardian,
            createdAt:         patient.created_at
        };
    };

    // ==================== HELPER: PROFILE PICTURE ====================
    window.getPatientProfilePicture = function(patient) {
        if (patient.profile_picture) return patient.profile_picture;
        return '/Acudent/frontend/assets/images/default-pfp.jpg';
    };

    // ==================== RENDER TILE VIEW ====================
    window.renderPatientTileView = function(patients, containerId, detailPageUrl) {
        const container = document.getElementById(containerId);
        if (!container) return;

        // ✅ Target only the .row inside — never touch the wrapper div
        // The .row keeps: row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-2 row-cols-xl-4 ps-3
        const row = container.querySelector('.row');
        if (!row) return;

        if (!patients.length) {
            row.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fas fa-user-slash fa-2x mb-3" style="color:#ccc;"></i>
                    <p class="text-muted">No patient records found.</p>
                </div>`;
            return;
        }

        // ✅ Exact same column classes as original HTML structure
        row.innerHTML = patients.map(p => `
            <div class="col-12 col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6 col-profile-box">
                <div class="profile-box" tabindex="0" data-page="${detailPageUrl}" data-id="${p.id}">
                    <div class="record-img-container">
                        <img src="${p.profilePicture}"
                             alt="${p.fullName}"
                             onerror="this.src='/Acudent/frontend/assets/images/default-pfp.jpg'">
                    </div>
                    <div class="info-container">
                        <h3>${p.fullName}</h3>
                        <span>${p.code}</span>
                    </div>
                </div>
            </div>
        `).join('');

        row.querySelectorAll('.profile-box').forEach(box => {
            box.addEventListener('click', () => {
                const url = box.getAttribute('data-page');
                const id  = box.getAttribute('data-id');
                if (!url) return;
                if (typeof window.loadPage === 'function') {
                    window.loadPage(url, { patientId: id });
                } else {
                    window.location.href = url;
                }
            });
        });
    };

    // ==================== RENDER LIST VIEW ====================
    window.renderPatientListView = function(patients, tbodyId, detailPageUrl) {
        const tbody = document.getElementById(tbodyId);
        if (!tbody) return;

        if (!patients.length) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center text-muted py-4">No patient records found.</td>
                </tr>`;
            return;
        }

        tbody.innerHTML = patients.map(p => `
            <tr>
                <td>${p.fullName}</td>
                <td>${p.code}</td>
                <td>${p.phone}</td>
                <td>${p.email}</td>
                <td>
                    <div class="appointment-td-wrapper d-flex flex-row align-items-center">
                        <p class="mb-0">${p.totalAppointments}</p>
                        <button type="button"
                                class="ms-auto td-view-button"
                                data-page="${detailPageUrl}"
                                data-id="${p.id}">
                            View Details
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');

        tbody.querySelectorAll('.td-view-button').forEach(btn => {
            btn.addEventListener('click', () => {
                const url = btn.getAttribute('data-page');
                const id  = btn.getAttribute('data-id');
                if (!url) return;
                if (typeof window.loadPage === 'function') {
                    window.loadPage(url, { patientId: id });
                } else {
                    window.location.href = url;
                }
            });
        });
    };

    // ==================== UPDATE COUNT DISPLAY ====================
    window.updatePatientCountDisplay = function(showing, total, selector = '.count-show-header') {
        const el = document.querySelector(selector);
        if (el) el.textContent = `Showing ${showing} of ${total}`;
    };

    if (DEBUG_MODE) console.log('✅ Get All Patients API loaded');

})();

// ==================== GET PATIENT BY ID (WITH DEDICATED ENDPOINT + FALLBACK) ====================
/**
 * Gets a single patient by ID
 * Tries dedicated endpoint first, falls back to filtering from getAllPatients
 * @param {number} patientId - Patient ID
 * @returns {Promise<Object>} - Single patient data
 */
window.getPatientById = async function(patientId) {
    try {
        if (DEBUG_MODE) console.log('📤 Fetching patient by ID:', patientId);

        if (!patientId) throw new Error('Patient ID is required');

        // ✅ TRY DEDICATED ENDPOINT FIRST
        try {
            const url = `/Acudent/backend/api/patient-record/get-patient.php?patient_id=${patientId}`;

            if (DEBUG_MODE) console.log('📡 Request URL (dedicated endpoint):', url);

            const response = await fetch(url, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });

            if (response.ok) {
                const rawText = await response.text();
                const jsonStart = rawText.indexOf('{');
                if (jsonStart !== -1) {
                    const result = JSON.parse(rawText.substring(jsonStart));
                    if (result.success) {
                        if (DEBUG_MODE) console.log('✅ Patient fetched from dedicated endpoint');
                        return result;
                    }
                }
            }
        } catch (endpointError) {
            if (DEBUG_MODE) console.warn('⚠️ Dedicated endpoint failed, falling back to getAllPatients');
        }

        // ✅ FALLBACK: Filter from getAllPatients
        if (DEBUG_MODE) console.log('📡 Using fallback method (getAllPatients)');

        const result = await window.getAllPatients();

        if (!result.success || !result.data) throw new Error('Failed to fetch patients');

        const patient = result.data.find(p => p.patient_id === parseInt(patientId));

        if (!patient) throw new Error(`Patient with ID ${patientId} not found`);

        return {
            success: true,
            message: 'Patient retrieved successfully',
            data: patient
        };

    } catch (error) {
        console.error('Failed to fetch patient by ID:', error.message);
        throw error;
    }
};