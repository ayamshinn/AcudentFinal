// ===================== GET PATIENT BY ID API =====================
// Handles ONLY: Fetching a single patient record by ID
// Tries dedicated endpoint first, falls back to getAllPatients

(function() {
    'use strict';

    if (window.getPatientByIdAPIInitialized) {
        return;
    }
    window.getPatientByIdAPIInitialized = true;

    // ==================== API ENDPOINTS ====================
    const GET_PATIENT_BY_ID_ENDPOINT = "/Acudent/backend/api/patient-record/get-patient.php";
    const GET_ALL_PATIENTS_ENDPOINT  = "/Acudent/backend/api/patient-record/get-all-patient.php";

    // ==================== DEVELOPMENT MODE ====================
    const DEBUG_MODE = false;

    // ==================== GET PATIENT BY ID (WITH FALLBACK) ====================
    /**
     * Gets a single patient by ID
     * Tries dedicated endpoint first, falls back to filtering from getAllPatients
     * @param {number} patientId - Patient ID
     * @returns {Promise<Object>} - Single patient data
     */
    window.getPatientById = async function(patientId) {
        try {
            if (DEBUG_MODE) console.log('📤 Fetching patient by ID:', patientId);

            if (!patientId) {
                throw new Error('Patient ID is required');
            }

            // ✅ TRY DEDICATED ENDPOINT FIRST
            try {
                const url = `${GET_PATIENT_BY_ID_ENDPOINT}?patient_id=${patientId}`;

                if (DEBUG_MODE) console.log('📡 Request URL (dedicated endpoint):', url);

                const response = await fetch(url, {
                    method: 'GET',
                    headers: { 'Content-Type': 'application/json' }
                });

                if (response.ok) {
                    const rawText = await response.text();
                    const jsonStart = rawText.indexOf('{');
                    if (jsonStart !== -1) {
                        const result = JSON.parse(rawText.substring(jsonStart));
                        if (result.success) {
                            if (DEBUG_MODE) console.log('✅ Patient fetched from dedicated endpoint');
                            return result;
                        }
                    }
                }
            } catch (endpointError) {
                if (DEBUG_MODE) console.warn('⚠️ Dedicated endpoint failed, falling back to getAllPatients');
            }

            // ✅ FALLBACK: Get all patients and filter by ID
            if (DEBUG_MODE) console.log('📡 Using fallback method (getAllPatients)');

            const fallbackResponse = await fetch(`${GET_ALL_PATIENTS_ENDPOINT}`, {
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });

            const rawText = await fallbackResponse.text();
            const jsonStart = rawText.indexOf('{');
            if (jsonStart === -1) throw new Error('Server error: no valid response received.');

            const result = JSON.parse(rawText.substring(jsonStart));

            if (!result.success || !result.data) {
                throw new Error('Failed to fetch patients');
            }

            const patient = result.data.find(p => p.patient_id === parseInt(patientId));

            if (!patient) {
                throw new Error(`Patient with ID ${patientId} not found`);
            }

            return {
                success: true,
                message: 'Patient retrieved successfully',
                data: patient
            };

        } catch (error) {
            console.error('Failed to fetch patient by ID:', error.message);
            throw error;
        }
    };

    if (DEBUG_MODE) console.log('✅ Get Patient By ID API loaded');

})();