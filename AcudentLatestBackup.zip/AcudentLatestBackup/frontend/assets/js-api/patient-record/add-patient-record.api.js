// ===================== PATIENT RECORD API =====================
// Handles ONLY: Patient record creation API call

(function() {
    'use strict';
    
    if (window.patientRecordAPIInitialized) {
        return;
    }
    window.patientRecordAPIInitialized = true;

    // ==================== API ENDPOINT ====================
    const RECORD_API_ENDPOINT = "/Acudent/backend/api/patient-record/add-patient-record.php";

    // ==================== DEVELOPMENT MODE (Set to false in production) ====================
    const DEBUG_MODE = false;

    // ==================== CREATE PATIENT RECORD FUNCTION ====================
    window.createPatientRecord = async function(patientData) {
        try {
            if (DEBUG_MODE) console.log('📤 Creating patient record', patientData);

            const response = await fetch(RECORD_API_ENDPOINT, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(patientData)
            });

            if (DEBUG_MODE) console.log('📥 Response status:', response.status);

            // ✅ FIX: Always try to parse the response body first,
            // even on 500 — PHP display_errors can corrupt status
            // while the actual JSON result is still valid.
            const rawText = await response.text();
            if (DEBUG_MODE) console.log('📥 Raw response text:', rawText);

            // Strip any PHP warnings/notices printed before the JSON
            // They appear before the first '{' character
            const jsonStart = rawText.indexOf('{');
            if (jsonStart === -1) {
                // No JSON found at all — real server error
                throw new Error('Server error: no valid response received. Please check server logs.');
            }

            const cleanedText = rawText.substring(jsonStart);

            let result;
            try {
                result = JSON.parse(cleanedText);
            } catch (parseError) {
                if (DEBUG_MODE) console.error('❌ JSON parse error:', parseError);
                throw new Error('Server returned an invalid response. Please check server logs.');
            }

            if (DEBUG_MODE) console.log('📥 Parsed response:', result);

            if (!result.success) {
                throw new Error(result.message || "Failed to create patient record");
            }

            return result;

        } catch (error) {
            console.error("Patient record creation failed:", error.message);
            throw error;
        }
    };

    // ==================== VALIDATION HELPER ====================
    window.validatePatientData = function(data) {
        const errors = [];

        // ========== HELPER: safely convert any value to a trimmed string ==========
        function toStr(val) {
            if (val === null || val === undefined) return '';
            return String(val).trim();
        }

        // ========== PERSONAL INFORMATION ==========
        if (!toStr(data.LastName)) {
            errors.push('Last name is required');
        }

        if (!toStr(data.FirstName)) {
            errors.push('First name is required');
        }

        if (!toStr(data.Gender)) {
            errors.push('Gender is required');
        } else if (!['Male', 'Female'].includes(data.Gender)) {
            errors.push('Invalid gender value');
        }

        if (!toStr(data.Birthdate)) {
            errors.push('Birthdate is required');
        } else {
            const birthDate = new Date(data.Birthdate);
            if (isNaN(birthDate.getTime())) {
                errors.push('Invalid birthdate format');
            } else if (birthDate > new Date()) {
                errors.push('Birthdate cannot be in the future');
            }
        }

        // ✅ Age can be a number or string — convert safely before any string operations
        const ageStr = toStr(data.Age);
        const ageParsed = parseInt(ageStr, 10);

        if (ageStr === '') {
            errors.push('Age is required');
        } else if (isNaN(ageParsed) || ageParsed < 0) {
            errors.push('Invalid age value');
        }

        if (!toStr(data.PhoneNumber)) {
            errors.push('Phone number is required');
        } else if (!/^\+?[0-9\s\-()]+$/.test(toStr(data.PhoneNumber))) {
            errors.push('Invalid phone number format');
        }

        if (!toStr(data.Email)) {
            errors.push('Email address is required');
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toStr(data.Email))) {
            errors.push('Invalid email format');
        }

        if (!toStr(data.Address)) {
            errors.push('Address is required');
        }

        // ========== HMO VALIDATION ==========
        if (data.hasHMO === 'yes') {
            if (!toStr(data.HMOProvider)) {
                errors.push('HMO provider is required when HMO is selected');
            }
            if (!toStr(data.MembershipID)) {
                errors.push('Membership ID is required when HMO is selected');
            }
        }

        // ========== GUARDIAN VALIDATION (for minors) ==========
        if (!isNaN(ageParsed) && ageParsed < 18) {
            if (!toStr(data['guardian-fullname'])) {
                errors.push('Guardian full name is required for patients under 18');
            }

            if (!toStr(data.MContactNum)) {
                errors.push('Guardian contact number is required for patients under 18');
            } else if (!/^\+?[0-9\s\-()]+$/.test(toStr(data.MContactNum))) {
                errors.push('Invalid guardian phone number format');
            }

            if (!toStr(data.RltoPatient)) {
                errors.push('Relationship to patient is required for patients under 18');
            }

            if (!toStr(data.GuardianEmail)) {
                errors.push('Guardian email is required for patients under 18');
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toStr(data.GuardianEmail))) {
                errors.push('Invalid guardian email format');
            }
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    };

    // ==================== SHOW ERROR MESSAGE HELPER ====================
    window.showPatientFormErrors = function(errors) {
        // Remove any existing error container
        const existingError = document.querySelector('.patient-form-error-container');
        if (existingError) existingError.remove();

        // Create error container
        const errorContainer = document.createElement('div');
        errorContainer.className = 'patient-form-error-container alert alert-danger';
        errorContainer.style.cssText = 'margin: 20px 0; padding: 15px; border-radius: 5px;';

        const errorTitle = document.createElement('h5');
        errorTitle.textContent = 'Please correct the following errors:';
        errorTitle.style.marginBottom = '10px';
        errorContainer.appendChild(errorTitle);

        const errorList = document.createElement('ul');
        errorList.style.marginBottom = '0';
        errors.forEach(error => {
            const li = document.createElement('li');
            li.textContent = error;
            errorList.appendChild(li);
        });
        errorContainer.appendChild(errorList);

        // Insert at the top of the form and scroll to it
        const formContainer = document.querySelector('.patient-information-container');
        if (formContainer) {
            formContainer.insertBefore(errorContainer, formContainer.firstChild);
            errorContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    // ==================== SHOW SUCCESS MESSAGE HELPER ====================
    window.showPatientFormSuccess = function(message, data) {
        const existingMessage = document.querySelector('.patient-form-success-container');
        if (existingMessage) existingMessage.remove();

        const successContainer = document.createElement('div');
        successContainer.className = 'patient-form-success-container alert alert-success';
        successContainer.style.cssText = 'margin: 20px 0; padding: 15px; border-radius: 5px;';

        const successTitle = document.createElement('h5');
        successTitle.innerHTML = `<i class="fas fa-check-circle"></i> Success!`;
        successTitle.style.marginBottom = '10px';
        successContainer.appendChild(successTitle);

        const successMessage = document.createElement('p');
        successMessage.textContent = message;
        successMessage.style.marginBottom = '10px';
        successContainer.appendChild(successMessage);

        if (data) {
            const patientInfo = document.createElement('p');
            patientInfo.innerHTML = `<strong>Patient Code:</strong> ${data.patient_code}`;
            patientInfo.style.marginBottom = '0';
            successContainer.appendChild(patientInfo);
        }

        const formContainer = document.querySelector('.patient-information-container');
        if (formContainer) {
            formContainer.insertBefore(successContainer, formContainer.firstChild);
            successContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    if (DEBUG_MODE) console.log('✅ Patient Record API loaded');

})();