document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("slideshowTrack");
  if (!track) {
    console.error("slideshowTrack not found");
    return;
  }

  // clone once
  track.innerHTML += track.innerHTML;

  let position = 0;
  const speed = 1;
  const halfHeight = track.scrollHeight / 2;

  function loopScroll() {
    position += speed;

    if (position >= halfHeight) {
      position -= halfHeight;
    }


    track.style.transform = `translateY(-${position}px)`;
    requestAnimationFrame(loopScroll);
  }

  loopScroll();
  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();
  section6Animation();
  stackcarddentist();
});




function section2Animation() {
  const section = document.querySelector('.section2');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.1;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .1]
  });

  reveals.forEach(el => observer.observe(el));
}



function section3Animation() {
  const section = document.querySelector('.section3');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.1;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .1]
  });

  reveals.forEach(el => observer.observe(el));
}



function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;




      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.1;





      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1]
  });

  reveals.forEach(el => observer.observe(el));
}




function section6Animation() {
  const section = document.querySelector('.section6');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;




      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}

function stackcarddentist(){
    const cardWrappers = document.querySelectorAll('.doctor-card');
    
    function updateCards() {
        cardWrappers.forEach((wrapper, index) => {
            const card = wrapper.querySelector('.doctor');
            const rect = wrapper.getBoundingClientRect();
            const topValue = parseInt(getComputedStyle(wrapper).top);
            
            // Count how many cards are coming up and overlaying this card
            let cardsAbove = 0;
            let totalScrollProgress = 0;
            
            cardWrappers.forEach((otherWrapper, otherIndex) => {
                if (otherIndex > index) {
                    const otherRect = otherWrapper.getBoundingClientRect();
                    const otherTop = parseInt(getComputedStyle(otherWrapper).top);
                    
                    // Calculate how much the next card has scrolled into position
                    if (otherRect.top < window.innerHeight) {
                        const scrollDistance = window.innerHeight - otherTop;
                        const currentScroll = window.innerHeight - otherRect.top;
                        const scrollProgress = Math.max(0, Math.min(1, currentScroll / scrollDistance));
                        
                        if (otherRect.top <= otherTop) {
                            cardsAbove++;
                        }
                        
                        // Add the scroll progress for smooth scaling
                        totalScrollProgress += scrollProgress;
                    }
                }
            });
            
            // Apply smooth stacking effect based on scroll progress
            if (rect.top <= topValue) {
                // Smooth scale based on how much cards below have scrolled up
                const scale = Math.max(0.7, 1 - (totalScrollProgress * 0.05));
                const translateY = -(totalScrollProgress * 30);
                
                card.style.transform = `scale(${scale}) translateY(${translateY}px)`;
                card.style.transition = 'transform 0.1s ease-out';
                wrapper.style.zIndex = 100 - cardsAbove;
            } else {
                // Card hasn't reached sticky position yet
                card.style.transform = 'scale(1) translateY(0)';
                card.style.transition = 'transform 0.3s ease-out';
                wrapper.style.zIndex = 200 + index;
            }
        });
    }

    window.addEventListener('scroll', updateCards);
    window.addEventListener('resize', updateCards);
    updateCards();
}

stackcarddentist();