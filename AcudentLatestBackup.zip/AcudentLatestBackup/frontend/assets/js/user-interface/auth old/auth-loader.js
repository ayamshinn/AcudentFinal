let authLoaded = false; // Prevent double loading

function loadAuthModal() {
  const modalContainer = document.getElementById("authentication-modal-container");

  if (authLoaded) {
    // Already loaded → Just open modal
    document.getElementById('authentication-modal-container-id').style.display = 'flex';
    document.body.classList.add('modal-open');

    if (typeof initClinicStaffLogin === "function") {
      initClinicStaffLogin(); // Rebind if needed
    }

    return;
  }

  fetch("../user-interface/auth.html")
    .then(res => res.text())
    .then(html => {
      modalContainer.innerHTML = html;

      // Load clinic staff login API (backend logic)
      const scriptClinicAPI = document.createElement("script");
      scriptClinicAPI.src = "../../assets/js-api/auth/auth-clinic-staff-api.js";
      scriptClinicAPI.defer = true;

      scriptClinicAPI.onload = () => {
        if (typeof initClinicStaffLogin === "function") {
          initClinicStaffLogin(); // ✅ Attach login event
        }

        // Load auth.js (UI logic) AFTER API script
        const scriptAuth = document.createElement("script");
        scriptAuth.src = "../../assets/js/user-interface/auth.js";
        scriptAuth.defer = true;

        scriptAuth.onload = () => {
          authLoaded = true;

          if (typeof initAuthModal === "function") {
            initAuthModal();
          }

          // Open modal immediately after loading everything
          document.getElementById('authentication-modal-container-id').style.display = 'flex';
          document.body.classList.add('modal-open');
        };

        document.body.appendChild(scriptAuth);
      };

      document.body.appendChild(scriptClinicAPI);
    })
    .catch(err => console.error("Failed to load auth modal:", err));
}

// Attach click event to the Sign In button
document.addEventListener("DOMContentLoaded", () => {
  const signInBtn = document.querySelector('.btn-signin');
  signInBtn?.addEventListener('click', (e) => {
    e.preventDefault();
    loadAuthModal();
  });
});
