document.addEventListener("DOMContentLoaded", () => {

  faqFunction();
  section2Animation();
  section3Animation();
  section4Animation();
  section5Animation();
    section6Animation();




});

function faqFunction() {
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');

    question.addEventListener('click', () => {
      // Close other items
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove('active');
        }
      });

      // Toggle current item
      item.classList.toggle('active');
    });
  });
}



function section2Animation() {
  const section = document.querySelector('.section2');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.1;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.1;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.1;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.1, .2]
  });

  reveals.forEach(el => observer.observe(el));
}




function section3Animation() {
  const section = document.querySelector('.section3');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}



function section4Animation() {
  const section = document.querySelector('.section4');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}


function section5Animation() {
  const section = document.querySelector('.section5');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-left')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-right')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}


function section6Animation() {
  const section = document.querySelector('.section6');
  const reveals = section.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.2;



      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, .2]
  });

  reveals.forEach(el => observer.observe(el));
}


