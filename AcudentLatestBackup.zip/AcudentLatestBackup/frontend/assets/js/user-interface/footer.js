    document.addEventListener("DOMContentLoaded", () => {

footerAnimation();
    });



    function footerAnimation() {
  const section = document.querySelector('.section8');
  const reveals = section.querySelectorAll('.reveal');

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const el = entry.target;

      let requiredRatio = 0.2;

      if (el.classList.contains('reveal-header')) requiredRatio = 0.2;
      if (el.classList.contains('reveal-content')) requiredRatio = 0.3;


      if (entry.intersectionRatio >= requiredRatio) {
        el.classList.add('active');
        observer.unobserve(el);
      }
    });
  }, {
    threshold: [0.2, 0.3]
  });

  reveals.forEach(el => observer.observe(el));
}

