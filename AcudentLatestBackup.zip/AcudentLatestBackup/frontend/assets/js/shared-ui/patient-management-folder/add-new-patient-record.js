// ===================== ADD NEW PATIENT RECORD - FORM HANDLER =====================

function initAddNewPatientRecord() {
    console.log('🚀 Initializing Add New Patient Record');

    // ==================== HMO SECTION TOGGLE ====================
    const hmoRadios = document.querySelectorAll('input[name="hasHMO"]');
    const hmoDetailsSection = document.querySelector('.patient-information-hmo-information-container.d-none');

    hmoRadios.forEach(radio => {
        radio.addEventListener('change', () => {
            if (radio.value === 'yes' && radio.checked) {
                hmoDetailsSection.classList.remove('d-none');
                document.getElementById('HMOProvider')?.setAttribute('required', 'required');
                document.getElementById('MembershipID')?.setAttribute('required', 'required');
            } else if (radio.value === 'no' && radio.checked) {
                hmoDetailsSection.classList.add('d-none');
                document.getElementById('HMOProvider')?.removeAttribute('required');
                document.getElementById('MembershipID')?.removeAttribute('required');
                document.getElementById('HMOProvider').value = '';
                document.getElementById('MembershipID').value = '';
            }
        });
    });

    // ==================== AGE INPUT - TRIGGERS MINOR SECTION ====================
    const ageInput = document.getElementById('Age');

    function updateMinorSection(age) {
        const minorSection = document.querySelector('.patient-information-minor-patient-container');
        if (!minorSection) return;

        if (age !== null && age < 18) {
            minorSection.classList.remove('d-none');
            document.getElementById('guardian-fullname')?.setAttribute('required', 'required');
            document.getElementById('MContactNum')?.setAttribute('required', 'required');
            document.getElementById('RltoPatient')?.setAttribute('required', 'required');
            document.getElementById('GuardianEmail')?.setAttribute('required', 'required');
        } else {
            minorSection.classList.add('d-none');
            document.getElementById('guardian-fullname')?.removeAttribute('required');
            document.getElementById('MContactNum')?.removeAttribute('required');
            document.getElementById('RltoPatient')?.removeAttribute('required');
            document.getElementById('GuardianEmail')?.removeAttribute('required');

            ['guardian-fullname', 'MContactNum', 'RltoPatient', 'GuardianEmail'].forEach(id => {
                const field = document.getElementById(id);
                if (field) field.value = '';
            });
        }
    }

    if (ageInput) {
        ageInput.addEventListener('input', function () {
            const age = parseInt(this.value, 10);
            updateMinorSection(!isNaN(age) && age >= 0 ? age : null);
        });

        ageInput.addEventListener('change', function () {
            const age = parseInt(this.value, 10);
            updateMinorSection(!isNaN(age) && age >= 0 ? age : null);
        });
    }

    // ==================== PORTAL CONTEXT HELPER ====================
    // Determines the correct back page based on which portal loaded this page
    function getBackPage() {
    const origin = sessionStorage.getItem('patientFormOrigin');
    return origin === 'frontdesk'
        ? '../staff-ui/staff-frontdesk-subfolder/staff-frontdesk-patient-records.html'
        : '../admin-ui/admin-subfolder/admin-patient-management.html';
}

function navigateBack() {
    const backPage = getBackPage();
    sessionStorage.removeItem('patientFormOrigin'); // ✅ clean up
    if (typeof window.loadPage === 'function') {
        window.loadPage(backPage);
    } else {
        window.location.href = backPage;
    }
}

    // ==================== BACK BUTTON NAVIGATION ====================
    // If the button has an explicit data-page, honour it.
    // Otherwise fall back to hash-based portal detection so both
    // admin and frontdesk navigate to the correct list page.
    const backButtons = document.querySelectorAll('.head-btn');
    backButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const explicitUrl = btn.getAttribute('data-page');
            if (explicitUrl) {
                if (typeof window.loadPage === 'function') {
                    window.loadPage(explicitUrl);
                } else {
                    window.location.href = explicitUrl;
                }
                return;
            }
            navigateBack();
        });
    });

    // ==================== GLOBAL FORM DATA COLLECTION ====================
    window.collectPatientFormData = function () {
        console.log('📋 Collecting form data...');

        const ageInput = document.getElementById('Age');
        const ageValue = parseInt(ageInput?.value?.trim(), 10);

        const formData = {
            LastName:       document.getElementById('LastName')?.value?.trim()       || '',
            FirstName:      document.getElementById('FirstName')?.value?.trim()      || '',
            MiddleInitial:  document.getElementById('MiddleInitial')?.value?.trim()  || '',
            Gender:         document.getElementById('Gender')?.value                 || '',
            Birthdate:      document.getElementById('Birthdate')?.value?.trim()      || '',
            Age:            !isNaN(ageValue) ? ageValue                              : '',
            PhoneNumber:    document.getElementById('PhoneNumber')?.value?.trim()    || '',
            Email:          document.getElementById('Email')?.value?.trim()          || '',
            Address:        document.getElementById('Address')?.value?.trim()        || '',
            hasHMO:         document.querySelector('input[name="hasHMO"]:checked')?.value || 'no',
            HMOProvider:    document.getElementById('HMOProvider')?.value?.trim()    || '',
            MembershipID:   document.getElementById('MembershipID')?.value?.trim()   || '',
            'guardian-fullname': document.getElementById('guardian-fullname')?.value?.trim() || '',
            MContactNum:    document.getElementById('MContactNum')?.value?.trim()    || '',
            RltoPatient:    document.getElementById('RltoPatient')?.value?.trim()    || '',
            GuardianEmail:  document.getElementById('GuardianEmail')?.value?.trim()  || ''
        };

        console.log('📤 Form data collected:', formData);
        return formData;
    };

    // ==================== FORM SUBMISSION HANDLER ====================
    const saveButton     = document.querySelector('.new-btn-save');
    const cancelButton   = document.querySelector('.new-btn-cancel');
    const consentCheckbox = document.querySelector('.patient-consent-statement input[type="checkbox"]');

    if (saveButton) {
        saveButton.addEventListener('click', async (e) => {
            e.preventDefault();
            console.log('💾 Save button clicked');

            if (typeof window.createPatientRecord !== 'function') {
                window.showPatientFormErrors(['Error: Patient Record API not loaded. Please refresh the page.']);
                return;
            }

            if (!consentCheckbox?.checked) {
                window.showPatientFormErrors(['Please agree to the consent statement before proceeding.']);
                consentCheckbox?.focus();
                return;
            }

            saveButton.disabled = true;
            saveButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

            try {
                const patientData = window.collectPatientFormData();
                console.log('📤 Submitting patient data:', patientData);

                const validation = window.validatePatientData(patientData);
                if (!validation.isValid) {
                    console.error('❌ Validation failed:', validation.errors);
                    window.showPatientFormErrors(validation.errors);
                    saveButton.disabled = false;
                    saveButton.innerHTML = 'Submit';
                    return;
                }

                console.log('🚀 Calling createPatientRecord API...');
                const result = await window.createPatientRecord(patientData);
                console.log('📥 API response:', result);

                if (result.success) {
                    console.log('✅ Patient created successfully!');
                    window.showPatientFormSuccess(result.message, result.data);

                    setTimeout(() => {
                        resetPatientForm();
                    }, 2000);

                    // ✅ Navigate back to the correct list page for the active portal
                    setTimeout(() => {
                        navigateBack();
                    }, 3000);

                } else {
                    console.error('❌ API returned error:', result.message);
                    window.showPatientFormErrors([result.message]);
                    saveButton.disabled = false;
                    saveButton.innerHTML = 'Submit';
                }

            } catch (error) {
                console.error('❌ Form submission error:', error);
                window.showPatientFormErrors([error.message || 'An unexpected error occurred. Please try again.']);
                saveButton.disabled = false;
                saveButton.innerHTML = 'Submit';
            }
        });
    }

    // ==================== CANCEL BUTTON HANDLER ====================
    if (cancelButton) {
        cancelButton.addEventListener('click', (e) => {
            e.preventDefault();
            if (confirm('Are you sure you want to cancel? All unsaved changes will be lost.')) {
                resetPatientForm();
                // ✅ Navigate back to the correct list page for the active portal
                navigateBack();
            }
        });
    }

    // ==================== FORM RESET FUNCTION ====================
    function resetPatientForm() {
        document.querySelectorAll(
            '.patient-information-container input[type="text"], ' +
            '.patient-information-container input[type="email"], ' +
            '.patient-information-container input[type="tel"], ' +
            '.patient-information-container input[type="date"]'
        ).forEach(input => { input.value = ''; });

        document.querySelectorAll('.patient-information-container select').forEach(select => {
            select.selectedIndex = 0;
        });

        document.querySelectorAll('.patient-information-container input[type="radio"]').forEach(radio => {
            radio.checked = false;
        });

        if (consentCheckbox) consentCheckbox.checked = false;

        const hmoSection   = document.querySelector('.patient-information-hmo-information-container');
        const minorSection = document.querySelector('.patient-information-minor-patient-container');
        if (hmoSection   && !hmoSection.classList.contains('d-none'))   hmoSection.classList.add('d-none');
        if (minorSection && !minorSection.classList.contains('d-none')) minorSection.classList.add('d-none');

        document.querySelector('.patient-form-error-container')?.remove();
        document.querySelector('.patient-form-success-container')?.remove();

        if (saveButton) {
            saveButton.disabled = false;
            saveButton.innerHTML = 'Submit';
        }

        console.log('✅ Form reset complete');
    }

    // ==================== PHONE NUMBER FORMATTING ====================
    const phoneInputs = document.querySelectorAll('#PhoneNumber, #MContactNum');
    phoneInputs.forEach(input => {
        input.addEventListener('input', function (e) {
            e.target.value = e.target.value.replace(/[^0-9+\-() ]/g, '');
        });
    });

    console.log('✅ Add New Patient Record initialized');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAddNewPatientRecord);
} else {
    initAddNewPatientRecord();
}