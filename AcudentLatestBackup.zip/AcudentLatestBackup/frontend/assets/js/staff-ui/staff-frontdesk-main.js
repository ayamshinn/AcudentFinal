// ===================== FRONTDESK MAIN JS =====================
document.addEventListener('DOMContentLoaded', () => {
  const container = document.querySelector('.content-area');

  // ===== Function to load a page (reusable) =====
  window.loadPage = function (pageUrl, addToHistory = true) {
    fetch(pageUrl)
      .then(res => res.text())
      .then(html => {
        container.innerHTML = html;

        if (pageUrl.includes("dashboard"))        document.title = "Frontdesk Portal - Dashboard";
        else if (pageUrl.includes("appointments")) document.title = "Frontdesk Portal - Appointments";
        else if (pageUrl.includes("help"))         document.title = "Frontdesk Portal - Help";
        else if (pageUrl.includes("account"))      document.title = "Frontdesk Portal - My Account";
        else if (pageUrl.includes("records"))      document.title = "Frontdesk Portal - Patient Record";
        else if (pageUrl.includes("messages"))     document.title = "Frontdesk Portal - Messages";
        else if (pageUrl.includes("inventory"))    document.title = "Frontdesk Portal - Inventory Management";
        else if (pageUrl.includes("patient"))      document.title = "Frontdesk Portal - Patient Management";
        else                                        document.title = "Frontdesk Portal";

        if (addToHistory) {
          history.pushState({ pageUrl }, "", `#${pageUrl}`);
        }

        // Reset scroll to top
        window.scrollTo(0, 0);
        const contentArea = document.querySelector('.main-content-area-container');
        if (contentArea) contentArea.scrollTop = 0;

        // ✅ initPageScript FIRST so all button listeners are attached immediately
        initPageScript(pageUrl);

        // ✅ Dispatch pageLoaded AFTER — triggers the API loader script
        const pageLoadedEvent = new CustomEvent('pageLoaded', {
          detail: { pageUrl: pageUrl }
        });
        document.dispatchEvent(pageLoadedEvent);
      })
      .catch(err => console.error('Error loading page:', err));
  };

  // ===== Attach click events to all sidebar links =====
  document.querySelectorAll('a[data-page]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const pageUrl = link.getAttribute('data-page');
      loadPage(pageUrl);
    });
  });

  const initialPage = location.hash
    ? location.hash.substring(1)
    : '../staff-ui/staff-frontdesk-subfolder/staff-frontdesk-dashboard.html';
  loadPage(initialPage, false);

  window.addEventListener("popstate", (event) => {
    if (event.state && event.state.pageUrl) {
      loadPage(event.state.pageUrl, false);
    } else {
      loadPage('../staff-ui/staff-frontdesk-subfolder/staff-frontdesk-dashboard.html', false);
    }
  });
});


// ===================== PAGE SCRIPT INITIALIZER =====================
function initPageScript(pageUrl) {

  if (pageUrl.includes('staff-frontdesk-my-account.html')) {
    if (typeof initStaffFrontDeskMyAccountPage === 'function') {
      initStaffFrontDeskMyAccountPage();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-my-account.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskMyAccountPage();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('staff-frontdesk-dashboard.html')) {
    if (typeof initStaffFrontDeskDashboard === 'function') {
      initStaffFrontDeskDashboard();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-dashboard.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskDashboard();
      document.body.appendChild(script);
    }
  }

  // ============================== PATIENT RECORDS ==============================
  // ✅ No longer gated behind API availability.
  // Buttons (Add New Patient, tile/list toggle, search, filter, load more/less)
  // get their listeners attached immediately. Patient data loading is handled
  // gracefully inside the patient records script itself.
  if (pageUrl.includes('staff-frontdesk-patient-records.html')) {
    if (typeof initStaffFrontDeskPatientRecords === 'function') {
      initStaffFrontDeskPatientRecords();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-patient-records.js';
      script.onload = () => initStaffFrontDeskPatientRecords();
      document.body.appendChild(script);
    }
  }
// ============================== ADD NEW PATIENT ==============================
if (pageUrl.includes('add-new-patient-record.html')) {
  if (typeof initAddNewPatientRecord === 'function') {
    initAddNewPatientRecord();
  } else {
    const script = document.createElement('script');
    script.src = '../../assets/js/shared-ui/patient-management-folder/add-new-patient-record.js';
    script.onload = () => {
      if (typeof initAddNewPatientRecord === 'function') {
        initAddNewPatientRecord();
      } else {
        console.error('❌ initAddNewPatientRecord not found after script load');
      }
    };
    script.onerror = () => {
      console.error('❌ Failed to load add-new-patient-record.js');
      const container = document.querySelector('.patient-information-container');
      if (container) {
        container.innerHTML = `
          <div class="text-center py-5">
            <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
            <p class="text-danger">Failed to load the form. Please refresh the page.</p>
            <button class="btn btn-primary mt-3" onclick="location.reload()">
              <i class="fa-solid fa-rotate-right me-2"></i>Refresh Page
            </button>
          </div>`;
      }
    };
    document.body.appendChild(script);
  }
}

  // ============================== PATIENT DETAILED VIEW ==============================
  if (pageUrl.includes('staff-frontdesk-patient-records-detailed.html')) {
    if (typeof initStaffFrontDeskPatientRecordsDetailed === 'function') {
      initStaffFrontDeskPatientRecordsDetailed();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-patient-records-detailed.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskPatientRecordsDetailed();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('staff-frontdesk-appointments.html')) {
    if (typeof initStaffFrontDeskAppointments === 'function') {
      initStaffFrontDeskAppointments();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-appointments.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskAppointments();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('staff-frontdesk-messages.html')) {
    if (typeof initStaffFrontDeskMessages === 'function') {
      initStaffFrontDeskMessages();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-messages.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskMessages();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('staff-frontdesk-inventory-management.html')) {
    if (typeof initStaffFrontDeskInventoryManagement === 'function') {
      initStaffFrontDeskInventoryManagement();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-inventory-management.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskInventoryManagement();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('staff-frontdesk-help.html')) {
    if (typeof initStaffFrontDeskHelp === 'function') {
      initStaffFrontDeskHelp();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/staff-ui/staff-frontdesk-subfolder/staff-frontdesk-help.js';
      script.defer = true;
      script.onload = () => initStaffFrontDeskHelp();
      document.body.appendChild(script);
    }
  }
}