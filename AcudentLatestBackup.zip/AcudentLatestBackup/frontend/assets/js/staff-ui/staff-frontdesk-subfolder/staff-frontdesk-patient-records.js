// ===================== STAFF FRONTDESK PATIENT MANAGEMENT =====================

const FRONTDESK_PATIENT_DETAIL_PAGE = '../staff-ui/staff-frontdesk-subfolder/staff-frontdesk-patient-records-detailed.html';
const FRONTDESK_TILE_CONTAINER      = 'record-tile-view-id';
const FRONTDESK_LIST_BODY           = 'list-view-body-id';
const FRONTDESK_PATIENT_LIMIT       = 10;

let fdCurrentPage    = 1;
let fdCurrentSearch  = '';
let fdCurrentOrderBy = 'alphabetical';
let fdTotalPatients  = 0;
let fdAllLoaded      = false;

function initStaffFrontDeskPatientRecords() {
    const page = document.querySelector('#staff-frontdesk-patient-page-id');
    if (!page) return;
    console.log('Frontdesk Patient Management initialized ✅');

    // ===================== TOGGLE TILE / LIST VIEW =====================
    const toggleButtons = document.querySelectorAll('.toggle-button[data-target]');
    const sections      = document.querySelectorAll('.profile-box-main-container');

    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId      = btn.getAttribute('data-target');
            const targetSection = document.getElementById(targetId);
            if (!targetSection) return;

            sections.forEach(s => s.classList.add('hidden'));
            targetSection.classList.remove('hidden');

            toggleButtons.forEach(b => b.classList.remove('active-tab'));
            btn.classList.add('active-tab');
        });
    });

    // ===================== FILTER DROPDOWN =====================
    const filterBtn  = document.getElementById('filterDropdownBtn');
    const filterMenu = document.getElementById('filterDropdownMenu');

    if (filterBtn && filterMenu) {
        filterBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            filterMenu.style.display = filterMenu.style.display === 'none' ? 'block' : 'none';
        });

        document.addEventListener('click', () => {
            filterMenu.style.display = 'none';
        });

        document.querySelectorAll('.filter-option').forEach(opt => {
            opt.addEventListener('click', () => {
                fdCurrentOrderBy = opt.getAttribute('data-filter');
                fdCurrentPage    = 1;
                filterMenu.style.display = 'none';
                fdLoadPatients(true);
            });
        });
    }

    // ===================== SEARCH =====================
    const searchbar = document.querySelector('.record-searchbar');
    if (searchbar) {
        let debounceTimer;
        searchbar.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                fdCurrentSearch = this.value.trim();
                fdCurrentPage   = 1;
                fdLoadPatients(true);
            }, 400);
        });
    }

    // ===================== LOAD MORE / LESS =====================
    const loadMoreBtn = document.querySelector('.load-more');
    const loadLessBtn = document.querySelector('.load-less');

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
            if (!fdAllLoaded) {
                fdCurrentPage++;
                fdLoadPatients(false);
            }
        });
    }

    if (loadLessBtn) {
        loadLessBtn.addEventListener('click', () => {
            if (fdCurrentPage > 1) {
                fdCurrentPage--;
                fdLoadPatients(false);
            }
        });
    }

    // ===================== ADD NEW PATIENT =====================
document.querySelectorAll('.add-user-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const url = btn.getAttribute('data-page');
        if (!url) return;
        sessionStorage.setItem('patientFormOrigin', 'frontdesk'); // ✅ store context
        if (typeof window.loadPage === 'function') {
            window.loadPage(url);
        } else {
            window.location.href = url;
        }
    });
});

    // ===================== INITIAL LOAD =====================
    fdLoadPatients(true);
}

// ===================== CORE LOAD FUNCTION =====================
async function fdLoadPatients(reset = false) {
    if (reset) {
        fdCurrentPage = 1;
        fdAllLoaded   = false;
    }

    fdShowLoadingState();

    try {
        const result = await window.getAllPatients({
            search:   fdCurrentSearch,
            order_by: fdCurrentOrderBy,
            page:     fdCurrentPage,
            limit:    FRONTDESK_PATIENT_LIMIT
        });

        fdTotalPatients = result.total_count || 0;
        const patients  = result.data || [];

        fdAllLoaded = (fdCurrentPage * FRONTDESK_PATIENT_LIMIT) >= fdTotalPatients;

        fdRenderTileView(patients);
        fdRenderListView(patients);
        fdUpdateCountDisplay();
        fdUpdateLoadButtons();

    } catch (error) {
        console.error('Failed to load patients:', error);
        fdShowErrorState(error.message);
    }
}

// ===================== TILE VIEW RENDERER =====================
function fdRenderTileView(patients) {
    const tileRow = document.querySelector(`#${FRONTDESK_TILE_CONTAINER} .row`);
    if (!tileRow) return;

    if (patients.length === 0) {
        tileRow.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-user-slash fa-2x mb-3 text-muted"></i>
                <p class="text-muted">No patients found.</p>
            </div>`;
        return;
    }

    tileRow.innerHTML = patients.map(patient => {
        const name       = `${patient.first_name || ''} ${patient.last_name || ''}`.trim() || 'Unknown';
        const patientCode = patient.patient_code || 'N/A';
        const patientId  = patient.patient_id || '';
        const profilePic = patient.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg';

        return `
            <div class="col-12 col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6 col-profile-box">
                <div class="profile-box" tabindex="0"
                    data-target="${FRONTDESK_PATIENT_DETAIL_PAGE}"
                    data-id="${patientId}"
                    style="cursor:pointer;">
                    <div class="record-img-container">
                        <img src="${profilePic}"
                            alt="Profile Picture"
                            onerror="this.src='/Acudent/frontend/assets/images/default-pfp.jpg'">
                    </div>
                    <div class="info-container">
                        <h3>${name}</h3>
                        <span>${patientCode}</span>
                    </div>
                </div>
            </div>`;
    }).join('');

    // Attach click handlers after rendering
    tileRow.querySelectorAll('.profile-box').forEach(box => {
        box.addEventListener('click', () => {
            const url       = box.getAttribute('data-target');
            const patientId = box.getAttribute('data-id');
            if (!url) return;
            const dest = patientId ? `${url}?id=${encodeURIComponent(patientId)}` : url;
            if (typeof window.loadPage === 'function') {
                window.loadPage(dest);
            } else {
                window.location.href = dest;
            }
        });
    });
}

// ===================== LIST VIEW RENDERER =====================
function fdRenderListView(patients) {
    const listBody = document.getElementById(FRONTDESK_LIST_BODY);
    if (!listBody) return;

    if (patients.length === 0) {
        listBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4 text-muted">No patients found.</td>
            </tr>`;
        return;
    }

    listBody.innerHTML = patients.map(patient => {
        const name        = `${patient.first_name || ''} ${patient.last_name || ''}`.trim() || 'Unknown';
        const patientCode = patient.patient_code || 'N/A';
        const phone       = patient.phone  || 'N/A';
        const email       = patient.email  || 'N/A';
        const apptCount   = patient.total_appointments ?? 0;
        const patientId   = patient.patient_id || '';

        return `
            <tr>
                <td>${name}</td>
                <td>${patientCode}</td>
                <td>${phone}</td>
                <td>${email}</td>
                <td>
                    <div class="appointment-td-wrapper d-flex flex-row align-items-center">
                        <p class="mb-0">${apptCount}</p>
                        <button type="button"
                            class="ms-auto td-view-button"
                            data-target="${FRONTDESK_PATIENT_DETAIL_PAGE}"
                            data-id="${patientId}">
                            View Details
                        </button>
                    </div>
                </td>
            </tr>`;
    }).join('');

    // Attach click handlers after rendering
    listBody.querySelectorAll('.td-view-button').forEach(btn => {
        btn.addEventListener('click', () => {
            const url       = btn.getAttribute('data-target');
            const patientId = btn.getAttribute('data-id');
            if (!url) return;
            const dest = patientId ? `${url}?id=${encodeURIComponent(patientId)}` : url;
            if (typeof window.loadPage === 'function') {
                window.loadPage(dest);
            } else {
                window.location.href = dest;
            }
        });
    });
}

// ===================== COUNT DISPLAY =====================
function fdUpdateCountDisplay() {
    const countHeader = document.querySelector('.count-show-header');
    if (!countHeader) return;
    const showing = Math.min(fdCurrentPage * FRONTDESK_PATIENT_LIMIT, fdTotalPatients);
    countHeader.textContent = `Showing ${showing} of ${fdTotalPatients}`;
}

// ===================== LOADING STATE =====================
function fdShowLoadingState() {
    const tileRow = document.querySelector(`#${FRONTDESK_TILE_CONTAINER} .row`);
    if (tileRow) {
        tileRow.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-spinner fa-spin fa-2x mb-3" style="color:#9E5B08;"></i>
                <p class="text-muted">Loading patients...</p>
            </div>`;
    }

    const listBody = document.getElementById(FRONTDESK_LIST_BODY);
    if (listBody) {
        listBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <i class="fas fa-spinner fa-spin me-2" style="color:#9E5B08;"></i>
                    Loading patients...
                </td>
            </tr>`;
    }
}

// ===================== ERROR STATE =====================
function fdShowErrorState(message) {
    const tileRow = document.querySelector(`#${FRONTDESK_TILE_CONTAINER} .row`);
    if (tileRow) {
        tileRow.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-exclamation-triangle fa-2x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load patients: ${message}</p>
                <button class="btn btn-sm btn-outline-danger mt-2" onclick="fdLoadPatients(true)">
                    <i class="fas fa-redo me-1"></i> Retry
                </button>
            </div>`;
    }

    const listBody = document.getElementById(FRONTDESK_LIST_BODY);
    if (listBody) {
        listBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-danger py-4">
                    Failed to load patients.
                    <a href="#" onclick="fdLoadPatients(true); return false;">Retry</a>
                </td>
            </tr>`;
    }
}

// ===================== LOAD MORE/LESS BUTTON STATE =====================
function fdUpdateLoadButtons() {
    const loadMoreBtn = document.querySelector('.load-more');
    const loadLessBtn = document.querySelector('.load-less');

    if (loadMoreBtn) {
        loadMoreBtn.disabled      = fdAllLoaded;
        loadMoreBtn.style.opacity = fdAllLoaded ? '0.4' : '1';
    }
    if (loadLessBtn) {
        loadLessBtn.disabled      = fdCurrentPage <= 1;
        loadLessBtn.style.opacity = fdCurrentPage <= 1 ? '0.4' : '1';
    }
}

// ⚠️ Do NOT use DOMContentLoaded here.
// This script is loaded dynamically via script injection AFTER the DOM is ready.
// initStaffFrontDeskPatientRecords() is called explicitly by initPageScript()
// in staff-frontdesk-main.js once the API is confirmed available.