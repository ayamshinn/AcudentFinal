// ===================== MY ACCOUNT PAGE JS ===================== //
function initPatientTreatmentHistory() {
  console.log('Initializing Patient Treatment History...');

  // Function to setup dropdown functionality
  function setupDropdown(wrapperId, buttonId) {
    const wrapper = document.getElementById(wrapperId);
    const button = document.getElementById(buttonId);

    // Check if elements exist
    if (!wrapper || !button) {
      console.error(`Elements not found: ${wrapperId} or ${buttonId}`);
      return;
    }

    const dropdownItems = wrapper.querySelectorAll('.monthly-dropdown-item');
    const selectedSpan = button.querySelector('.selected-period');

    // Toggle dropdown on button click
    button.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();

      // Close all other dropdowns
      document.querySelectorAll('.monthly-wrapper-caret-down').forEach(w => {
        if (w !== wrapper) {
          w.classList.remove('active');
        }
      });

      // Toggle current dropdown
      wrapper.classList.toggle('active');
    });

    // Handle dropdown item selection
    dropdownItems.forEach(item => {
      item.addEventListener('click', function (e) {
        e.preventDefault();
        const selectedText = this.textContent;
        const selectedValue = this.getAttribute('data-value');

        // Update the selected text
        selectedSpan.textContent = selectedText;

        // Close the dropdown
        wrapper.classList.remove('active');

        // Log selection
        console.log(`Selected: ${selectedText} (value: ${selectedValue})`);

        // Call filter function
        filterTreatments();
      });
    });
  }

  // Setup all three dropdowns
  setupDropdown('treatment-type-wrapper', 'treatment-type-caret-btn');
  setupDropdown('status-wrapper', 'status-caret-btn');
  setupDropdown('time-period-wrapper', 'time-period-caret-btn');

  // Close dropdowns when clicking outside
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.monthly-wrapper-caret-down')) {
      document.querySelectorAll('.monthly-wrapper-caret-down').forEach(wrapper => {
        wrapper.classList.remove('active');
      });
    }
  });

  // Function to handle filtering based on selections
  function filterTreatments() {
    // Get all current selections
    const treatmentType = document.querySelector('#treatment-type-caret-btn .selected-period')?.textContent;
    const status = document.querySelector('#status-caret-btn .selected-period')?.textContent;
    const timePeriod = document.querySelector('#time-period-caret-btn .selected-period')?.textContent;

    console.log('Filter by:', {
      treatment: treatmentType,
      status: status,
      period: timePeriod
    });

    // Add your filtering logic here
    // For example, make an API call or filter table rows
  }

  const toggleButtons = document.querySelectorAll('.timeline-toggle-btn');

  // Check if buttons exist
  if (toggleButtons.length === 0) {
    console.error('Timeline toggle buttons not found');
  } else {
    console.log(`Found ${toggleButtons.length} toggle buttons`);

    toggleButtons.forEach(button => {
      button.addEventListener('click', function (e) {
        e.preventDefault();

        // Get the target section ID
        const targetId = this.getAttribute('data-target');
        const targetSection = document.getElementById(targetId);

        console.log(`Button clicked. Target: ${targetId}`);

        // Remove active-tab class from all buttons
        toggleButtons.forEach(btn => btn.classList.remove('active-tab'));

        // Add active-tab class to clicked button
        this.classList.add('active-tab');

        // Get both containers
        const timelineContainer = document.getElementById('treatment-history-timeline-overview-main-container');
        const tableContainer = document.getElementById('treatment-history-timeline-overview-table-container');

        // Get the title element
        const titleElement = document.getElementById('treatment-view-title');

        // Hide all sections by adding hidden class
        if (timelineContainer) timelineContainer.classList.add('hidden');
        if (tableContainer) tableContainer.classList.add('hidden');

        // Show the target section and update title
        if (targetSection) {
          targetSection.classList.remove('hidden');

          // Update title based on which view is active
          if (targetId === 'treatment-history-timeline-overview-main-container') {
            if (titleElement) titleElement.textContent = 'Treatment Timeline';
          } else if (targetId === 'treatment-history-timeline-overview-table-container') {
            if (titleElement) titleElement.textContent = 'Treatment List';
          }

          console.log(`Switched to: ${targetId}`);
        } else {
          console.error(`Target section not found: ${targetId}`);
        }
      });
    });

    // Initialize: Show the active tab's content on load
    const activeButton = document.querySelector('.timeline-toggle-btn.active-tab');

    // Get both containers
    const timelineContainer = document.getElementById('treatment-history-timeline-overview-main-container');
    const tableContainer = document.getElementById('treatment-history-timeline-overview-table-container');
    const titleElement = document.getElementById('treatment-view-title');

    console.log('Initialization check:', {
      activeButton: !!activeButton,
      timelineContainer: !!timelineContainer,
      tableContainer: !!tableContainer,
      titleElement: !!titleElement
    });

    if (activeButton) {
      const targetId = activeButton.getAttribute('data-target');
      const targetSection = document.getElementById(targetId);

      console.log(`Active button found. Target: ${targetId}`);
      console.log(`Target section exists: ${!!targetSection}`);

      // Hide all sections first
      if (timelineContainer) {
        timelineContainer.classList.add('hidden');
        console.log('Timeline container hidden');
      }
      if (tableContainer) {
        tableContainer.classList.add('hidden');
        console.log('Table container hidden');
      }

      // Show the active section and set initial title
      if (targetSection) {
        targetSection.classList.remove('hidden');
        console.log(`Target section (${targetId}) shown`);

        // Set initial title based on active view
        if (targetId === 'treatment-history-timeline-overview-main-container') {
          if (titleElement) titleElement.textContent = 'Treatment Timeline';
        } else if (targetId === 'treatment-history-timeline-overview-table-container') {
          if (titleElement) titleElement.textContent = 'Treatment List';
        }
      }
    } else {
      // DEFAULT: Show timeline view if no active button is set
      console.log('No active button found, showing default timeline view');
      if (tableContainer) tableContainer.classList.add('hidden');
      if (timelineContainer) timelineContainer.classList.remove('hidden');
      if (titleElement) titleElement.textContent = 'Treatment Timeline';
    }
  }


  const modal = document.getElementById("treatment-history-modal-container-id");
  const closeBtn = document.getElementById("treatment-history-close-modal");

  // Open modal (works for ALL buttons with the class)
  document.addEventListener("click", (e) => {
    const openBtn = e.target.closest(".open-treatment-history-modal");
    if (!openBtn) return;

    modal.classList.add("active");
  });

  // Close modal
  closeBtn.addEventListener("click", () => {
    modal.classList.remove("active");
  });

  // Optional: click outside modal to close
  modal.addEventListener("click", (e) => {
    if (e.target === modal) {
      modal.classList.remove("active");
    }
  });

  const modalTitle = document.getElementById("treatment-history-modal-title-inner-class");

  
}

document.addEventListener('DOMContentLoaded', initPatientTreatmentHistory);