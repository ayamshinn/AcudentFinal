function initDentistAppointmentReports() {
    const caretWrapper = document.querySelector('.monthly-wrapper-caret-down');
    const caretButton = caretWrapper.querySelector('.inventory-management-caret-button');
    const selectedPeriod = caretWrapper.querySelector('.selected-period');
    const dropdownItems = caretWrapper.querySelectorAll('.monthly-dropdown-item');

    // Toggle dropdown visibility
    caretButton.addEventListener('click', (e) => {
        e.stopPropagation(); // Prevent click from closing dropdown immediately
        caretWrapper.classList.toggle('active');
    });

    // Handle dropdown item clicks
    dropdownItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const newValue = item.textContent.trim();
            selectedPeriod.textContent = newValue; // Update button text
            caretWrapper.classList.remove('active'); // Close dropdown
        });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!caretWrapper.contains(e.target)) {
            caretWrapper.classList.remove('active');
        }
    });




    //Graph
    // Sample data (replace with real data from API or PHP)
    const appointmentData = {
        "2023-09": {  // Last month (September)
            labels: Array.from({ length: 30 }, (_, i) => i + 1),  // Days 1-30
            data: [5, 8, 12, 15, 20, 18, 25, 22, 30, 28, 35, 32, 40, 38, 45, 42, 50, 48, 55, 52, 60, 58, 65, 62, 70, 68, 75, 72, 80, 78]
        },
        "2023-10": {  // Current month (October)
            labels: Array.from({ length: 31 }, (_, i) => i + 1),  // Days 1-31
            data: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40]
        }
    };

    let chart; // Global variable for the chart instance

    // Function to initialize/update the chart
    function updateChart(selectedMonth) {
        const ctx = document.getElementById('appointment-report-dentist-id').getContext('2d');

        // Destroy existing chart if it exists
        if (chart) chart.destroy();

        // Determine last month (static demo)
        const currentData = appointmentData[selectedMonth];
        const lastMonthKey = selectedMonth === "2023-10" ? "2023-09" : "2023-09";
        const lastData = appointmentData[lastMonthKey];

        // Create the chart
        chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: currentData.labels,
                datasets: [
                    {
                        label: `Current Month (${selectedMonth})`,
                        data: currentData.data,
                        borderColor: '#28a745',
                        backgroundColor: 'rgba(40, 167, 69, 0.2)',
                        borderWidth: 3,
                        pointRadius: 4,
                        pointHoverRadius: 6,
                        tension: 0, // Sharp (tusok-tusok)
                        fill: false
                    },
                    {
                        label: `Previous Month (${lastMonthKey})`,
                        data: lastData.data,
                        borderColor: '#dc3545',
                        backgroundColor: 'rgba(220, 53, 69, 0.2)',
                        borderWidth: 3,
                        pointRadius: 0,
                        pointHoverRadius: 6,
                        tension: 0, // Sharp (tusok-tusok)
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            boxWidth: 20,
                            padding: 15
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const peak = Math.max(...context.dataset.data);
                                return `${context.dataset.label}: ${context.parsed.y} appointments (Peak: ${peak})`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Appointments'
                        },
                        ticks: {
                            stepSize: 10
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Day of Month'
                        }
                    }
                }
            }
        });
    }



    // Initialize on page load
    const monthSelect = document.getElementById('month-select-dentist-report');

    // Load initial chart (current month)
    updateChart(monthSelect.value);

    // Update chart on dropdown change
    monthSelect.addEventListener('change', (e) => {
        updateChart(e.target.value);
    });



    const modalContainer = document.getElementById('dentist-appointment-modal-container-id');
    const closeModalBtn = document.getElementById('dentist-appointment-report-close-modal');
    const viewButtons = document.querySelectorAll('.view-btn');

    viewButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            modalContainer.classList.add("active");
        });
    });

    // CLOSE MODAL (X button)
    closeModalBtn.addEventListener("click", () => {
        modalContainer.classList.remove("active");
    });

    // CLOSE MODAL (click outside)
    modalContainer.addEventListener("click", (e) => {
        if (e.target === modalContainer) {
            modalContainer.classList.remove("active");
        }
    });



    document.addEventListener("click", function (e) {
        const btn = e.target.closest("button[data-target]");
        if (!btn) return;

        const modal = document.querySelector(btn.dataset.target);
        if (!modal) return;

        modal.classList.add("active");

        const category = btn.dataset.category;
        if (category) updateModalContent(category);
    });


    const closeBtn = document.getElementById("dentist-close-appointments-btn");
    const modal = document.getElementById("dentist-appointments-modal-container-id");

    closeBtn.addEventListener("click", () => {
        modal.classList.remove("active"); // or display = "none"
    });

    modal.addEventListener("click", (e) => {
        if (e.target === modal) {
            modal.classList.remove("active");
        }
    })

    function updateModalContent(category) {
        const title = document.querySelector(".dentist-appointments-modal-title h3");
        const subtitle = document.querySelector(".dentist-appointments-modal-title p");

        const labels = {
            completed: "Completed Appointments",
            "no-show": "No Show Appointments",
            cancelled: "Cancelled Appointments"
        };

        title.innerHTML = `<i class="fa-solid fa-circle-info"></i> ${labels[category]}`;
        subtitle.textContent = "Overall summary of " + labels[category].toLowerCase();
    }




}

document.addEventListener('DOMContentLoaded', initDentistAppointmentReports);