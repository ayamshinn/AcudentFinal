// ===================== ADMIN PATIENT MANAGEMENT - DETAILED VIEW =====================

function initAdminPatientManagementDetailed() {
    const page = document.querySelector('#admin-patient-detail-view-page-id');
    if (!page) return;
    console.log('Patient Management Detailed initialized ✅');

    // ===================== GET PATIENT ID =====================
    // SPA uses sessionStorage since there are no URL params with loadPage()
    const patientId = sessionStorage.getItem('selectedPatientId');

    if (!patientId) {
        showDetailError('No patient selected. Please go back and select a patient.');
        return;
    }

    // ===================== LOAD PATIENT DATA =====================
    loadPatientDetail(patientId);

    // ===================== INIT MODAL + BUTTONS =====================
    DentalHistoryModal();
    buttons();
}

// ===================== LOAD PATIENT DATA FROM API =====================
async function loadPatientDetail(patientId) {
    try {
        showDetailLoading();

        const result = await window.getPatientById(patientId);

        if (!result.success || !result.data) {
            throw new Error('Failed to load patient data');
        }

        const patient = result.data;
        const info    = patient.personal_info   || {};
        const med     = patient.medical_history || null;

        // ── Profile picture ───────────────────────────────────────────
        const profileImg = document.querySelector('#patient-profile-img');
        if (profileImg) {
            profileImg.src = patient.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg';
            profileImg.onerror = () => {
                profileImg.src = '/Acudent/frontend/assets/images/default-pfp.jpg';
            };
        }

        // ── Profile card (ID badge, status, registered date) ─────────
        // ✅ FIX: targets the correct elements in the profile card section
        setField('#patient-code-display',       patient.patient_code || 'N/A');
        setField('#patient-status-display',     patient.status       || 'N/A');
        setField('#patient-registered-display', formatDate(patient.created_at));

        // Status badge color
        const statusEl = document.querySelector('#patient-status-display');
        if (statusEl) {
            statusEl.className = patient.status === 'Complete'
                ? 'text-success'
                : 'text-warning';
        }

        // ── General Information fields ────────────────────────────────
        // ✅ FIX: using actual HTML IDs from the detail page
        setField('#user-name',          info.full_name          || 'N/A');
        setField('#user-age-text',      info.age != null ? info.age + ' years old' : 'N/A');
        setField('#user-gender-text',   info.gender             || 'N/A');
        setField('#user-address-text',  info.email              || 'N/A'); // this field is labeled Email in HTML
        setField('#user-phone-text',    info.phone              || 'N/A');
        setField('#user-HMO-card',      patient.hmo
            ? (patient.hmo.is_valid ? 'Active' : 'Inactive')
            : 'None');

        // ── Full info modal fields ────────────────────────────────────
        setField('#user-birthday-text', formatDate(info.birthdate));
        setField('#user-name-modal',    info.full_name          || 'N/A');
        setField('#user-age-modal',     info.age != null ? info.age + ' years old' : 'N/A');

        // ── Medical Record fields ─────────────────────────────────────
        // ✅ FIX: pulls from patient_medical_history_tb via API
        setField('#patient-allergy-text',  med?.allergies             || 'None');
        setField('#MedicalConditions',     med?.medical_conditions    || 'None');
        setField('#Menstruation',          med?.menstruation_details  || 'None');
        setField('#patient-current-med',   med?.current_medications   || 'None');
        setField('#patient-past-med',      med?.past_surgeries        || 'None');

        // ── HMO section ───────────────────────────────────────────────
        const hmoSection = document.querySelector('#patient-hmo-section');
        if (hmoSection) {
            if (patient.hmo) {
                hmoSection.classList.remove('d-none');
                setField('#patient-hmo-provider',  patient.hmo.provider  || 'N/A');
                setField('#patient-hmo-member-id', patient.hmo.member_id || 'N/A');
                setField('#patient-hmo-valid',     patient.hmo.is_valid ? 'Valid' : 'Invalid');
            } else {
                hmoSection.classList.add('d-none');
            }
        }

        // ── Guardian section ──────────────────────────────────────────
        const guardianSection = document.querySelector('#patient-guardian-section');
        if (guardianSection) {
            if (patient.guardian) {
                guardianSection.classList.remove('d-none');
                setField('#guardian-name',         patient.guardian.name         || 'N/A');
                setField('#guardian-contact',      patient.guardian.contact      || 'N/A');
                setField('#guardian-relationship', patient.guardian.relationship || 'N/A');
                setField('#guardian-email',        patient.guardian.email        || 'N/A');
            } else {
                guardianSection.classList.add('d-none');
            }
        }

        // ── Page title ────────────────────────────────────────────────
        const pageTitle = document.querySelector('.patient-detail-name');
        if (pageTitle) pageTitle.textContent = info.full_name || 'Patient Details';

        console.log('✅ Patient detail loaded:', patient.patient_code);

        // ── Load dental history table ─────────────────────────────────
        populateTable(sampleDentalHistoryData);

    } catch (error) {
        console.error('Failed to load patient detail:', error);
        showDetailError(error.message);
    }
}

// ===================== HELPER: SET FIELD TEXT =====================
function setField(selector, value) {
    const el = document.querySelector(selector);
    if (el) {
        // If it's an input, set value; otherwise set textContent
        if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.value = value;
        } else {
            el.textContent = value;
        }
    }
}

// ===================== HELPER: FORMAT DATE =====================
function formatDate(dateStr) {
    if (!dateStr || dateStr === '0000-00-00' || dateStr === '0000-00-00 00:00:00') return 'N/A';
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return 'N/A';
        return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch {
        return dateStr;
    }
}

// ===================== LOADING STATE =====================
function showDetailLoading() {
    const nameEl = document.querySelector('.patient-detail-name');
    if (nameEl) nameEl.textContent = 'Loading...';

    // Show loading placeholder in inputs
    document.querySelectorAll('.form-control-user-info').forEach(el => {
        if (el.tagName === 'INPUT') el.value = 'Loading...';
    });
}

// ===================== ERROR STATE =====================
function showDetailError(message) {
    const container = document.querySelector('#admin-patient-detail-view-page-id');
    if (!container) return;

    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger m-4';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle me-2"></i>
        ${message}
        <button class="btn btn-sm btn-outline-danger ms-3"
                onclick="history.back()">
            <i class="fas fa-arrow-left me-1"></i> Go Back
        </button>`;

    const hr = container.querySelector('.hr');
    if (hr) hr.insertAdjacentElement('afterend', errorDiv);
}

// ===================== SAMPLE DENTAL HISTORY DATA =====================
const sampleDentalHistoryData = [
    {
        id: 1,
        date: "2023-10-15",
        services: "Cleaning",
        price: "₱500",
        dentist: "Dr. Santos",
        status: "Completed",
        remarks: "No issues found"
    },
    {
        id: 2,
        date: "2023-11-02",
        services: "Filling",
        price: "₱1,200",
        dentist: "Dr. Dela Cruz",
        status: "Upcoming",
        remarks: "Follow-up required"
    }
];

// ===================== POPULATE TABLE =====================
function populateTable(data) {
    const tbody = document.getElementById('patient-dental-history-tb-body');
    if (!tbody) return;

    tbody.innerHTML = '';

    if (!data.length) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted py-4">No dental history records found.</td>
            </tr>`;
        return;
    }

    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.date}</td>
            <td>${row.services}</td>
            <td>${row.price}</td>
            <td>${row.dentist}</td>
            <td>${row.status}</td>
            <td>
                <button class="view-btn btn btn-sm" data-id="${row.id}">View</button>
            </td>
        `;
        tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.view-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const rowId   = e.target.getAttribute('data-id');
            const rowData = data.find(r => r.id == rowId);
            if (rowData) openDentalHistoryModal(rowData);
        });
    });
}

// ===================== DENTAL HISTORY MODAL =====================
function DentalHistoryModal() {
    const modal        = document.querySelector('.dental-history-modal-container');
    const closeButtons = document.querySelectorAll('.dental-history-modal-close-button');

    if (!modal) return;

    window.openDentalHistoryModal = function(rowData) {
        const remarksEl = modal.querySelector('#remarks-of-patient');
        const notesEl   = modal.querySelector('#notes-of-patient');
        if (remarksEl) remarksEl.value   = rowData.remarks || '';
        if (notesEl)   notesEl.value     = rowData.notes   || '';
        modal.classList.add('active');
    };

    closeButtons.forEach(btn => {
        btn.addEventListener('click', () => modal.classList.remove('active'));
    });

    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
    });
}

// ===================== BUTTONS =====================
function buttons() {
    document.querySelectorAll('.back-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            sessionStorage.removeItem('selectedPatientId');
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                window.location.href = url;
            }
        });
    });

    document.querySelectorAll('.patient-view-more-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                window.location.href = url;
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', initAdminPatientManagementDetailed);