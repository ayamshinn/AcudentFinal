// ===================== ADMIN DENTIST DETAILED VIEW =====================
// Displays specific dentist information based on dentist_id from sessionStorage

// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.dentistDetailedLoaded) {
    console.log('Dentist Detailed already loaded, skipping...');
} else {
    window.dentistDetailedLoaded = true;
    initAdminDentistManagementDetailed();
}

// ===================== MAIN INIT FUNCTION =====================
async function initAdminDentistManagementDetailed() {
    const page = document.querySelector('#admin-dentist-detail-view-page-id');
    if (!page) {
        console.log('Dentist detail page not found in DOM');
        return;
    }
    
    console.log('✅ Dentist Management Detailed initialized');

    // ✅ GET DENTIST ID FROM SESSION STORAGE
    const dentistId = sessionStorage.getItem('selectedDentistId');
    
    if (!dentistId) {
        console.error('❌ No dentist ID found in session storage');
        showError('No dentist selected. Redirecting back...');
        
        // Redirect back to dentist list after 2 seconds
        setTimeout(() => {
            if (typeof window.loadPage === 'function') {
                window.loadPage('../admin-ui/admin-subfolder/admin-dentist-management.html');
            }
        }, 2000);
        return;
    }

    console.log('📋 Dentist ID from session storage:', dentistId);

    // Load dentist data
    await loadDentistData(dentistId);
    
    // Initialize buttons
    initButtons();
    
    // Initialize modals and other functions
    initDentalHistoryModal();
    loadDentalHistory();
}

// ===================== LOAD DENTIST DATA =====================
async function loadDentistData(dentistId) {
    try {
        console.log('📤 Loading dentist data for ID:', dentistId);
        
        // Show loading state
        showLoadingState();
        
        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getDentistById !== 'function') {
            throw new Error('Dentist API is not available. Please refresh the page.');
        }
        
        // Fetch dentist data
        const response = await window.getDentistById(dentistId);
        
        if (!response.success || !response.data) {
            throw new Error('Failed to load dentist data');
        }
        
        const dentist = response.data;
        
        // Debug dentist data
        debugDentistData(dentist);
        
        console.log('📥 Dentist data loaded:', dentist);
        
        // Populate the page with dentist data
        populateDentistInfo(dentist);
        
        // Hide loading state
        hideLoadingState();
        
    } catch (error) {
        console.error('❌ Error loading dentist data:', error);
        showError('Failed to load dentist information: ' + error.message);
        hideLoadingState();
    }
}

// ===================== DEBUG DENTIST DATA =====================
function debugDentistData(dentist) {
    console.log('=== DENTIST DATA DEBUG ===');
    console.log('Full dentist object:', dentist);
    console.log('Profile Picture:', dentist.profile_picture);
    console.log('Start Date:', dentist.professional_info?.start_date);
    console.log('Schedule:', dentist.schedule);
    console.log('Personal Info:', dentist.personal_info);
    console.log('Professional Info:', dentist.professional_info);
    console.log('========================');
}

// ===================== POPULATE DENTIST INFO =====================
function populateDentistInfo(dentist) {
    console.log('📝 Populating dentist info...');
    
    // ==================== PROFILE PICTURE ====================
    const profileImg = document.querySelector('.user-information-profile-img img');
    if (profileImg) {
        const profilePicture = dentist.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg';
        profileImg.src = profilePicture;
        profileImg.alt = dentist.personal_info.full_name;
        console.log('📸 Profile picture set:', profilePicture);
    }
    
    // ==================== DENTIST ID ====================
    const dentistIdSpan = document.querySelector('.user-information-profile-id');
    if (dentistIdSpan) {
        dentistIdSpan.textContent = dentist.dentist_code || 'N/A';
    }
    
    // ==================== START DATE (REGISTERED DATE REPLACEMENT) ====================
    const startDateSpan = document.getElementById('dentist-start-date');
    if (startDateSpan) {
        if (dentist.professional_info?.start_date) {
            const startDate = new Date(dentist.professional_info.start_date);
            const formattedDate = startDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            startDateSpan.textContent = formattedDate;
            console.log('📅 Start date set:', formattedDate);
        } else {
            startDateSpan.textContent = 'Not set';
            console.warn('⚠️ No start date available');
        }
    }
    
    // ==================== GENERAL INFORMATION ====================
    const userName = document.getElementById('user-name');
    if (userName) userName.value = dentist.personal_info?.full_name || 'N/A';
    
    const birthDate = document.getElementById('birth-date');
    if (birthDate) birthDate.value = dentist.personal_info?.birthdate || '';
    
    const userAge = document.getElementById('user-age-text');
    if (userAge) {
        const age = calculateAge(dentist.personal_info?.birthdate);
        userAge.value = age !== 'N/A' ? age + ' years old' : 'N/A';
    }
    
    const userGender = document.getElementById('user-gender-text');
    if (userGender) userGender.value = dentist.personal_info?.gender || 'Not specified';
    
    const userEmail = document.getElementById('user-address-text');
    if (userEmail) userEmail.value = dentist.personal_info?.email || 'Not provided';
    
    const userPhone = document.getElementById('user-phone-text');
    if (userPhone) userPhone.value = dentist.personal_info?.phone || 'N/A';
    
    // ==================== WORK DETAILS ====================
    
    // Check if schedule is already in the dentist object
    if (dentist.schedule && dentist.schedule.length > 0) {
        console.log('📊 Using schedule from dentist data');
        populateScheduleFromData(dentist.schedule);
    } else {
        console.log('📊 Fetching schedule separately');
        // Fallback: Fetch schedule separately
        fetchDentistSchedule(dentist.staff_profile_id);
    }
    
    const position = document.getElementById('working-assistant');
    if (position) position.value = dentist.professional_info?.position || 'Dentist';
    
    const specialization = document.getElementById('Specialization');
    if (specialization) specialization.value = dentist.professional_info?.specialization || 'General Dentistry';
    
    const licenseNo = document.getElementById('license-no');
    if (licenseNo) licenseNo.value = dentist.professional_info?.license_number || 'N/A';
    
    console.log('✅ Dentist info populated successfully');
}

// ===================== POPULATE SCHEDULE FROM DATA =====================
function populateScheduleFromData(schedule) {
    console.log('📅 Populating schedule from data:', schedule);
    
    // Get working days
    const workingDays = schedule
        .filter(s => s.is_working)
        .map(s => s.day)
        .join(', ');
    
    const workingDaysInput = document.getElementById('user-working-days');
    if (workingDaysInput) {
        workingDaysInput.value = workingDays || 'Not set';
        console.log('Working days set:', workingDays);
    }
    
    // Get working hours from first working day
    const firstWorkingDay = schedule.find(s => s.is_working);
    if (firstWorkingDay) {
        const workingTime = document.getElementById('user-working-time');
        if (workingTime) {
            const timeString = `${firstWorkingDay.start_time} - ${firstWorkingDay.end_time}`;
            workingTime.value = timeString;
            console.log('Working hours set:', timeString);
        }
    } else {
        const workingTime = document.getElementById('user-working-time');
        if (workingTime) {
            workingTime.value = 'Not set';
            console.warn('⚠️ No working days found in schedule');
        }
    }
}

// ===================== FETCH DENTIST SCHEDULE =====================
async function fetchDentistSchedule(staffProfileId) {
    try {
        console.log('📡 Fetching schedule for staff profile ID:', staffProfileId);
        
        const response = await fetch(`/Acudent/backend/api/staff/get-staff-schedule.php?staff_profile_id=${staffProfileId}`);
        const result = await response.json();
        
        console.log('📥 Schedule response:', result);
        
        if (result.success && result.data) {
            const schedule = result.data;
            populateScheduleFromData(schedule);
        } else {
            console.warn('⚠️ No schedule found or API error');
            // No schedule found
            const workingDaysInput = document.getElementById('user-working-days');
            if (workingDaysInput) workingDaysInput.value = 'Not set';
            
            const workingTime = document.getElementById('user-working-time');
            if (workingTime) workingTime.value = 'Not set';
        }
    } catch (error) {
        console.error('❌ Failed to fetch schedule:', error);
        // Set default values
        const workingDaysInput = document.getElementById('user-working-days');
        if (workingDaysInput) workingDaysInput.value = 'Not available';
        
        const workingTime = document.getElementById('user-working-time');
        if (workingTime) workingTime.value = 'Not available';
    }
}

// ===================== HELPER: CALCULATE AGE =====================
function calculateAge(birthdate) {
    if (!birthdate) return 'N/A';
    
    const birth = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
}

// ===================== SHOW/HIDE LOADING STATE =====================
// ===================== SHOW/HIDE LOADING STATE =====================
function showLoadingState() {
    const infoWrapper = document.querySelector('.info-wrapper');
    if (infoWrapper) {
        infoWrapper.style.opacity = '0.6';
        infoWrapper.style.transition = 'opacity 0.3s ease';
    }
}

function hideLoadingState() {
    const infoWrapper = document.querySelector('.info-wrapper');
    if (infoWrapper) {
        infoWrapper.style.opacity = '1';
    }
}
// ===================== INITIALIZE BUTTONS =====================
function initButtons() {
    // ==================== BACK BUTTON ====================
    const backButtons = document.querySelectorAll('.back-btn');
    backButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
                window.location.href = url;
            }
        });
    });
    
    // ==================== VIEW MORE BUTTON ====================
    const viewMoreBtns = document.querySelectorAll('.patient-view-more-btn');
    viewMoreBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            // ✅ DENTIST ID ALREADY IN SESSION STORAGE, JUST NAVIGATE
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== LOAD DENTAL HISTORY =====================
function loadDentalHistory() {
    // Sample data for dental history table
    const sampleDentalHistoryData = [
        {
            id: 1,
            date: "2023-10-15",
            services: "Cleaning",
            patientName: "Dracy Malibu",
            patientId: "P-1005",
            status: "Completed",
            remarks: "Patient was cooperative. Standard cleaning procedure completed.",
            notes: "Schedule next cleaning in 6 months."
        },
        {
            id: 2,
            date: "2023-11-02",
            services: "Filling",
            patientName: "Jane Smith",
            patientId: "P-1006",
            status: "Upcoming",
            remarks: "Cavity found in molar #14.",
            notes: "Patient requested morning appointment."
        },
        {
            id: 3,
            date: "2023-12-20",
            services: "Extraction",
            patientName: "John Doe",
            patientId: "P-1007",
            status: "Completed",
            remarks: "Wisdom tooth extraction completed successfully.",
            notes: "Prescribed pain medication. Follow-up in 1 week."
        }
    ];
    
    populateDentalHistoryTable(sampleDentalHistoryData);
}

// ===================== POPULATE DENTAL HISTORY TABLE =====================
function populateDentalHistoryTable(data) {
    const tbody = document.getElementById('patient-dental-history-tb-body-doc-side');
    if (!tbody) {
        console.error('❌ Dental history table body not found!');
        return;
    }
    
    tbody.innerHTML = ''; // Clear existing rows
    
    if (!data || data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <i class="fa-solid fa-inbox fa-2x mb-2 text-muted"></i>
                    <p class="text-muted">No dental history records found.</p>
                </td>
            </tr>
        `;
        return;
    }
    
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.date}</td>
            <td>${row.services}</td>
            <td>${row.patientName}</td>
            <td>${row.patientId}</td>
            <td><span class="badge ${getStatusBadgeClass(row.status)}">${row.status}</span></td>
            <td><button class="view-btn btn btn-sm btn-primary" data-id="${row.id}">View</button></td>
        `;
        tbody.appendChild(tr);
    });
    
    // Attach event listeners to view buttons
    attachDentalHistoryViewButtons(data);
}

// ===================== GET STATUS BADGE CLASS =====================
function getStatusBadgeClass(status) {
    switch (status.toLowerCase()) {
        case 'completed':
            return 'bg-success';
        case 'upcoming':
            return 'bg-warning text-dark';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// ===================== ATTACH DENTAL HISTORY VIEW BUTTONS =====================
function attachDentalHistoryViewButtons(data) {
    const viewButtons = document.querySelectorAll('.view-btn');
    viewButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const rowId = e.target.getAttribute('data-id');
            const rowData = data.find(row => row.id == rowId);
            if (rowData) {
                openDentalHistoryModal(rowData);
            }
        });
    });
}

// ===================== DENTAL HISTORY MODAL =====================
function initDentalHistoryModal() {
    const modal = document.querySelector('.dental-history-modal-container');
    const closeModalBtns = document.querySelectorAll('.dental-history-modal-close-button');
    
    if (!modal) {
        console.warn('⚠️ Dental history modal not found');
        return;
    }
    
    // Close modal handlers
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            modal.classList.remove('active');
        });
    });
    
    // Close on outside click
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
    
    // Define global function to open modal
    window.openDentalHistoryModal = function(rowData) {
        const remarksElement = modal.querySelector('#remarks-of-patient');
        const notesElement = modal.querySelector('#notes-of-patient');
        
        if (remarksElement) {
            remarksElement.value = rowData.remarks || 'No remarks available.';
        }
        
        if (notesElement) {
            notesElement.value = rowData.notes || 'No notes available.';
        }
        
        modal.classList.add('active');
    };
}

// ===================== SHOW ERROR =====================
function showError(message) {
    console.error('❌ Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP =====================
window.cleanupDentistDetailed = function() {
    delete window.dentistDetailedLoaded;
    delete window.openDentalHistoryModal;
    
    // ✅ CLEAR SESSION STORAGE ON PAGE CHANGE
    sessionStorage.removeItem('selectedDentistId');
    
    console.log('🧹 Dentist Detailed cleaned up');
};

// ===================== HANDLE DOM CONTENT LOADED =====================
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (!window.dentistDetailedLoaded) {
            initAdminDentistManagementDetailed();
        }
    });
} else {
    // DOM already loaded
    if (!window.dentistDetailedLoaded) {
        initAdminDentistManagementDetailed();
    }
}