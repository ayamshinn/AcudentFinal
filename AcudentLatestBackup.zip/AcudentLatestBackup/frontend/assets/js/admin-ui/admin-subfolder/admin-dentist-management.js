// ===================== ADMIN DENTIST MANAGEMENT PAGE HANDLER =====================
// Handles dentist listing page with tile/list view toggle and data loading



// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.dentistManagementLoaded) {
    console.log('Dentist Management already loaded, skipping...');
} else {
    window.dentistManagementLoaded = true;
    
    initAdminDentistManagement();
}

// ===================== INITIALIZE DENTIST MANAGEMENT =====================
function initAdminDentistManagement() {
    const page = document.querySelector('#admin-dentist-page-id');
    if (!page) {
        console.log('Dentist page not found in DOM');
        return;
    }
    

    // ===================== INITIALIZE VIEW TOGGLE ===================== //
    const toggleButtons = document.querySelectorAll('.toggle-button');
    const sections = document.querySelectorAll('.profile-box-main-container');

    if (!toggleButtons.length || !sections.length) {
        console.warn('No toggle elements found.');
        return;
    }

    // ===================== TOGGLE MENU / LIST VIEW ===================== //
    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            const targetSection = document.getElementById(targetId);

            if (!targetSection) return;

            // Hide all sections
            sections.forEach(section => section.classList.add('hidden'));
            // Show selected section
            targetSection.classList.remove('hidden');

            // Update button styles
            toggleButtons.forEach(b => b.classList.remove('active-tab'));
            btn.classList.add('active-tab');

            // Load data for the active view
            if (targetId === 'record-tile-view-id') {
                loadDentistsTileView();
            } else if (targetId === 'record-list-view-id') {
                loadDentistsListView();
            }
        });
    });

    // ===================== SEARCH FUNCTIONALITY ===================== //
    const searchBar = document.querySelector('.record-searchbar');
    if (searchBar) {
        searchBar.addEventListener('input', debounce(function() {
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadDentistsTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadDentistsListView();
            }
        }, 500));
    }

    // ===================== FILTER DROPDOWN ===================== //
    const filterBtn = document.getElementById('filterDropdownBtn');
    const filterMenu = document.getElementById('filterDropdownMenu');
    
    if (filterBtn && filterMenu) {
        filterBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            const isVisible = filterMenu.style.display === 'block';
            filterMenu.style.display = isVisible ? 'none' : 'block';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!filterBtn.contains(event.target) && !filterMenu.contains(event.target)) {
                filterMenu.style.display = 'none';
            }
        });
    }

    // ===================== FILTER OPTIONS ===================== //
    const filterOptions = document.querySelectorAll('.filter-option');
    filterOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Update active state
            filterOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Close dropdown
            if (filterMenu) {
                filterMenu.style.display = 'none';
            }

            // Reload data with new filter
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadDentistsTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadDentistsListView();
            }
        });
    });

    // ===================== ADD NEW DENTIST BUTTON ===================== //
    const dentistAddnewRecord = document.querySelectorAll('.add-user-btn');
    dentistAddnewRecord.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            if (!url) return;

            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

    // ===================== LOAD INITIAL DATA ===================== //
    // Load tile view by default - only after API is confirmed ready
    // The API check is already done in waitForDentistAPI(), so we can safely load now
    if (typeof window.getAllDentists === 'function') {
        loadDentistsTileView();
    } else {
        console.warn('⚠️ API check passed but function not available, showing error');
        showErrorInViews('Failed to initialize. Please refresh the page.');
    }
}

// ===================== LOAD DENTISTS - TILE VIEW ===================== //
async function loadDentistsTileView() {
    const container = document.querySelector('.profile-box-container');
    
    if (!container) {
        console.error('❌ Tile view container not found');
        return;
    }

    try {
        // Show loading state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3 text-muted">Loading dentists...</p>
            </div>
        `;


        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllDentists !== 'function') {
            throw new Error('Dentist API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch dentists
        const response = await window.getAllDentists({
            search: searchValue,
            order_by: activeFilter
        });

        const dentists = response.data || [];
        
        // Clear loading state and existing content
        container.innerHTML = '';

        // Check if dentists exist
        if (dentists.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                    <p class="text-muted">No dentists found.</p>
                </div>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through dentists and create cards
        dentists.forEach(dentist => {
            const formatted = window.formatDentistForDisplay(dentist);
            const profilePicture = window.getDentistProfilePicture(dentist);

            const colDiv = document.createElement('div');
            colDiv.className = 'col-12 col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6 col-profile-box';
            
            colDiv.innerHTML = `
                <div class="profile-box" tabindex="0"
                    data-page="../admin-ui/admin-subfolder/admin-dentist-management-detailed.html"
                    data-id="${formatted.id}">
                    <div class="record-img-container">
                        <img data-id="profile-img-id" src="${profilePicture}" alt="${formatted.name}">
                    </div>
                    <div class="info-container">
                        <h3 data-id="information-dentist-record-name-id">${formatted.name}</h3>
                        <span data-id="information-dentist-record-dID-id">${formatted.code}</span>
                    </div>
                </div>
            `;
            
            container.appendChild(colDiv);
        });

        // Add click handlers to new boxes
        attachDentistBoxHandlers();

        // Update count display
        updateCountDisplay(dentists.length, response.total_count);


    } catch (error) {
        console.error('❌ Error loading dentists (Tile View):', error);
        
        // Show error state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load dentists. Please try again.</p>
                <button class="btn btn-primary mt-3" onclick="loadDentistsTileView()">
                    <i class="fa-solid fa-rotate-right me-2"></i>Retry
                </button>
            </div>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load dentists. Please try again.');
    }
}

// ===================== LOAD DENTISTS - LIST VIEW ===================== //
async function loadDentistsListView() {
    const tbody = document.getElementById('list-view-body-id');
    
    if (!tbody) {
        console.error('❌ List view tbody not found');
        return;
    }

    try {
        // Show loading state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading dentists...</p>
                </td>
            </tr>
        `;


        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllDentists !== 'function') {
            throw new Error('Dentist API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch dentists
        const response = await window.getAllDentists({
            search: searchValue,
            order_by: activeFilter
        });

        const dentists = response.data || [];
        
        // Clear loading state and existing content
        tbody.innerHTML = '';

        // Check if dentists exist
        if (dentists.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                        <p class="text-muted">No dentists found.</p>
                    </td>
                </tr>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through dentists and create rows
        dentists.forEach(dentist => {
            const formatted = window.formatDentistForDisplay(dentist);

            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${formatted.name}</td>
                <td>${formatted.code}</td>
                <td>${formatted.email}</td>
                <td>${formatted.phone}</td>
                <td>
                    <div class="appointment-td-wrapper d-flex flex-row align-items-center">
                        <button type="button" class="td-view-button"
                            data-page="../admin-ui/admin-subfolder/admin-dentist-management-detailed.html"
                            data-id="${formatted.id}">
                            View Details
                        </button>
                    </div>
                </td>
            `;
            
            tbody.appendChild(row);
        });

        // Add click handlers to view buttons
        attachViewButtonHandlers();

        // Update count display
        updateCountDisplay(dentists.length, response.total_count);


    } catch (error) {
        console.error('❌ Error loading dentists (List View):', error);
        
        // Show error state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">Failed to load dentists. Please try again.</p>
                    <button class="btn btn-primary mt-3" onclick="loadDentistsListView()">
                        <i class="fa-solid fa-rotate-right me-2"></i>Retry
                    </button>
                </td>
            </tr>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load dentists. Please try again.');
    }
}

// ===================== ATTACH HANDLERS TO DENTIST BOXES (TILE VIEW) ===================== //
function attachDentistBoxHandlers() {
    const dentistBoxes = document.querySelectorAll('.profile-box');
    dentistBoxes.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            const dentistId = box.getAttribute('data-id');
            
            if (!url) return;
            
            // ✅ STORE DENTIST ID IN SESSION STORAGE
            if (dentistId) {
                sessionStorage.setItem('selectedDentistId', dentistId);
                console.log('✅ Stored dentist ID in session:', dentistId);
            }
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== ATTACH HANDLERS TO VIEW BUTTONS (LIST VIEW) ===================== //
function attachViewButtonHandlers() {
    const viewButtons = document.querySelectorAll('.td-view-button');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            const dentistId = btn.getAttribute('data-id');
            
            if (!url) return;
            
            // ✅ STORE DENTIST ID IN SESSION STORAGE
            if (dentistId) {
                sessionStorage.setItem('selectedDentistId', dentistId);
                console.log('✅ Stored dentist ID in session:', dentistId);
            }
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== UPDATE COUNT DISPLAY ===================== //
function updateCountDisplay(showing, total) {
    const countShowHeader = document.querySelector('.count-show-header');
    if (countShowHeader) {
        countShowHeader.textContent = `Showing ${showing} of ${total}`;
    }
}

// ===================== SHOW ERROR IN VIEWS ===================== //
function showErrorInViews(message) {
    // Show error in tile view
    const tileContainer = document.querySelector('.profile-box-container');
    if (tileContainer) {
        tileContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">${message}</p>
            </div>
        `;
    }
    
    // Show error in list view
    const listContainer = document.getElementById('list-view-body-id');
    if (listContainer) {
        listContainer.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">${message}</p>
                </td>
            </tr>
        `;
    }
    
    updateCountDisplay(0, 0);
}

// ===================== DEBOUNCE HELPER ===================== //
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===================== SHOW ERROR MESSAGE ===================== //
function showError(message) {
    console.error('Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP ON PAGE CHANGE =====================
window.cleanupDentistManagement = function() {
    delete window.dentistManagementLoaded;
};