// ===================== ADMIN ASSISTANT MANAGEMENT PAGE HANDLER =====================
// Handles assistant listing page with tile/list view toggle and data loading

// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.assistantManagementLoaded) {
    console.log('Assistant Management already loaded, skipping...');
} else {
    window.assistantManagementLoaded = true;
    
    initAdminStaffAssistantManagement();
}

// ===================== INITIALIZE ASSISTANT MANAGEMENT =====================
function initAdminStaffAssistantManagement() {
    const page = document.querySelector('#admin-staff-assistant-page-id');
    if (!page) {
        console.log('Assistant page not found in DOM');
        return;
    }
    
    console.log('Assistant Management initialized ✅');

    // ✅ REMOVED FULL-SCREEN LOADING - Using inline loading states instead
    // showPageLoadingScreen();

    // ===================== INITIALIZE VIEW TOGGLE ===================== //
    const toggleButtons = document.querySelectorAll('.toggle-button');
    const sections = document.querySelectorAll('.profile-box-main-container');

    if (!toggleButtons.length || !sections.length) {
        console.warn('No toggle elements found.');
        return;
    }

    // ===================== TOGGLE MENU / LIST VIEW ===================== //
    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            const targetSection = document.getElementById(targetId);

            if (!targetSection) return;

            // Hide all sections
            sections.forEach(section => section.classList.add('hidden'));
            // Show selected section
            targetSection.classList.remove('hidden');

            // Update button styles
            toggleButtons.forEach(b => b.classList.remove('active-tab'));
            btn.classList.add('active-tab');

            // Load data for the active view
            if (targetId === 'record-tile-view-id') {
                loadAssistantTileView();
            } else if (targetId === 'record-list-view-id') {
                loadAssistantListView();
            }
        });
    });

    // ===================== SEARCH FUNCTIONALITY ===================== //
    const searchBar = document.querySelector('.record-searchbar');
    if (searchBar) {
        searchBar.addEventListener('input', debounce(function() {
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadAssistantTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadAssistantListView();
            }
        }, 500));
    }

    // ===================== FILTER DROPDOWN ===================== //
    const filterBtn = document.getElementById('filterDropdownBtn');
    const filterMenu = document.getElementById('filterDropdownMenu');
    
    if (filterBtn && filterMenu) {
        filterBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            const isVisible = filterMenu.style.display === 'block';
            filterMenu.style.display = isVisible ? 'none' : 'block';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            if (!filterBtn.contains(event.target) && !filterMenu.contains(event.target)) {
                filterMenu.style.display = 'none';
            }
        });
    }

    // ===================== FILTER OPTIONS ===================== //
    const filterOptions = document.querySelectorAll('.filter-option');
    filterOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Update active state
            filterOptions.forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');
            
            // Close dropdown
            if (filterMenu) {
                filterMenu.style.display = 'none';
            }

            // Reload data with new filter
            const activeView = document.querySelector('.profile-box-main-container:not(.hidden)');
            if (activeView && activeView.id === 'record-tile-view-id') {
                loadAssistantTileView();
            } else if (activeView && activeView.id === 'record-list-view-id') {
                loadAssistantListView();
            }
        });
    });

    // ===================== ADD NEW ASSISTANT BUTTON ===================== //
    const staffAddnewRecord = document.querySelectorAll('.add-user-btn');
    staffAddnewRecord.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            if (!url) return;

            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });

    // ===================== LOAD INITIAL DATA ===================== //
    // Load tile view by default - only after API is confirmed ready
    if (typeof window.getAllAssistants === 'function') {
        loadAssistantTileView();
    } else {
        console.warn('⚠️ API check passed but function not available, showing error');
        showErrorInViews('Failed to initialize. Please refresh the page.');
    }
}

// ===================== LOAD ASSISTANT - TILE VIEW ===================== //
async function loadAssistantTileView() {
    const container = document.querySelector('.profile-box-container');
    
    if (!container) {
        console.error('❌ Tile view container not found');
        return;
    }

    try {
        // Show loading state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-3 text-muted">Loading assistant staff...</p>
            </div>
        `;

        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllAssistants !== 'function') {
            throw new Error('Assistant API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch assistant staff
        const response = await window.getAllAssistants({
            search: searchValue,
            order_by: activeFilter
        });

        const assistantStaff = response.data || [];
        
        // Clear loading state and existing content
        container.innerHTML = '';

        // Check if assistant staff exist
        if (assistantStaff.length === 0) {
            container.innerHTML = `
                <div class="col-12 text-center py-5">
                    <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                    <p class="text-muted">No assistant staff found.</p>
                </div>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through assistant staff and create cards
        assistantStaff.forEach(staff => {
            const colDiv = document.createElement('div');
            colDiv.className = 'col-12 col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6 col-profile-box';
            
            colDiv.innerHTML = `
                <div class="profile-box" tabindex="0"
                    data-page="../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management-detailed.html"
                    data-staff-profile-id="${staff.staff_profile_id}">
                    <div class="record-img-container">
                        <img data-id="profile-img-id" 
                             src="${staff.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg'}" 
                             alt="${staff.personal_info?.full_name || 'Assistant Staff'}">
                    </div>
                    <div class="info-container">
                        <h3 data-id="information-assistant-record-name-id">${staff.personal_info?.full_name || 'N/A'}</h3>
                        <span data-id="information-assistant-record-code-id">${staff.assistant_code || 'N/A'}</span>
                    </div>
                </div>
            `;
            
            container.appendChild(colDiv);
        });

        // Add click handlers to new boxes
        attachAssistantBoxHandlers();

        // Update count display
        updateCountDisplay(assistantStaff.length, response.total_count);

    } catch (error) {
        console.error('❌ Error loading assistant staff (Tile View):', error);
        
        // Show error state
        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load assistant staff. Please try again.</p>
                <button class="btn btn-primary mt-3" onclick="loadAssistantTileView()">
                    <i class="fa-solid fa-rotate-right me-2"></i>Retry
                </button>
            </div>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load assistant staff. Please try again.');
    }
}

// ===================== LOAD ASSISTANT - LIST VIEW ===================== //
async function loadAssistantListView() {
    const tbody = document.getElementById('list-view-body-id');
    
    if (!tbody) {
        console.error('❌ List view tbody not found');
        return;
    }

    try {
        // Show loading state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-3 text-muted">Loading assistant staff...</p>
                </td>
            </tr>
        `;

        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAllAssistants !== 'function') {
            throw new Error('Assistant API is not available');
        }

        // Get search value
        const searchValue = document.querySelector('.record-searchbar')?.value || '';
        
        // Get active filter
        const activeFilter = document.querySelector('.filter-option.active')?.dataset.filter || 'alphabetical';
        
        // Fetch assistant staff
        const response = await window.getAllAssistants({
            search: searchValue,
            order_by: activeFilter
        });

        const assistantStaff = response.data || [];
        
        // Clear loading state and existing content
        tbody.innerHTML = '';

        // Check if assistant staff exist
        if (assistantStaff.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-5">
                        <i class="fa-solid fa-inbox fa-3x mb-3 text-muted"></i>
                        <p class="text-muted">No assistant staff found.</p>
                    </td>
                </tr>
            `;
            updateCountDisplay(0, 0);
            return;
        }

        // Loop through assistant staff and create rows
        assistantStaff.forEach(staff => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${staff.personal_info?.full_name || 'N/A'}</td>
                <td>${staff.assistant_code || 'N/A'}</td>
                <td>${staff.personal_info?.email || 'Not provided'}</td>
                <td>${staff.personal_info?.phone || 'N/A'}</td>
                <td>
                    <div class="appointment-td-wrapper d-flex flex-row align-items-center">
                        <button type="button" class="td-view-button"
                            data-page="../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management-detailed.html"
                            data-staff-profile-id="${staff.staff_profile_id}">
                            View Details
                        </button>
                    </div>
                </td>
            `;
            
            tbody.appendChild(row);
        });

        // Add click handlers to view buttons
        attachViewButtonHandlers();

        // Update count display
        updateCountDisplay(assistantStaff.length, response.total_count);

    } catch (error) {
        console.error('❌ Error loading assistant staff (List View):', error);
        
        // Show error state
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">Failed to load assistant staff. Please try again.</p>
                    <button class="btn btn-primary mt-3" onclick="loadAssistantListView()">
                        <i class="fa-solid fa-rotate-right me-2"></i>Retry
                    </button>
                </td>
            </tr>
        `;
        
        updateCountDisplay(0, 0);
        showError('Failed to load assistant staff. Please try again.');
    }
}

// ===================== ATTACH HANDLERS TO ASSISTANT BOXES (TILE VIEW) ===================== //
function attachAssistantBoxHandlers() {
    const assistantBoxes = document.querySelectorAll('.profile-box');
    assistantBoxes.forEach(box => {
        box.addEventListener('click', () => {
            const url = box.getAttribute('data-page');
            const staffProfileId = box.getAttribute('data-staff-profile-id');
            
            if (!url) return;
            
            // ✅ SAVE staff_profile_id TO SESSION STORAGE
            if (staffProfileId) {
                sessionStorage.setItem('selectedAssistantStaffProfileId', staffProfileId);
                console.log('✅ Saved staff_profile_id to session:', staffProfileId);
            }
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== ATTACH HANDLERS TO VIEW BUTTONS (LIST VIEW) ===================== //
function attachViewButtonHandlers() {
    const viewButtons = document.querySelectorAll('.td-view-button');
    viewButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            const staffProfileId = btn.getAttribute('data-staff-profile-id');
            
            if (!url) return;
            
            // ✅ SAVE staff_profile_id TO SESSION STORAGE
            if (staffProfileId) {
                sessionStorage.setItem('selectedAssistantStaffProfileId', staffProfileId);
                console.log('✅ Saved staff_profile_id to session:', staffProfileId);
            }
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== UPDATE COUNT DISPLAY ===================== //
function updateCountDisplay(showing, total) {
    const countShowHeader = document.querySelector('.count-show-header');
    if (countShowHeader) {
        countShowHeader.textContent = `Showing ${showing} of ${total}`;
    }
}

// ===================== SHOW ERROR IN VIEWS ===================== //
function showErrorInViews(message) {
    // Show error in tile view
    const tileContainer = document.querySelector('.profile-box-container');
    if (tileContainer) {
        tileContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">${message}</p>
            </div>
        `;
    }
    
    // Show error in list view
    const listContainer = document.getElementById('list-view-body-id');
    if (listContainer) {
        listContainer.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-5">
                    <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                    <p class="text-danger">${message}</p>
                </td>
            </tr>
        `;
    }
    
    updateCountDisplay(0, 0);
}

// ===================== DEBOUNCE HELPER ===================== //
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===================== SHOW ERROR MESSAGE ===================== //
function showError(message) {
    console.error('Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP ON PAGE CHANGE =====================
window.cleanupAssistantManagement = function() {
    delete window.assistantManagementLoaded;
    console.log('🧹 Assistant Management cleaned up');
};