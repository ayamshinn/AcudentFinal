// ===================== ADMIN FRONTDESK DETAILED VIEW =====================
// Displays specific frontdesk information based on staff_profile_id from sessionStorage

// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.frontdeskDetailedLoaded) {
    console.log('Frontdesk Detailed already loaded, skipping...');
} else {
    window.frontdeskDetailedLoaded = true;
    initAdminStaffFrontdeskManagementDetailed();
}

// ===================== MAIN INIT FUNCTION =====================
async function initAdminStaffFrontdeskManagementDetailed() {
    const page = document.querySelector('#admin-staff-frontdesk-detail-view-page-id');
    
    if (!page) {
        console.log('Frontdesk detail page not found in DOM');
        return;
    }

    console.log('Frontdesk Management Detailed initialized ✅');

    // ✅ GET staff_profile_id FROM SESSION STORAGE
    const staffProfileId = sessionStorage.getItem('selectedFrontdeskStaffProfileId');
    
    if (!staffProfileId) {
        showError('No frontdesk staff selected. Redirecting back...');
        
        // Redirect back to frontdesk list after 2 seconds
        setTimeout(() => {
            if (typeof window.loadPage === 'function') {
                window.loadPage('../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.html');
            }
        }, 2000);
        return;
    }

    console.log('🔍 Loading frontdesk with staff_profile_id:', staffProfileId);

    // Load frontdesk data
    await loadFrontdeskData(staffProfileId);
    
    // Initialize buttons
    initButtons();
    
    // Initialize dental history
    loadDentalHistory();
}

// ===================== LOAD FRONTDESK DATA =====================
async function loadFrontdeskData(staffProfileId) {
    try {
        console.log('📤 Loading frontdesk data for staff_profile_id:', staffProfileId);
        
        // Show loading state
        // showLoadingState();
        
        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getFrontdeskById !== 'function') {
            console.error('❌ getFrontdeskById function not available');
            throw new Error('Frontdesk API is not available. Please refresh the page.');
        }
        
        console.log('✅ API function found, calling getFrontdeskById...');
        
        // Fetch frontdesk data - pass as number
        const response = await window.getFrontdeskById(parseInt(staffProfileId));
        
        console.log('📥 API Response:', response);
        
        if (!response.success || !response.data) {
            throw new Error(response.message || 'Failed to load frontdesk data');
        }
        
        const frontdesk = response.data;
        
        console.log('✅ Frontdesk data loaded:', frontdesk);
        
        // Populate the page with frontdesk data
        populateFrontdeskInfo(frontdesk);
        
        // Hide loading state
        hideLoadingState();
        
    } catch (error) {
        console.error('❌ Failed to load frontdesk:', error);
        showError('Failed to load frontdesk information: ' + error.message);
        hideLoadingState();
        
        // Redirect back after error
        setTimeout(() => {
            if (typeof window.loadPage === 'function') {
                window.loadPage('../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.html');
            }
        }, 3000);
    }
}

// ===================== POPULATE FRONTDESK INFO =====================
function populateFrontdeskInfo(frontdesk) {
    console.log('📝 Populating frontdesk info...');
    console.log('Frontdesk object received:', frontdesk);
    
    // ==================== PROFILE PICTURE ====================
    const profileImg = document.querySelector('.user-information-profile-img img');
    if (profileImg) {
        const profilePicture = frontdesk.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg';
        profileImg.src = profilePicture;
        profileImg.alt = frontdesk.personal_info?.full_name || 'Frontdesk Staff';
        console.log('📸 Profile picture set:', profilePicture);
    }
    
    // ==================== STAFF ID ====================
    const staffIdSpan = document.querySelector('.user-information-profile-id');
    if (staffIdSpan) {
        staffIdSpan.textContent = frontdesk.frontdesk_code || 'N/A';
    }
    
    // ==================== REGISTERED DATE ====================
    const registeredDate = document.querySelector('.container-p p:nth-child(2)');
    if (registeredDate && frontdesk.created_at) {
        const createdDate = new Date(frontdesk.created_at);
        const formattedDate = createdDate.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        });
        registeredDate.innerHTML = `<strong>Registered:</strong> ${formattedDate}`;
        console.log('📅 Registered date set:', formattedDate);
    }
    
    // ==================== GENERAL INFORMATION ====================
    const userName = document.getElementById('user-name');
    if (userName) userName.value = frontdesk.personal_info?.full_name || 'N/A';
    
    const birthDate = document.getElementById('birth-date');
    if (birthDate) birthDate.value = frontdesk.personal_info?.birthdate || '';
    
    const userAge = document.getElementById('user-age-text');
    if (userAge) {
        const age = calculateAge(frontdesk.personal_info?.birthdate);
        userAge.value = age !== 'N/A' ? age + ' years old' : 'N/A';
    }
    
    const userGender = document.getElementById('user-gender-text');
    if (userGender) userGender.value = frontdesk.personal_info?.gender || 'Not specified';
    
    const userEmail = document.getElementById('user-address-text');
    if (userEmail) userEmail.value = frontdesk.personal_info?.email || 'Not provided';
    
    const userPhone = document.getElementById('user-phone-text');
    if (userPhone) userPhone.value = frontdesk.personal_info?.phone || 'N/A';
    
    // ==================== WORK DETAILS ====================
    
    // Working Days
    const workingDays = document.getElementById('user-working-days');
    if (workingDays && frontdesk.work_info?.schedule) {
        const days = frontdesk.work_info.schedule
            .filter(s => s.is_working)
            .map(s => s.day)
            .join(', ');
        workingDays.value = days || 'Not set';
        console.log('📅 Working days set:', days);
    }
    
    // Working Hours
    const workingTime = document.getElementById('user-working-time');
    if (workingTime && frontdesk.work_info?.schedule) {
        const firstWorkingDay = frontdesk.work_info.schedule.find(s => s.is_working);
        if (firstWorkingDay) {
            const timeString = `${firstWorkingDay.start_time} - ${firstWorkingDay.end_time}`;
            workingTime.value = timeString;
            console.log('⏰ Working hours set:', timeString);
        } else {
            workingTime.value = 'Not set';
        }
    }
    
    // Role
    const role = document.getElementById('Role');
    if (role) role.value = frontdesk.role_name || 'Frontdesk';
    
    console.log('✅ Frontdesk info populated successfully');
}

// ===================== HELPER: CALCULATE AGE =====================
function calculateAge(birthdate) {
    if (!birthdate) return 'N/A';
    
    const birth = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
}

// // ===================== SHOW/HIDE LOADING STATE =====================
// function showLoadingState() {
//     const infoWrapper = document.querySelector('.info-wrapper');
//     if (infoWrapper) {
//         infoWrapper.style.opacity = '0.5';
//         infoWrapper.style.pointerEvents = 'none';
//     }
    
//     // Show loading spinner overlay
//     const loadingOverlay = document.createElement('div');
//     loadingOverlay.id = 'loading-overlay';
//     loadingOverlay.innerHTML = `
//         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; text-align: center;">
//             <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
//                 <span class="visually-hidden">Loading...</span>
//             </div>
//             <p class="mt-3 text-muted">Loading frontdesk information...</p>
//         </div>
//     `;
//     loadingOverlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.8); z-index: 9998; display: flex; align-items: center; justify-content: center;';
//     document.body.appendChild(loadingOverlay);
// }

function hideLoadingState() {
    const infoWrapper = document.querySelector('.info-wrapper');
    if (infoWrapper) {
        infoWrapper.style.opacity = '1';
        infoWrapper.style.pointerEvents = 'auto';
    }
    
    // Remove loading overlay
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
}

// ===================== INITIALIZE BUTTONS =====================
function initButtons() {
    // ==================== BACK BUTTON ====================
    const backButtons = document.querySelectorAll('.back-btn');
    backButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
                window.location.href = url;
            }
        });
    });
    
    // ==================== VIEW MORE BUTTON ====================
    const viewMoreBtns = document.querySelectorAll('.patient-view-more-btn');
    viewMoreBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== LOAD DENTAL HISTORY =====================
function loadDentalHistory() {
    // Sample data for dental history table
    const sampleDentalHistoryData = [
        {
            id: 1,
            date: "2023-10-15",
            services: "Cleaning",
            patientName: "Dracy Malibu",
            patientId: "P-1005",
            dentist: "Dr. Santos",
            status: "Completed"
        },
        {
            id: 2,
            date: "2023-11-02",
            services: "Filling",
            patientName: "Jane Smith",
            patientId: "P-1006",
            dentist: "Dr. Dela Cruz",
            status: "Upcoming"
        },
        {
            id: 3,
            date: "2023-12-20",
            services: "Extraction",
            patientName: "John Doe",
            patientId: "P-1007",
            dentist: "Dr. Lee",
            status: "Completed"
        }
    ];
    
    populateDentalHistoryTable(sampleDentalHistoryData);
}

// ===================== POPULATE DENTAL HISTORY TABLE =====================
function populateDentalHistoryTable(data) {
    const tbody = document.getElementById('patient-dental-history-tb-body-staff-side');
    if (!tbody) {
        console.error('❌ Dental history table body not found!');
        return;
    }
    
    tbody.innerHTML = ''; // Clear existing rows
    
    if (!data || data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <i class="fa-solid fa-inbox fa-2x mb-2 text-muted"></i>
                    <p class="text-muted">No dental history records found.</p>
                </td>
            </tr>
        `;
        return;
    }
    
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.date}</td>
            <td>${row.services}</td>
            <td>${row.patientName}</td>
            <td>${row.patientId}</td>
            <td>${row.dentist}</td>
            <td><span class="badge ${getStatusBadgeClass(row.status)}">${row.status}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// ===================== GET STATUS BADGE CLASS =====================
function getStatusBadgeClass(status) {
    switch (status.toLowerCase()) {
        case 'completed':
            return 'bg-success';
        case 'upcoming':
            return 'bg-warning text-dark';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// ===================== SHOW ERROR =====================
function showError(message) {
    console.error('❌ Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP =====================
window.cleanupFrontdeskDetailed = function() {
    delete window.frontdeskDetailedLoaded;
    
    // ✅ DON'T clear sessionStorage here - let the next page decide
    // Only clear if we're NOT going to another frontdesk-related page
    const currentHash = window.location.hash;
    const isFrontdeskRelated = currentHash && currentHash.includes('frontdesk');
    
    if (!isFrontdeskRelated) {
        sessionStorage.removeItem('selectedFrontdeskStaffProfileId'); // ✅ Updated session key
        console.log('🧹 Cleared frontdesk sessionStorage (navigating away from frontdesk pages)');
    }
    
    console.log('🧹 Frontdesk Detailed cleaned up');
};

// ===================== HANDLE DOM CONTENT LOADED =====================
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (!window.frontdeskDetailedLoaded) {
            initAdminStaffFrontdeskManagementDetailed();
        }
    });
} else {
    // DOM already loaded
    if (!window.frontdeskDetailedLoaded) {
        initAdminStaffFrontdeskManagementDetailed();
    }
}