// ===================== ADMIN ASSISTANT DETAILED VIEW =====================
// Displays specific assistant information based on staff_profile_id from sessionStorage

// ===================== PREVENT MULTIPLE INITIALIZATIONS =====================
if (window.assistantDetailedLoaded) {
    console.log('Assistant Detailed already loaded, skipping...');
} else {
    window.assistantDetailedLoaded = true;
    initAdminStaffAssistantManagementDetailed();
}

// ===================== MAIN INIT FUNCTION =====================
async function initAdminStaffAssistantManagementDetailed() {
    const page = document.querySelector('#admin-staff-assistant-detail-view-page-id');
    
    if (!page) {
        console.log('❌ Assistant detail page not found in DOM');
        return;
    }

    console.log('✅ Assistant Management Detailed initialized');

    // ✅ GET staff_profile_id FROM SESSION STORAGE
    const staffProfileId = sessionStorage.getItem('selectedAssistantStaffProfileId');
    
    console.log('📦 Session Storage Value:', staffProfileId);
    
    if (!staffProfileId) {
        console.error('❌ No assistant staff selected');
        showError('No assistant staff selected. Redirecting back...');
        
        // Redirect back to assistant list after 2 seconds
        setTimeout(() => {
            if (typeof window.loadPage === 'function') {
                window.loadPage('../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management.html');
            }
        }, 2000);
        return;
    }

    console.log('🔍 Loading assistant with staff_profile_id:', staffProfileId);

    // Load assistant data
    await loadAssistantData(staffProfileId);
    
    // Initialize buttons
    initButtons();
    
    // Initialize dental history (if applicable for assistants)
    loadDentalHistory();
}

// ===================== LOAD ASSISTANT DATA =====================
async function loadAssistantData(staffProfileId) {
    try {
        console.log('📤 Loading assistant data for staff_profile_id:', staffProfileId);
        
        // Show loading state
        // showLoadingState();
        
        // ✅ VERIFY API IS AVAILABLE
        if (typeof window.getAssistantById !== 'function') {
            console.error('❌ getAssistantById function not available');
            console.log('Available window functions:', Object.keys(window).filter(k => k.includes('Assistant')));
            throw new Error('Assistant API is not available. Please refresh the page.');
        }
        
        console.log('✅ API function found, calling getAssistantById...');
        
        // Fetch assistant data - pass as number
        const response = await window.getAssistantById(parseInt(staffProfileId));
        
        console.log('📥 Full API Response:', response);
        console.log('📥 Response.data:', response.data);
        
        if (!response.success || !response.data) {
            throw new Error(response.message || 'Failed to load assistant data');
        }
        
        const assistant = response.data;
        
        console.log('✅ Assistant data loaded successfully');
        console.log('📋 Assistant Details:', {
            staff_profile_id: assistant.staff_profile_id,
            assistant_code: assistant.assistant_code,
            personal_info: assistant.personal_info,
            work_info: assistant.work_info,
            profile_picture: assistant.profile_picture,
            role_name: assistant.role_name
        });
        
        // Populate the page with assistant data
        populateAssistantInfo(assistant);
        
        // Hide loading state
        hideLoadingState();
        
    } catch (error) {
        console.error('❌ Failed to load assistant:', error);
        console.error('❌ Error stack:', error.stack);
        showError('Failed to load assistant information: ' + error.message);
        hideLoadingState();
        
        // Redirect back after error
        setTimeout(() => {
            if (typeof window.loadPage === 'function') {
                window.loadPage('../admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management.html');
            }
        }, 3000);
    }
}

// ===================== POPULATE ASSISTANT INFO =====================
function populateAssistantInfo(assistant) {
    console.log('📝 Starting to populate assistant info...');
    console.log('📝 Assistant object:', assistant);
    
    try {
        // ==================== PROFILE PICTURE ====================
        const profileImg = document.querySelector('.user-information-profile-img img');
        console.log('🖼️ Profile img element:', profileImg);
        
        if (profileImg) {
            const profilePicture = assistant.profile_picture || '/Acudent/frontend/assets/images/default-pfp.jpg';
            profileImg.src = profilePicture;
            profileImg.alt = assistant.personal_info?.full_name || 'Assistant Staff';
            console.log('✅ Profile picture set:', profilePicture);
        } else {
            console.warn('⚠️ Profile img element not found');
        }
        
        // ==================== STAFF ID ====================
        const staffIdSpan = document.querySelector('.user-information-profile-id');
        console.log('🆔 Staff ID span element:', staffIdSpan);
        
        if (staffIdSpan) {
            staffIdSpan.textContent = assistant.assistant_code || 'N/A';
            console.log('✅ Staff ID set:', assistant.assistant_code);
        } else {
            console.warn('⚠️ Staff ID span not found');
        }
        
        // ==================== REGISTERED DATE ====================
        const registeredDate = document.querySelector('.container-p p:nth-child(2)');
        console.log('📅 Registered date element:', registeredDate);
        
        if (registeredDate && assistant.created_at) {
            const createdDate = new Date(assistant.created_at);
            const formattedDate = createdDate.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            registeredDate.innerHTML = `<strong>Registered:</strong> ${formattedDate}`;
            console.log('✅ Registered date set:', formattedDate);
        } else {
            console.warn('⚠️ Registered date element not found or created_at missing');
        }
        
        // ==================== GENERAL INFORMATION ====================
        console.log('📋 Setting general information fields...');
        
        const userName = document.getElementById('user-name');
        if (userName) {
            userName.value = assistant.personal_info?.full_name || 'N/A';
            console.log('✅ Name set:', userName.value);
        } else {
            console.warn('⚠️ user-name element not found');
        }
        
        const birthDate = document.getElementById('birth-date');
        if (birthDate) {
            birthDate.value = assistant.personal_info?.birthdate || '';
            console.log('✅ Birth date set:', birthDate.value);
        } else {
            console.warn('⚠️ birth-date element not found');
        }
        
        const userAge = document.getElementById('user-age-text');
        if (userAge) {
            const age = calculateAge(assistant.personal_info?.birthdate);
            userAge.value = age !== 'N/A' ? age + ' years old' : 'N/A';
            console.log('✅ Age set:', userAge.value);
        } else {
            console.warn('⚠️ user-age-text element not found');
        }
        
        const userGender = document.getElementById('user-gender-text');
        if (userGender) {
            userGender.value = assistant.personal_info?.gender || 'Not specified';
            console.log('✅ Gender set:', userGender.value);
        } else {
            console.warn('⚠️ user-gender-text element not found');
        }
        
        const userEmail = document.getElementById('user-address-text');
        if (userEmail) {
            userEmail.value = assistant.personal_info?.email || 'Not provided';
            console.log('✅ Email set:', userEmail.value);
        } else {
            console.warn('⚠️ user-address-text element not found');
        }
        
        const userPhone = document.getElementById('user-phone-text');
        if (userPhone) {
            userPhone.value = assistant.personal_info?.phone || 'N/A';
            console.log('✅ Phone set:', userPhone.value);
        } else {
            console.warn('⚠️ user-phone-text element not found');
        }
        
        // ==================== WORK DETAILS ====================
        console.log('💼 Setting work details...');
        console.log('💼 Work info:', assistant.work_info);
        console.log('💼 Schedule:', assistant.work_info?.schedule);
        
        // Working Days
        const workingDays = document.getElementById('user-working-days');
        if (workingDays) {
            if (assistant.work_info?.schedule && Array.isArray(assistant.work_info.schedule)) {
                const days = assistant.work_info.schedule
                    .filter(s => s.is_working)
                    .map(s => s.day)
                    .join(', ');
                workingDays.value = days || 'Not set';
                console.log('✅ Working days set:', workingDays.value);
            } else {
                workingDays.value = 'Not set';
                console.log('✅ Working days set to: Not set (no schedule data)');
            }
        } else {
            console.warn('⚠️ user-working-days element not found');
        }
        
        // Working Hours
        const workingTime = document.getElementById('user-working-time');
        if (workingTime) {
            if (assistant.work_info?.schedule && Array.isArray(assistant.work_info.schedule)) {
                const firstWorkingDay = assistant.work_info.schedule.find(s => s.is_working);
                if (firstWorkingDay) {
                    const timeString = `${firstWorkingDay.start_time} - ${firstWorkingDay.end_time}`;
                    workingTime.value = timeString;
                    console.log('✅ Working hours set:', workingTime.value);
                } else {
                    workingTime.value = 'Not set';
                    console.log('✅ Working hours set to: Not set (no working days)');
                }
            } else {
                workingTime.value = 'Not set';
                console.log('✅ Working hours set to: Not set (no schedule data)');
            }
        } else {
            console.warn('⚠️ user-working-time element not found');
        }
        
        // Role
        const role = document.getElementById('Role');
        if (role) {
            role.value = assistant.role_name || 'Assistant';
            console.log('✅ Role set:', role.value);
        } else {
            console.warn('⚠️ Role element not found');
        }
        
        console.log('✅✅✅ Assistant info population completed successfully!');
        
    } catch (error) {
        console.error('❌ Error populating assistant info:', error);
        console.error('❌ Error stack:', error.stack);
        throw error;
    }
}

// ===================== HELPER: CALCULATE AGE =====================
function calculateAge(birthdate) {
    if (!birthdate) return 'N/A';
    
    const birth = new Date(birthdate);
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
        age--;
    }
    
    return age;
}

// // ===================== SHOW/HIDE LOADING STATE =====================
// function showLoadingState() {
//     const infoWrapper = document.querySelector('.info-wrapper');
//     if (infoWrapper) {
//         infoWrapper.style.opacity = '0.5';
//         infoWrapper.style.pointerEvents = 'none';
//     }
    
//     // Show loading spinner overlay
//     const loadingOverlay = document.createElement('div');
//     loadingOverlay.id = 'loading-overlay';
//     loadingOverlay.innerHTML = `
//         <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); z-index: 9999; text-align: center;">
//             <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
//                 <span class="visually-hidden">Loading...</span>
//             </div>
//             <p class="mt-3 text-muted">Loading assistant information...</p>
//         </div>
//     `;
//     loadingOverlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255,255,255,0.8); z-index: 9998; display: flex; align-items: center; justify-content: center;';
//     document.body.appendChild(loadingOverlay);
// }

function hideLoadingState() {
    const infoWrapper = document.querySelector('.info-wrapper');
    if (infoWrapper) {
        infoWrapper.style.opacity = '1';
        infoWrapper.style.pointerEvents = 'auto';
    }
    
    // Remove loading overlay
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
}

// ===================== INITIALIZE BUTTONS =====================
function initButtons() {
    // ==================== BACK BUTTON ====================
    const backButtons = document.querySelectorAll('.back-btn');
    backButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
                window.location.href = url;
            }
        });
    });
    
    // ==================== VIEW MORE BUTTON ====================
    const viewMoreBtns = document.querySelectorAll('.patient-view-more-btn');
    viewMoreBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const url = btn.getAttribute('data-page');
            if (!url) return;
            
            if (typeof window.loadPage === 'function') {
                window.loadPage(url);
            } else {
                console.warn('⚠️ loadPage() function not found.');
            }
        });
    });
}

// ===================== LOAD DENTAL HISTORY =====================
function loadDentalHistory() {
    // Sample data for dental history table (if assistants have this)
    const sampleDentalHistoryData = [
        {
            id: 1,
            date: "2023-10-15",
            services: "Cleaning",
            patientName: "Dracy Malibu",
            patientId: "P-1005",
            dentist: "Dr. Santos",
            status: "Completed"
        },
        {
            id: 2,
            date: "2023-11-02",
            services: "Filling",
            patientName: "Jane Smith",
            patientId: "P-1006",
            dentist: "Dr. Dela Cruz",
            status: "Upcoming"
        },
        {
            id: 3,
            date: "2023-12-20",
            services: "Extraction",
            patientName: "John Doe",
            patientId: "P-1007",
            dentist: "Dr. Lee",
            status: "Completed"
        }
    ];
    
    populateDentalHistoryTable(sampleDentalHistoryData);
}

// ===================== POPULATE DENTAL HISTORY TABLE =====================
function populateDentalHistoryTable(data) {
    const tbody = document.getElementById('patient-dental-history-tb-body-staff-side');
    if (!tbody) {
        console.error('❌ Dental history table body not found!');
        return;
    }
    
    tbody.innerHTML = ''; // Clear existing rows
    
    if (!data || data.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <i class="fa-solid fa-inbox fa-2x mb-2 text-muted"></i>
                    <p class="text-muted">No dental history records found.</p>
                </td>
            </tr>
        `;
        return;
    }
    
    data.forEach(row => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${row.date}</td>
            <td>${row.services}</td>
            <td>${row.patientName}</td>
            <td>${row.patientId}</td>
            <td>${row.dentist}</td>
            <td><span class="badge ${getStatusBadgeClass(row.status)}">${row.status}</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// ===================== GET STATUS BADGE CLASS =====================
function getStatusBadgeClass(status) {
    switch (status.toLowerCase()) {
        case 'completed':
            return 'bg-success';
        case 'upcoming':
            return 'bg-warning text-dark';
        case 'cancelled':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

// ===================== SHOW ERROR =====================
function showError(message) {
    console.error('❌ Error:', message);
    
    if (typeof window.showToast === 'function') {
        window.showToast('error', message);
    } else {
        alert(message);
    }
}

// ===================== CLEANUP =====================
window.cleanupAssistantDetailed = function() {
    delete window.assistantDetailedLoaded;
    
    // ✅ DON'T clear sessionStorage here - let the next page decide
    // Only clear if we're NOT going to another assistant-related page
    const currentHash = window.location.hash;
    const isAssistantRelated = currentHash && currentHash.includes('assistant');
    
    if (!isAssistantRelated) {
        sessionStorage.removeItem('selectedAssistantStaffProfileId');
        console.log('🧹 Cleared assistant sessionStorage (navigating away from assistant pages)');
    }
    
    console.log('🧹 Assistant Detailed cleaned up');
};

// ===================== HANDLE DOM CONTENT LOADED =====================
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        if (!window.assistantDetailedLoaded) {
            initAdminStaffAssistantManagementDetailed();
        }
    });
} else {
    // DOM already loaded
    if (!window.assistantDetailedLoaded) {
        initAdminStaffAssistantManagementDetailed();
    }
}