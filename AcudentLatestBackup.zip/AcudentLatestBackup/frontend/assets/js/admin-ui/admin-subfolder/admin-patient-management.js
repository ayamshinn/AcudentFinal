// ===================== ADMIN PATIENT MANAGEMENT =====================

const PATIENT_DETAIL_PAGE = '../admin-ui/admin-subfolder/admin-patient-management-detailed.html';
const PATIENT_TILE_CONTAINER  = 'record-tile-view-id';
const PATIENT_LIST_BODY       = 'list-view-body-id';
const PATIENT_LIMIT           = 10;

let currentPage     = 1;
let currentSearch   = '';
let currentOrderBy  = 'alphabetical';
let totalPatients   = 0;
let allLoaded       = false;

function initAdminPatientManagement() {
    const page = document.querySelector('#admin-patient-page-id');
    if (!page) return;
    console.log('Patient Management initialized ✅');

    // ===================== TOGGLE TILE / LIST VIEW =====================
    const toggleButtons = document.querySelectorAll('.toggle-button[data-target]');
    const sections      = document.querySelectorAll('.profile-box-main-container');

    toggleButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId      = btn.getAttribute('data-target');
            const targetSection = document.getElementById(targetId);
            if (!targetSection) return;

            sections.forEach(s => s.classList.add('hidden'));
            targetSection.classList.remove('hidden');

            toggleButtons.forEach(b => b.classList.remove('active-tab'));
            btn.classList.add('active-tab');
        });
    });

    // ===================== FILTER DROPDOWN =====================
    const filterBtn  = document.getElementById('filterDropdownBtn');
    const filterMenu = document.getElementById('filterDropdownMenu');

    if (filterBtn && filterMenu) {
        filterBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            filterMenu.style.display = filterMenu.style.display === 'none' ? 'block' : 'none';
        });

        document.addEventListener('click', () => {
            filterMenu.style.display = 'none';
        });

        document.querySelectorAll('.filter-option').forEach(opt => {
            opt.addEventListener('click', () => {
                currentOrderBy = opt.getAttribute('data-filter');
                currentPage    = 1;
                filterMenu.style.display = 'none';
                loadPatients(true);
            });
        });
    }

    // ===================== SEARCH =====================
    const searchbar = document.querySelector('.record-searchbar');
    if (searchbar) {
        let debounceTimer;
        searchbar.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                currentSearch = this.value.trim();
                currentPage   = 1;
                loadPatients(true);
            }, 400);
        });
    }

    // ===================== LOAD MORE / LESS =====================
    const loadMoreBtn = document.querySelector('.load-more');
    const loadLessBtn = document.querySelector('.load-less');

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
            if (!allLoaded) {
                currentPage++;
                loadPatients(false);
            }
        });
    }

    if (loadLessBtn) {
        loadLessBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                loadPatients(false);
            }
        });
    }

    // ===================== ADD NEW PATIENT =====================
 document.querySelectorAll('.add-user-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const url = btn.getAttribute('data-page');
        if (!url) return;
        sessionStorage.setItem('patientFormOrigin', 'admin'); // ✅ store context
        if (typeof window.loadPage === 'function') {
            window.loadPage(url);
        } else {
            window.location.href = url;
        }
    });
});

    // ===================== INITIAL LOAD =====================
    loadPatients(true);
}

// ===================== CORE LOAD FUNCTION =====================
async function loadPatients(reset = false) {
    if (reset) {
        currentPage = 1;
        allLoaded   = false;
    }

    // Show loading state
    showPatientLoadingState();

    try {
        const result = await window.getAllPatients({
            search:   currentSearch,
            order_by: currentOrderBy,
            page:     currentPage,
            limit:    PATIENT_LIMIT
        });

        totalPatients = result.total_count || 0;
        const patients = (result.data || []).map(window.formatPatientForDisplay);

        // Check if we've loaded everything
        allLoaded = (currentPage * PATIENT_LIMIT) >= totalPatients;

        // Render both views
        window.renderPatientTileView(patients, PATIENT_TILE_CONTAINER, PATIENT_DETAIL_PAGE);
        window.renderPatientListView(patients, PATIENT_LIST_BODY, PATIENT_DETAIL_PAGE);

        // Update count display
        const showing = Math.min(currentPage * PATIENT_LIMIT, totalPatients);
        window.updatePatientCountDisplay(showing, totalPatients);

        // Update load more/less button states
        updateLoadButtons();

    } catch (error) {
        console.error('Failed to load patients:', error);
        showPatientErrorState(error.message);
    }
}

// ===================== LOADING STATE =====================
function showPatientLoadingState() {
    // ✅ Target .row inside tile container — preserves Bootstrap column classes
    const tileRow = document.querySelector(`#${PATIENT_TILE_CONTAINER} .row`);
    if (tileRow) {
        tileRow.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-spinner fa-spin fa-2x mb-3" style="color:#9E5B08;"></i>
                <p class="text-muted">Loading patients...</p>
            </div>`;
    }

    const listBody = document.getElementById(PATIENT_LIST_BODY);
    if (listBody) {
        listBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <i class="fas fa-spinner fa-spin me-2" style="color:#9E5B08;"></i>
                    Loading patients...
                </td>
            </tr>`;
    }
}

// ===================== ERROR STATE =====================
function showPatientErrorState(message) {
    // ✅ Target .row inside tile container — preserves Bootstrap column classes
    const tileRow = document.querySelector(`#${PATIENT_TILE_CONTAINER} .row`);
    if (tileRow) {
        tileRow.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-exclamation-triangle fa-2x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load patients: ${message}</p>
                <button class="btn btn-sm btn-outline-danger mt-2" onclick="loadPatients(true)">
                    <i class="fas fa-redo me-1"></i> Retry
                </button>
            </div>`;
    }

    const listBody = document.getElementById(PATIENT_LIST_BODY);
    if (listBody) {
        listBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-danger py-4">
                    Failed to load patients. <a href="#" onclick="loadPatients(true)">Retry</a>
                </td>
            </tr>`;
    }
}

// ===================== LOAD MORE/LESS BUTTON STATE =====================
function updateLoadButtons() {
    const loadMoreBtn = document.querySelector('.load-more');
    const loadLessBtn = document.querySelector('.load-less');

    if (loadMoreBtn) {
        loadMoreBtn.disabled = allLoaded;
        loadMoreBtn.style.opacity = allLoaded ? '0.4' : '1';
    }
    if (loadLessBtn) {
        loadLessBtn.disabled = currentPage <= 1;
        loadLessBtn.style.opacity = currentPage <= 1 ? '0.4' : '1';
    }
}

document.addEventListener('DOMContentLoaded', initAdminPatientManagement);