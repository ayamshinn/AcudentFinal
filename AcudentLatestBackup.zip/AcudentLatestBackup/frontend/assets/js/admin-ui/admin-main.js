// ===================== MAIN JS =====================
document.addEventListener('DOMContentLoaded', () => {

  const container = document.querySelector('.content-area');

  // ===== Function to load a page (reusable) =====
  window.loadPage = function (pageUrl, options = {}) {

    // ✅ FIX: Handle both old-style boolean calls e.g. loadPage(url, false)
    //         AND new-style object calls e.g. loadPage(url, { patientId: id })
    let addToHistory = true;

    if (typeof options === 'boolean') {
      // Legacy usage: loadPage(url, false)
      addToHistory = options;

    } else if (typeof options === 'object' && options !== null) {
      // New usage: loadPage(url, { patientId: '37' })
      if (options.addToHistory === false) addToHistory = false;

      // ✅ THE CORE FIX: Save patientId to sessionStorage BEFORE navigating
      if (options.patientId !== undefined && options.patientId !== null) {
        sessionStorage.setItem('selectedPatientId', options.patientId);
      }
    }

    fetch(pageUrl)
      .then(res => res.text())
      .then(html => {
        container.innerHTML = html;

        // Update title dynamically
        if (pageUrl.includes("dashboard")) document.title = "Admin Portal - Dashboard";
        else if (pageUrl.includes("appointments")) document.title = "Admin Portal - Appointments";
        else if (pageUrl.includes("messages")) document.title = "Admin Portal - Messages";
        else if (pageUrl.includes("patient")) document.title = "Admin Portal - Patient Management";
        else if (pageUrl.includes("dentist")) document.title = "Admin Portal - Dentist Management";
        else if (pageUrl.includes("staff")) document.title = "Admin Portal - Staff Management";
        else if (pageUrl.includes("inventory")) document.title = "Admin Portal - Inventory Management";
        else if (pageUrl.includes("inventory-report")) document.title = "Admin Portal - Inventory Reports";
        else if (pageUrl.includes("financial-report")) document.title = "Admin Portal - Financial Reports";
        else if (pageUrl.includes("appointment-report")) document.title = "Admin Portal - Appointment Reports";
        else if (pageUrl.includes("performance-report")) document.title = "Admin Portal - Performance Reports";
        else if (pageUrl.includes("services")) document.title = "Admin Portal - Dental Services";
        else if (pageUrl.includes("help")) document.title = "Admin Portal - Help";
        else if (pageUrl.includes("security")) document.title = "Admin Portal - Account Security";
        else if (pageUrl.includes("settings")) document.title = "Admin Portal - Settings";
        else document.title = "Admin Portal";

        // ✅ Add to browser history if required
        if (addToHistory) {
          history.pushState({ pageUrl }, "", `#${pageUrl}`);
        }

        // ✅ Reset scroll
        window.scrollTo(0, 0);
        const contentArea = document.querySelector('.main-content-area-container');
        if (contentArea) contentArea.scrollTop = 0;

        // ✅ Initialize the page logic after it's inserted
        initPageScript(pageUrl);

        // ✅ Dispatch pageLoaded event so API handlers know to load
        const pageLoadedEvent = new CustomEvent('pageLoaded', {
          detail: { pageUrl: pageUrl }
        });
        document.dispatchEvent(pageLoadedEvent);
      })
      .catch(err => console.error('Error loading page:', err));
  };

  // ===== Attach click events to all sidebar links =====
  document.querySelectorAll('a[data-page]').forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const pageUrl = link.getAttribute('data-page');
      loadPage(pageUrl); // default addToHistory = true
    });
  });

  // ✅ Automatically load the default page on initial load
  const initialPage = location.hash ? location.hash.substring(1) : '../admin-ui/admin-subfolder/admin-dashboard.html';
  loadPage(initialPage, false); // Don't add first load to history

  // ✅ Handle browser Back/Forward buttons
  window.addEventListener("popstate", (event) => {
    if (event.state && event.state.pageUrl) {
      loadPage(event.state.pageUrl, false); // false = don't re-push into history
    } else {
      loadPage('../admin-ui/admin-subfolder/admin-dashboard.html', false);
    }
  });
});


// ===================== PAGE SCRIPT INITIALIZER =====================
function initPageScript(pageUrl) {

  if (pageUrl.includes('admin-dashboard.html')) {
    if (typeof initAdminDashboard === 'function') {
      initAdminDashboard();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dashboard.js';
      script.onload = () => initAdminDashboard();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-appointments.html')) {
    if (typeof initAdminAppointments === 'function') {
      initAdminAppointments();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-appointments.js';
      script.onload = () => initAdminAppointments();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-messages.html')) {
    if (typeof initAdminMessages === 'function') {
      initAdminMessages();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-messages.js';
      script.onload = () => initAdminMessages();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-patient-management.html')) {
    if (typeof window.getAllPatients === 'function') {
      if (typeof initAdminPatientManagement === 'function') {
        initAdminPatientManagement();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/admin-patient-management.js';
        script.onload = () => initAdminPatientManagement();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getAllPatients === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminPatientManagement === 'function') {
            initAdminPatientManagement();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/admin-patient-management.js';
            script.onload = () => initAdminPatientManagement();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Patient API failed to load within 5 seconds');
          const container = document.querySelector('.profile-box-container');
          if (container) {
            container.innerHTML = `
              <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
              </div>`;
          }
        }
      }, 100);
    }
  }

  if (pageUrl.includes('add-new-patient-record.html')) {
    if (typeof window.createPatientRecord === 'function') {
      if (typeof initAddNewPatientRecord === 'function') {
        initAddNewPatientRecord();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/shared-ui/patient-management-folder/add-new-patient-record.js';
        script.onload = () => initAddNewPatientRecord();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.createPatientRecord === 'function') {
          clearInterval(checkAPI);
          if (typeof initAddNewPatientRecord === 'function') {
            initAddNewPatientRecord();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/shared-ui/patient-management-folder/add-new-patient-record.js';
            script.onload = () => initAddNewPatientRecord();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Patient Record API failed to load within 5 seconds');
          const container = document.querySelector('.patient-information-container');
          if (container) {
            container.innerHTML = `
              <div class="text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
                <button class="btn btn-primary mt-3" onclick="location.reload()">
                  <i class="fa-solid fa-rotate-right me-2"></i>Refresh Page
                </button>
              </div>`;
          }
        }
      }, 100);
    }
  }

  if (pageUrl.includes('admin-dentist-management.html')) {
    if (typeof window.getAllDentists === 'function') {
      if (typeof initAdminDentistManagement === 'function') {
        initAdminDentistManagement();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-management.js';
        script.onload = () => initAdminDentistManagement();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getAllDentists === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminDentistManagement === 'function') {
            initAdminDentistManagement();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-management.js';
            script.onload = () => initAdminDentistManagement();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ API failed to load within 5 seconds');
        }
      }, 500);
    }
  }

  if (pageUrl.includes('admin-inventory-management.html')) {
    if (typeof initAdminInventoryManagement === 'function') {
      initAdminInventoryManagement();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-inventory-management.js';
      script.onload = () => initAdminInventoryManagement();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-inventory-report.html')) {
    if (typeof initAdminInventoryReport === 'function') {
      initAdminInventoryReport();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/report-folder/admin-inventory-report.js';
      script.onload = () => initAdminInventoryReport();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-financial-report.html')) {
    if (typeof initAdminFinancialReport === 'function') {
      initAdminFinancialReport();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/report-folder/admin-financial-report.js';
      script.onload = () => initAdminFinancialReport();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-appointment-report.html')) {
    if (typeof initAdminAppointmentReport === 'function') {
      initAdminAppointmentReport();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/report-folder/admin-appointment-report.js';
      script.onload = () => initAdminAppointmentReport();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-performance-report.html')) {
    if (typeof initAdminPerformanceReport === 'function') {
      initAdminPerformanceReport();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/report-folder/admin-performance-reports.js';
      script.onload = () => initAdminPerformanceReport();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-services.html')) {
    if (typeof initAdminServices === 'function') {
      initAdminServices();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-services.js';
      script.onload = () => initAdminServices();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-help.html')) {
    if (typeof initAdminHelp === 'function') {
      initAdminHelp();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-help.js';
      script.onload = () => initAdminHelp();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-security.html')) {
    if (typeof initAdminSecurity === 'function') {
      initAdminSecurity();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-security.js';
      script.onload = () => initAdminSecurity();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-settings.html')) {
    if (typeof initAdminSettings === 'function') {
      initAdminSettings();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-settings.js';
      script.onload = () => initAdminSettings();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-patient-management-detailed.html')) {
    if (typeof window.getPatientById === 'function') {
      if (typeof initAdminPatientManagementDetailed === 'function') {
        initAdminPatientManagementDetailed();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/admin-patient-management-detailed.js';
        script.onload = () => initAdminPatientManagementDetailed();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getPatientById === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminPatientManagementDetailed === 'function') {
            initAdminPatientManagementDetailed();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/admin-patient-management-detailed.js';
            script.onload = () => initAdminPatientManagementDetailed();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Patient Detail API failed to load within 5 seconds');
          const container = document.querySelector('#admin-patient-detail-view-page-id');
          if (container) {
            container.innerHTML = `
              <div class="text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
                <button class="btn btn-primary mt-3" onclick="location.reload()">
                  <i class="fa-solid fa-rotate-right me-2"></i>Refresh Page
                </button>
              </div>`;
          }
        }
      }, 100);
    }
  }

  if (pageUrl.includes('admin-patient-management-view-detailed.html')) {
    if (typeof initAdminPatientManagementViewDetailed === 'function') {
      initAdminPatientManagementViewDetailed();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-patient-management-view-detailed.js';
      script.onload = () => initAdminPatientManagementViewDetailed();
      document.body.appendChild(script);
    }
  }

  // ============================== ASSISTANT MANAGEMENT ==============================
  if (pageUrl.includes('admin-staff-assistant-management.html')) {
    if (typeof window.getAllAssistants === 'function') {
      if (typeof initAdminStaffAssistantManagement === 'function') {
        initAdminStaffAssistantManagement();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management.js';
        script.onload = () => initAdminStaffAssistantManagement();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getAllAssistants === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminStaffAssistantManagement === 'function') {
            initAdminStaffAssistantManagement();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management.js';
            script.onload = () => initAdminStaffAssistantManagement();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Assistant API failed to load within 5 seconds');
          const container = document.querySelector('.profile-box-container');
          if (container) {
            container.innerHTML = `
              <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
              </div>`;
          }
        }
      }, 500);
    }
  }

  // ============================== ASSISTANT DETAILED VIEW ==============================
  if (pageUrl.includes('admin-staff-assistant-management-detailed.html')) {
    if (typeof window.getAssistantById === 'function') {
      if (typeof initAdminStaffAssistantManagementDetailed === 'function') {
        initAdminStaffAssistantManagementDetailed();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management-detailed.js';
        script.onload = () => initAdminStaffAssistantManagementDetailed();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getAssistantById === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminStaffAssistantManagementDetailed === 'function') {
            initAdminStaffAssistantManagementDetailed();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management-detailed.js';
            script.onload = () => initAdminStaffAssistantManagementDetailed();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Assistant Detail API failed to load within 5 seconds');
          const container = document.querySelector('.info-wrapper');
          if (container) {
            container.innerHTML = `
              <div class="text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
                <button class="btn btn-primary mt-3" onclick="location.reload()">
                  <i class="fa-solid fa-rotate-right me-2"></i>Refresh Page
                </button>
              </div>`;
          }
        }
      }, 100);
    }
  }

  if (pageUrl.includes('admin-staff-assistant-management-view-detailed.html')) {
    if (typeof initAdminStaffAssistantManagementViewDetailed === 'function') {
      initAdminStaffAssistantManagementViewDetailed();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-management-view-detailed.js';
      script.onload = () => initAdminStaffAssistantManagementViewDetailed();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-staff-assistant-register.html')) {
    if (typeof initAdminStaffAssistantRegister === 'function') {
      initAdminStaffAssistantRegister();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-assistant-register.js';
      script.onload = () => initAdminStaffAssistantRegister();
      document.body.appendChild(script);
    }
  }

  // ============================== FRONTDESK MANAGEMENT ==============================
  if (pageUrl.includes('admin-staff-frontdesk-management.html')) {
    if (typeof window.getAllFrontdesk === 'function') {
      if (typeof initAdminStaffFrontdeskManagement === 'function') {
        initAdminStaffFrontdeskManagement();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.js';
        script.onload = () => initAdminStaffFrontdeskManagement();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getAllFrontdesk === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminStaffFrontdeskManagement === 'function') {
            initAdminStaffFrontdeskManagement();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management.js';
            script.onload = () => initAdminStaffFrontdeskManagement();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Frontdesk API failed to load within 5 seconds');
          const container = document.querySelector('.profile-box-container');
          if (container) {
            container.innerHTML = `
              <div class="col-12 text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
              </div>`;
          }
        }
      }, 500);
    }
  }

  // ============================== FRONTDESK DETAILED VIEW ==============================
  if (pageUrl.includes('admin-staff-frontdesk-management-detailed.html')) {
    if (typeof window.getFrontdeskById === 'function') {
      if (typeof initAdminStaffFrontdeskManagementDetailed === 'function') {
        initAdminStaffFrontdeskManagementDetailed();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management-detailed.js';
        script.onload = () => initAdminStaffFrontdeskManagementDetailed();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getFrontdeskById === 'function') {
          clearInterval(checkAPI);
          if (typeof initAdminStaffFrontdeskManagementDetailed === 'function') {
            initAdminStaffFrontdeskManagementDetailed();
          } else {
            const script = document.createElement('script');
            script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management-detailed.js';
            script.onload = () => initAdminStaffFrontdeskManagementDetailed();
            document.body.appendChild(script);
          }
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Frontdesk Detail API failed to load within 5 seconds');
          const container = document.querySelector('.info-wrapper');
          if (container) {
            container.innerHTML = `
              <div class="text-center py-5">
                <i class="fa-solid fa-exclamation-triangle fa-3x mb-3 text-danger"></i>
                <p class="text-danger">Failed to load API. Please refresh the page.</p>
                <button class="btn btn-primary mt-3" onclick="location.reload()">
                  <i class="fa-solid fa-rotate-right me-2"></i>Refresh Page
                </button>
              </div>`;
          }
        }
      }, 100);
    }
  }

  if (pageUrl.includes('admin-staff-frontdesk-management-view-detailed.html')) {
    if (typeof initAdminStaffFrontdeskManagementViewDetailed === 'function') {
      initAdminStaffFrontdeskManagementViewDetailed();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-management-view-detailed.js';
      script.onload = () => initAdminStaffFrontdeskManagementViewDetailed();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('admin-staff-frontdesk-register.html')) {
    if (typeof initAdminStaffFrontdeskRegister === 'function') {
      initAdminStaffFrontdeskRegister();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-management/admin-staff-frontdesk-register.js';
      script.onload = () => initAdminStaffFrontdeskRegister();
      document.body.appendChild(script);
    }
  }

  // ============================== DENTIST MANAGEMENT ==============================
  if (pageUrl.includes('admin-dentist-register.html')) {
    if (typeof initAdminDentistRegister === 'function') {
      initAdminDentistRegister();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-register.js';
      script.onload = () => initAdminDentistRegister();
      document.body.appendChild(script);
    }
  }

  // ============================== DENTIST DETAILED VIEW ==============================
  if (pageUrl.includes('admin-dentist-management-detailed.html')) {
    if (typeof window.getDentistById === 'function') {
      if (typeof initAdminDentistManagementDetailed === 'function') {
        initAdminDentistManagementDetailed();
      } else {
        const script = document.createElement('script');
        script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-management-detailed.js';
        script.onload = () => initAdminDentistManagementDetailed();
        document.body.appendChild(script);
      }
    } else {
      let attempts = 0;
      const maxAttempts = 50;
      const checkAPI = setInterval(() => {
        attempts++;
        if (typeof window.getDentistById === 'function') {
          clearInterval(checkAPI);
          const script = document.createElement('script');
          script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-management-detailed.js';
          script.onload = () => initAdminDentistManagementDetailed();
          document.body.appendChild(script);
        } else if (attempts >= maxAttempts) {
          clearInterval(checkAPI);
          console.error('❌ Dentist API failed to load');
        }
      }, 100);
    }
  }

  if (pageUrl.includes('admin-dentist-management-view-detailed.html')) {
    if (typeof initAdminDentistManagementViewDetailed === 'function') {
      initAdminDentistManagementViewDetailed();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/admin-dentist-management-view-detailed.js';
      script.onload = () => initAdminDentistManagementViewDetailed();
      document.body.appendChild(script);
    }
  }

  if (pageUrl.includes('add-clinic-staff-record.html')) {
    if (typeof initAdminAddStaffRecord === 'function') {
      initAdminAddStaffRecord();
    } else {
      const script = document.createElement('script');
      script.src = '../../assets/js/admin-ui/admin-subfolder/clinic-staff-record-folder/add-clinic-staff-record.js';
      script.onload = () => initAdminAddStaffRecord();
      document.body.appendChild(script);
    }
  }
}