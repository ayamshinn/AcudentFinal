<?php
header("Content-Type: application/json");
session_start();

/* ===================== DB CONNECTION ===================== */
$dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
if (!file_exists($dbPath)) {
    echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
    exit;
}
require_once $dbPath;

/* ===================== REQUEST CHECK ===================== */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

/* ===================== INPUT ===================== */
$input = json_decode(file_get_contents('php://input'), true);

$username = strtolower(trim($input['username'] ?? ''));
$password = trim($input['password'] ?? '');
$patientOnly = $input['patient_only'] ?? false;

if ($username === '' || $password === '') {
    echo json_encode(['success' => false, 'message' => 'Username and password are required']);
    exit;
}

/* ===================== USER QUERY ===================== */
$query = "
    SELECT 
        u.user_id,
        u.username,
        u.password_hash,
        u.role_id,
        r.role_name,
        u.first_name,
        u.last_name
    FROM users_tb u
    INNER JOIN roles_tb r ON u.role_id = r.role_id
    WHERE u.username = ?
    LIMIT 1
";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
    exit;
}

$user = $result->fetch_assoc();

/* ===================== PATIENT-ONLY CHECK ===================== */
if ($patientOnly && strtolower($user['role_name']) !== 'patient') {
    echo json_encode([
        'success' => false,
        'message' => 'This login is for patients only'
    ]);
    exit;
}

/* ===================== PASSWORD VERIFY ===================== */
if (!password_verify($password, $user['password_hash'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
    exit;
}

/* ===================== SESSION ===================== */
$_SESSION['user'] = [
    'user_id'    => $user['user_id'],
    'username'   => $user['username'],
    'first_name' => $user['first_name'],
    'last_name'  => $user['last_name'],
    'role_id'    => $user['role_id'],
    'role_name'  => $user['role_name']
];

/* ===================== API TOKEN ===================== */
$token = bin2hex(random_bytes(32));
$expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));

$ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

$tokenQuery = "
    INSERT INTO api_tokens (user_id, token, expires_at, ip_address, user_agent)
    VALUES (?, ?, ?, ?, ?)
";
$tokenStmt = $conn->prepare($tokenQuery);
if ($tokenStmt) {
    $tokenStmt->bind_param(
        "issss",
        $user['user_id'],
        $token,
        $expiresAt,
        $ipAddress,
        $userAgent
    );
    $tokenStmt->execute();
}

/* ===================== REDIRECT ===================== */
$redirect = "../user-interface/index.php";

switch ($user['role_id']) {
    case 1: $redirect = "../admin-ui/admin-main.php"; break;
    case 2: $redirect = "../dentist-ui/dentist-main.php"; break;
    case 3: $redirect = "../staff-ui/staff-frontdesk-main.php"; break;
    case 4: $redirect = "../staff-ui/staff-assistant-main.php"; break;
    case 5: $redirect = "../patient-ui/patient-main.php"; break;
}

/* ===================== RESPONSE ===================== */
echo json_encode([
    'success'  => true,
    'role'     => $user['role_name'],
    'redirect' => $redirect,
    'token'    => $token
]);
exit;