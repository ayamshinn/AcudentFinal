<?php
// File: /Acudent/backend/api/auth/session-auth.php
// Simple session-based authentication for capstone project

require_once $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';

// Start session with secure settings
function initSecureSession() {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
        session_start();
    }
}

// Generate CSRF token
function generateCSRFToken() {
    initSecureSession();
    
    if (!isset($_SESSION['csrf_token']) || !isset($_SESSION['csrf_token_time'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = time();
    } else {
        // Regenerate token every hour
        if (time() - $_SESSION['csrf_token_time'] > 3600) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
    }
    
    return $_SESSION['csrf_token'];
}

// Validate CSRF token
function validateCSRFToken($token) {
    initSecureSession();
    
    if (!isset($_SESSION['csrf_token'])) {
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Check if user is logged in
function isLoggedIn() {
    initSecureSession();
    return isset($_SESSION['user_id']) && isset($_SESSION['role_id']);
}

// Get current user info
function getCurrentUser() {
    initSecureSession();
    
    if (!isLoggedIn()) {
        return false;
    }
    
    return [
        'user_id' => $_SESSION['user_id'],
        'role_id' => $_SESSION['role_id'],
        'username' => $_SESSION['username'] ?? '',
        'role' => $_SESSION['role'] ?? ''
    ];
}

// Require authentication
function requireAuth($allowedRoles = []) {
    initSecureSession();
    
    if (!isLoggedIn()) {
        header("Content-Type: application/json");
        echo json_encode(["success" => false, "message" => "Please log in to continue"]);
        exit;
    }
    
    // Check role if specified
    if (!empty($allowedRoles) && isset($_SESSION['role'])) {
        if (!in_array($_SESSION['role'], $allowedRoles)) {
            header("Content-Type: application/json");
            echo json_encode(["success" => false, "message" => "You don't have permission to perform this action"]);
            exit;
        }
    }
    
    return getCurrentUser();
}

// Redirect if not logged in (for page protection)
function requireAuthPage($allowedRoles = []) {
    initSecureSession();
    
    if (!isLoggedIn()) {
        header("Location: /Acudent/frontend/views/user-interface/index.php");
        exit;
    }
    
    // Check role if specified
    if (!empty($allowedRoles) && isset($_SESSION['role'])) {
        if (!in_array($_SESSION['role'], $allowedRoles)) {
            header("Location: /Acudent/frontend/views/user-interface/unauthorized.php");
            exit;
        }
    }
    
    return getCurrentUser();
}

// Login user
function loginUser($userId, $roleId, $username, $roleName) {
    initSecureSession();
    
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    
    $_SESSION['user_id'] = $userId;
    $_SESSION['role_id'] = $roleId;
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $roleName;
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    
    // Generate initial CSRF token
    generateCSRFToken();
    
    return true;
}

// Logout user
function logoutUser() {
    initSecureSession();
    
    // Clear all session data
    $_SESSION = array();
    
    // Delete session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy session
    session_destroy();
    
    return true;
}

// Check session timeout (30 minutes of inactivity)
function checkSessionTimeout($timeout = 1800) {
    initSecureSession();
    
    if (isLoggedIn() && isset($_SESSION['last_activity'])) {
        if (time() - $_SESSION['last_activity'] > $timeout) {
            logoutUser();
            return false;
        }
        $_SESSION['last_activity'] = time();
    }
    
    return true;
}
?>