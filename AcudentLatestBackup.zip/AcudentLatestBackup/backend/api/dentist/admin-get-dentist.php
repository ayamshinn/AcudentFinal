<?php
/**
 * Get Single Dentist by ID API
 * Retrieves a specific dentist's complete information including schedule
 * 
 * Query Parameters:
 * - dentist_id (required): The ID of the dentist to retrieve
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET DENTIST BY ID API CLASS ===================== */
    class GetDentistByIdAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function getDentistById($dentistId) {
            try {
                if (empty($dentistId)) {
                    throw new Exception("Dentist ID is required");
                }
                
                // Validate dentist_id is numeric
                if (!is_numeric($dentistId)) {
                    throw new Exception("Invalid dentist ID format");
                }
                
                // Build query to get dentist details
                $sql = "SELECT 
                    d.dentist_id,
                    d.staff_profile_id,
                    d.specialization,
                    d.license_number,
                    d.education,
                    d.notes,
                    d.position,
                    d.start_date,
                    d.linkedin_url,
                    d.facebook_url,
                    d.instagram_url,
                    d.tiktok_url,
                    d.youtube_url,
                    d.professional_photo_path,
                    d.professional_photo,
                    sp.user_id,
                    sp.first_name,
                    sp.last_name,
                    sp.birthdate,
                    sp.gender,
                    sp.address,
                    sp.phone,
                    sp.created_at,
                    u.user_code,
                    u.username,
                    u.email,
                    u.profile_picture_path,
                    u.profile_picture,
                    r.role_name
                FROM Dentists_tb d
                INNER JOIN Staff_Profile_tb sp ON d.staff_profile_id = sp.staff_profile_id
                INNER JOIN Users_tb u ON sp.user_id = u.user_id
                INNER JOIN Roles_tb r ON sp.role_id = r.role_id
                WHERE d.dentist_id = ?
                LIMIT 1";
                
                $stmt = $this->conn->prepare($sql);
                
                if (!$stmt) {
                    throw new Exception("Failed to prepare statement: " . $this->conn->error);
                }
                
                $stmt->bind_param("i", $dentistId);
                
                if (!$stmt->execute()) {
                    throw new Exception("Failed to execute query: " . $stmt->error);
                }
                
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    throw new Exception("Dentist not found with ID: " . $dentistId);
                }
                
                $row = $result->fetch_assoc();
                $stmt->close();
                
                // Get schedule for this dentist
                $schedule = $this->getStaffSchedule($row['staff_profile_id']);
                
                // Format dentist data
                $dentistData = $this->formatDentistData($row, $schedule);
                
                return [
                    'success' => true,
                    'message' => 'Dentist retrieved successfully',
                    'data' => $dentistData
                ];
                
            } catch (Exception $e) {
                throw new Exception("Failed to retrieve dentist: " . $e->getMessage());
            }
        }
        
        private function getStaffSchedule($staffProfileId) {
            try {
                $sql = "SELECT 
                    day_of_week,
                    start_time,
                    end_time,
                    is_working
                FROM Staff_Base_Schedule_tb
                WHERE staff_profile_id = ?
                ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')";
                
                $stmt = $this->conn->prepare($sql);
                
                if (!$stmt) {
                    // Return empty schedule if table doesn't exist or query fails
                    return [];
                }
                
                $stmt->bind_param("i", $staffProfileId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $schedule = [];
                while ($row = $result->fetch_assoc()) {
                    $schedule[] = [
                        'day' => $row['day_of_week'],
                        'start_time' => $row['start_time'],
                        'end_time' => $row['end_time'],
                        'is_working' => (bool)$row['is_working']
                    ];
                }
                
                $stmt->close();
                return $schedule;
                
            } catch (Exception $e) {
                // Return empty schedule if error
                return [];
            }
        }
        
        private function formatDentistData($row, $schedule = []) {
            // Handle profile picture
            $profilePicture = null;
            
            // Priority: professional_photo_path > profile_picture_path > professional_photo (blob) > profile_picture (blob)
            if (!empty($row['professional_photo_path'])) {
                $profilePicture = $row['professional_photo_path'];
            } elseif (!empty($row['profile_picture_path'])) {
                $profilePicture = $row['profile_picture_path'];
            } elseif (!empty($row['professional_photo'])) {
                $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['professional_photo']);
            } elseif (!empty($row['profile_picture'])) {
                $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['profile_picture']);
            }
            
            // Generate dentist code
            $dentistCode = !empty($row['user_code']) ? $row['user_code'] : 'D-' . str_pad($row['dentist_id'], 4, '0', STR_PAD_LEFT);
            
            return [
                'dentist_id' => (int)$row['dentist_id'],
                'dentist_code' => $dentistCode,
                'staff_profile_id' => (int)$row['staff_profile_id'],
                'user_id' => (int)$row['user_id'],
                'personal_info' => [
                    'first_name' => $row['first_name'] ?? '',
                    'last_name' => $row['last_name'] ?? '',
                    'full_name' => trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')),
                    'birthdate' => $row['birthdate'] ?? null,
                    'gender' => $row['gender'] ?? 'Not specified',
                    'address' => $row['address'] ?? 'Not provided',
                    'phone' => $row['phone'] ?? 'Not provided',
                    'email' => $row['email'] ?? 'Not provided'
                ],
                'professional_info' => [
                    'specialization' => $row['specialization'] ?? 'General Dentistry',
                    'license_number' => $row['license_number'] ?? 'Not provided',
                    'position' => $row['position'] ?? 'Dentist',
                    'education' => $row['education'] ?? 'Not provided',
                    'start_date' => $row['start_date'] ?? null,
                    'notes' => $row['notes'] ?? ''
                ],
                'social_media' => [
                    'linkedin' => $row['linkedin_url'] ?? null,
                    'facebook' => $row['facebook_url'] ?? null,
                    'instagram' => $row['instagram_url'] ?? null,
                    'tiktok' => $row['tiktok_url'] ?? null,
                    'youtube' => $row['youtube_url'] ?? null
                ],
                'schedule' => $schedule,
                'profile_picture' => $profilePicture,
                'username' => $row['username'] ?? '',
                'role_name' => $row['role_name'] ?? 'Dentist',
                'created_at' => $row['created_at'] ?? null
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get dentist_id from query parameters
        $dentistId = $_GET['dentist_id'] ?? null;
        
        if (!$dentistId) {
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'message' => 'Dentist ID is required. Please provide dentist_id parameter.'
            ]);
            exit();
        }
        
        $api = new GetDentistByIdAPI($conn);
        $result = $api->getDentistById($dentistId);
        
        http_response_code(200);
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed. Use GET request.']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

exit;
?>