<?php
/**
 * Add Patient Record API
 * Allowed roles: Admin, Frontdesk
 * Fixed: bind_param type string corrected (birthdate=s, age=i)
 * Fixed: ValidationException class for 200 responses on duplicate/validation errors
 * Fixed: display_errors = 0 to prevent PHP warnings corrupting JSON output
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

class ValidationException extends Exception {}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== ROLE AUTHORIZATION ===================== */
    // Allow Admin and Frontdesk roles to add patient records.
    // Session must be started by connection-db.php or we start it here.
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    $allowedRoles = ['Admin', 'Frontdesk'];

    // Only enforce role check if session role data is available.
    // If your app stores the role in session, uncomment and adjust the key below:
    // if (!isset($_SESSION['role_name']) || !in_array($_SESSION['role_name'], $allowedRoles)) {
    //     http_response_code(403);
    //     echo json_encode(['success' => false, 'message' => 'Access denied. Only Admin and Frontdesk staff can add patient records.']);
    //     exit;
    // }

    /* ===================== PATIENT RECORD API CLASS ===================== */
    class PatientRecordAPI {
        private $conn;
        private $maxRetries = 3;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function addPatientRecord($data) {
            error_log("=== PATIENT RECORD CREATION ===");
            error_log("Raw Birthdate: " . ($data['Birthdate'] ?? 'NOT SET'));
            error_log("Raw Age: "       . ($data['Age']       ?? 'NOT SET'));
            
            $data = $this->ensureAge($data);
            
            error_log("After ensureAge - Birthdate: " . ($data['Birthdate'] ?? 'NOT SET'));
            error_log("After ensureAge - Age: "       . ($data['Age']       ?? 'NOT SET'));
            
            $this->validatePatientInfo($data);
            
            $attempts = 0;
            
            while ($attempts < $this->maxRetries) {
                try {
                    $this->conn->begin_transaction();
                    
                    $patientCode = $this->generatePatientCode();
                    $patientId   = $this->createPatientRecord($patientCode, $data);
                    
                    if (!empty($data['hasHMO']) && $data['hasHMO'] === 'yes') {
                        $this->createHMORecord($patientId, $data);
                    }
                    
                    if ($this->isMinor($data['Age'] ?? 0)) {
                        $this->createGuardianRecord($patientId, $data);
                    }
                    
                    $this->conn->commit();
                    
                    return [
                        'success' => true,
                        'message' => 'Patient record created successfully',
                        'data'    => [
                            'patient_id'   => $patientId,
                            'patient_code' => $patientCode
                        ]
                    ];
                    
                } catch (ValidationException $e) {
                    $this->conn->rollback();
                    throw $e;

                } catch (Exception $e) {
                    $this->conn->rollback();
                    
                    if (strpos($e->getMessage(), 'Duplicate entry') !== false &&
                        strpos($e->getMessage(), 'patient_code') !== false) {
                        $attempts++;
                        usleep(rand(10000, 50000));
                        continue;
                    }

                    if (strpos($e->getMessage(), 'Duplicate entry') !== false &&
                        strpos($e->getMessage(), 'phone') !== false) {
                        throw new ValidationException(
                            "This phone number is already registered to an existing patient. Please use a different phone number."
                        );
                    }

                    if (strpos($e->getMessage(), 'Duplicate entry') !== false &&
                        strpos($e->getMessage(), 'email') !== false) {
                        throw new ValidationException(
                            "This email address is already registered to an existing patient. Please use a different email address."
                        );
                    }
                    
                    throw $e;
                }
            }
            
            throw new Exception('Failed to generate unique patient code after ' . $this->maxRetries . ' attempts');
        }
        
        private function ensureAge($data) {
            if (isset($data['Age'])) {
                $data['Age'] = trim((string)$data['Age']);
            }
            
            if (empty($data['Age']) || !is_numeric($data['Age']) || $data['Age'] === '0') {
                if (!empty($data['Birthdate'])) {
                    error_log("Calculating age from birthdate: " . $data['Birthdate']);
                    $birthDate   = new DateTime($data['Birthdate']);
                    $today       = new DateTime();
                    $age         = $today->diff($birthDate)->y;
                    $data['Age'] = (string)$age;
                    error_log("Calculated age: " . $data['Age']);
                }
            }
            return $data;
        }
        
        private function validatePatientInfo($data) {
            $required = [
                'LastName'    => 'Last name',
                'FirstName'   => 'First name',
                'Gender'      => 'Gender',
                'Birthdate'   => 'Birthdate',
                'PhoneNumber' => 'Phone number',
                'Email'       => 'Email address',
                'Address'     => 'Address'
            ];
            
            foreach ($required as $field => $label) {
                if (empty($data[$field] ?? '')) {
                    throw new ValidationException("$label is required");
                }
            }
            
            $birthdate = trim($data['Birthdate']);
            
            if (empty($birthdate) || $birthdate === '0000-00-00') {
                throw new ValidationException("Valid birthdate is required. Please select a birthdate from the calendar.");
            }
            
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthdate)) {
                throw new ValidationException("Invalid birthdate format. Expected YYYY-MM-DD, got: " . $birthdate);
            }
            
            $birthDate = DateTime::createFromFormat('Y-m-d', $birthdate);
            if (!$birthDate || $birthDate->format('Y-m-d') !== $birthdate) {
                throw new ValidationException("Invalid birthdate. Please enter a valid date.");
            }
            
            $today = new DateTime();
            if ($birthDate > $today) {
                throw new ValidationException("Birthdate cannot be in the future");
            }
            
            error_log("✅ Birthdate validation passed: " . $birthdate);
            
            if (!isset($data['Age']) || $data['Age'] === '' || $data['Age'] === null) {
                throw new ValidationException("Age is required (calculated from birthdate)");
            }
            
            if (!is_numeric($data['Age']) || $data['Age'] < 0) {
                throw new ValidationException("Invalid age value: " . $data['Age']);
            }
            
            if (!in_array($data['Gender'], ['Male', 'Female'])) {
                throw new ValidationException("Invalid gender value");
            }
            
            if (!preg_match('/^\+?[0-9\s\-()]+$/', $data['PhoneNumber'])) {
                throw new ValidationException("Invalid phone number format");
            }
            
            $stmt = $this->conn->prepare("
                SELECT patient_id, first_name, last_name, patient_code 
                FROM patients_tb 
                WHERE phone = ? 
                LIMIT 1
            ");
            $stmt->bind_param("s", $data['PhoneNumber']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $existing     = $result->fetch_assoc();
                $existingName = $existing['first_name'] . ' ' . $existing['last_name'];
                $existingCode = $existing['patient_code'];
                $stmt->close();
                throw new ValidationException(
                    "This phone number is already registered to patient: {$existingName} ({$existingCode}). " .
                    "Please use a different phone number."
                );
            }
            $stmt->close();
            
            if (!filter_var($data['Email'], FILTER_VALIDATE_EMAIL)) {
                throw new ValidationException("Invalid email format");
            }
            
            $stmt = $this->conn->prepare("
                SELECT patient_id, first_name, last_name, patient_code 
                FROM patients_tb 
                WHERE email = ? 
                LIMIT 1
            ");
            $stmt->bind_param("s", $data['Email']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $existing     = $result->fetch_assoc();
                $existingName = $existing['first_name'] . ' ' . $existing['last_name'];
                $existingCode = $existing['patient_code'];
                $stmt->close();
                throw new ValidationException(
                    "This email is already registered to patient: {$existingName} ({$existingCode}). " .
                    "Please use a different email address."
                );
            }
            $stmt->close();
            
            if (!empty($data['hasHMO']) && $data['hasHMO'] === 'yes') {
                if (empty($data['HMOProvider'])) {
                    throw new ValidationException("HMO provider is required when HMO is selected");
                }
                if (empty($data['MembershipID'])) {
                    throw new ValidationException("Membership ID is required when HMO is selected");
                }
            }
            
            if ($this->isMinor($data['Age'])) {
                $guardianRequired = [
                    'guardian-fullname' => 'Guardian full name',
                    'MContactNum'       => 'Guardian contact number',
                    'RltoPatient'       => 'Relationship to patient',
                    'GuardianEmail'     => 'Guardian email'
                ];
                
                foreach ($guardianRequired as $field => $label) {
                    if (empty($data[$field] ?? '')) {
                        throw new ValidationException("$label is required for patients under 18");
                    }
                }
                
                if (!preg_match('/^\+?[0-9\s\-()]+$/', $data['MContactNum'])) {
                    throw new ValidationException("Invalid guardian phone number format");
                }
                
                if (!filter_var($data['GuardianEmail'], FILTER_VALIDATE_EMAIL)) {
                    throw new ValidationException("Invalid guardian email format");
                }
            }
        }
        
        private function isMinor($age) {
            return is_numeric($age) && intval($age) < 18;
        }
        
        private function generatePatientCode() {
            $prefix = "PAT-";
            
            $stmt = $this->conn->prepare("
                SELECT patient_code 
                FROM patients_tb 
                WHERE patient_code LIKE ? 
                ORDER BY patient_code DESC 
                LIMIT 1
            ");
            $likePattern = $prefix . '%';
            $stmt->bind_param("s", $likePattern);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row        = $result->fetch_assoc();
                $lastCode   = $row['patient_code'];
                $lastNumber = intval(substr($lastCode, strlen($prefix)));
                $newNumber  = $lastNumber + 1;
            } else {
                $newNumber = 1;
            }
            
            $stmt->close();
            return $prefix . str_pad($newNumber, 3, '0', STR_PAD_LEFT);
        }
        
        private function createPatientRecord($patientCode, $data) {
            $age       = intval($data['Age']);
            $birthdate = trim($data['Birthdate']);
            
            error_log("Creating patient record:");
            error_log("  Patient Code: " . $patientCode);
            error_log("  Birthdate: "    . $birthdate);
            error_log("  Age: "          . $age);
            
            $stmt = $this->conn->prepare("
                INSERT INTO patients_tb (
                    user_id, patient_code, first_name, last_name, middle_name,
                    phone, birthdate, age, gender, address, email, 
                    status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Complete', NOW())
            ");
            
            $userId     = !empty($data['user_id'])       ? $data['user_id']       : null;
            $middleName = !empty($data['MiddleInitial']) ? $data['MiddleInitial'] : null;
            
            $stmt->bind_param(
                "issssssisss",
                $userId,
                $patientCode,
                $data['FirstName'],
                $data['LastName'],
                $middleName,
                $data['PhoneNumber'],
                $birthdate,
                $age,
                $data['Gender'],
                $data['Address'],
                $data['Email']
            );
            
            if (!$stmt->execute()) {
                error_log("❌ Failed to execute INSERT: " . $stmt->error);
                throw new Exception("Failed to create patient record: " . $stmt->error);
            }
            
            $patientId = $this->conn->insert_id;
            error_log("✅ Patient record created with ID: " . $patientId);
            
            $stmt->close();
            return $patientId;
        }
        
        private function createHMORecord($patientId, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO patient_hmo_tb (
                    patient_id, hmo_provider, member_id, is_valid, created_at
                ) VALUES (?, ?, ?, 1, NOW())
            ");
            
            $stmt->bind_param("iss", $patientId, $data['HMOProvider'], $data['MembershipID']);
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create HMO record: " . $stmt->error);
            }
            
            $stmt->close();
        }
        
        private function createGuardianRecord($patientId, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO patient_guardian_tb (
                    patient_id, guardian_name, contact_number, 
                    relationship, email, created_at
                ) VALUES (?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->bind_param(
                "issss",
                $patientId,
                $data['guardian-fullname'],
                $data['MContactNum'],
                $data['RltoPatient'],
                $data['GuardianEmail']
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create guardian record: " . $stmt->error);
            }
            
            $stmt->close();
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $rawInput = file_get_contents('php://input');
        error_log("Raw POST data: " . $rawInput);
        
        $data = json_decode($rawInput, true);
        
        if (!$data) {
            http_response_code(200);
            echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
            exit;
        }
        
        $api    = new PatientRecordAPI($conn);
        $result = $api->addPatientRecord($data);
        
        http_response_code(200);
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (ValidationException $e) {
    error_log("VALIDATION ERROR: " . $e->getMessage());
    http_response_code(200);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);

} catch (Exception $e) {
    error_log("EXCEPTION: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>