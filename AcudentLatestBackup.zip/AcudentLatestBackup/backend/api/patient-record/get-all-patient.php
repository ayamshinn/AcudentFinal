<?php
/**
 * Get All Patients API
 * Retrieves all patient records from patients_tb only (no user account needed)
 * Includes HMO and guardian info via LEFT JOIN
 * Supports search, filtering, and pagination
 */

error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET ALL PATIENTS API CLASS ===================== */
    class GetAllPatientsAPI {
        private $conn;

        public function __construct($db) {
            $this->conn = $db;
        }

        public function getAllPatients($params = []) {
            $searchTerm = trim($params['search']   ?? '');
            $orderBy    = $params['order_by']       ?? 'alphabetical';
            $page       = isset($params['page'])    ? max(1, intval($params['page'])) : null;
            $limit      = isset($params['limit'])   ? max(1, intval($params['limit'])) : 10;

            // ── Base query ──────────────────────────────────────────────────────
            // patients_tb is the only required table.
            // HMO and guardian are optional (LEFT JOIN).
            $sql = "
                SELECT
                    p.patient_id,
                    p.patient_code,
                    p.first_name,
                    p.last_name,
                    p.middle_name,
                    p.phone,
                    p.birthdate,
                    p.age,
                    p.gender,
                    p.address,
                    p.email,
                    p.profile_picture,
                    p.status,
                    p.created_at,
                    p.updated_at,

                    -- HMO (NULL if none)
                    h.hmo_id,
                    h.hmo_provider,
                    h.member_id      AS hmo_member_id,
                    h.is_valid       AS hmo_is_valid,
                    h.notes          AS hmo_notes,

                    -- Guardian (NULL if none / adult patient)
                    g.guardian_id,
                    g.guardian_name,
                    g.contact_number AS guardian_contact,
                    g.relationship,
                    g.email          AS guardian_email,

                    -- Total appointments count
                    COUNT(DISTINCT a.appointment_id) AS total_appointments

                FROM patients_tb p
                LEFT JOIN patient_hmo_tb      h ON p.patient_id = h.patient_id
                LEFT JOIN patient_guardian_tb g ON p.patient_id = g.patient_id
                LEFT JOIN appointments_tb     a ON p.patient_id = a.patient_id
            ";

            // ── WHERE (search) ──────────────────────────────────────────────────
            $whereClause = '';
            if (!empty($searchTerm)) {
                $whereClause = "
                    WHERE (
                        p.first_name    LIKE ? OR
                        p.last_name     LIKE ? OR
                        p.email         LIKE ? OR
                        p.phone         LIKE ? OR
                        p.patient_code  LIKE ? OR
                        CONCAT(p.first_name, ' ', p.last_name) LIKE ?
                    )
                ";
            }
            $sql .= $whereClause;

            // ── GROUP BY (needed for COUNT) ─────────────────────────────────────
            $sql .= " GROUP BY p.patient_id";

            // ── ORDER BY ───────────────────────────────────────────────────────
            switch ($orderBy) {
                case 'newest':
                    $sql .= " ORDER BY p.created_at DESC";
                    break;
                case 'oldest':
                    $sql .= " ORDER BY p.created_at ASC";
                    break;
                case 'alphabetical':
                default:
                    $sql .= " ORDER BY p.last_name ASC, p.first_name ASC";
                    break;
            }

            // ── PAGINATION ─────────────────────────────────────────────────────
            if ($page !== null) {
                $offset = ($page - 1) * $limit;
                $sql .= " LIMIT ? OFFSET ?";
            }

            // ── Prepare & bind ─────────────────────────────────────────────────
            $stmt = $this->conn->prepare($sql);

            if (!empty($searchTerm)) {
                $s = "%{$searchTerm}%";
                if ($page !== null) {
                    $stmt->bind_param("ssssssii", $s, $s, $s, $s, $s, $s, $limit, $offset);
                } else {
                    $stmt->bind_param("ssssss", $s, $s, $s, $s, $s, $s);
                }
            } elseif ($page !== null) {
                $stmt->bind_param("ii", $limit, $offset);
            }

            $stmt->execute();
            $result = $stmt->get_result();

            $patients = [];
            while ($row = $result->fetch_assoc()) {
                $patients[] = $this->formatPatientData($row);
            }
            $stmt->close();

            // ── Total count (for pagination UI) ────────────────────────────────
            $totalCount = $this->getTotalCount($searchTerm);

            // ── Response ───────────────────────────────────────────────────────
            $response = [
                'success'     => true,
                'message'     => 'Patients retrieved successfully',
                'data'        => $patients,
                'count'       => count($patients),
                'total_count' => $totalCount,
                'order_by'    => $orderBy
            ];

            if (!empty($searchTerm)) {
                $response['search_term'] = $searchTerm;
            }

            if ($page !== null) {
                $response['pagination'] = [
                    'current_page' => $page,
                    'total_pages'  => ceil($totalCount / $limit),
                    'limit'        => $limit,
                    'total_records'=> $totalCount
                ];
            }

            return $response;
        }

        // ── Total count helper ─────────────────────────────────────────────────
        private function getTotalCount($searchTerm = '') {
            $sql = "SELECT COUNT(DISTINCT p.patient_id) AS total FROM patients_tb p";

            if (!empty($searchTerm)) {
                $sql .= "
                    WHERE (
                        p.first_name   LIKE ? OR
                        p.last_name    LIKE ? OR
                        p.email        LIKE ? OR
                        p.phone        LIKE ? OR
                        p.patient_code LIKE ? OR
                        CONCAT(p.first_name, ' ', p.last_name) LIKE ?
                    )
                ";
            }

            $stmt = $this->conn->prepare($sql);

            if (!empty($searchTerm)) {
                $s = "%{$searchTerm}%";
                $stmt->bind_param("ssssss", $s, $s, $s, $s, $s, $s);
            }

            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return (int)$row['total'];
        }

        // ── Format single patient row ──────────────────────────────────────────
        private function formatPatientData($row) {
            // Profile picture
            $profilePicture = null;
            if (!empty($row['profile_picture'])) {
                // Check if it's already a path string or raw binary
                if (ctype_print($row['profile_picture']) && strpos($row['profile_picture'], '/') !== false) {
                    $profilePicture = $row['profile_picture'];
                } else {
                    $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['profile_picture']);
                }
            }

            // HMO block (null if no HMO record)
            $hmo = null;
            if (!empty($row['hmo_id'])) {
                $hmo = [
                    'hmo_id'      => $row['hmo_id'],
                    'provider'    => $row['hmo_provider'],
                    'member_id'   => $row['hmo_member_id'],
                    'is_valid'    => (bool)$row['hmo_is_valid'],
                    'notes'       => $row['hmo_notes']
                ];
            }

            // Guardian block (null if adult / no guardian)
            $guardian = null;
            if (!empty($row['guardian_id'])) {
                $guardian = [
                    'guardian_id'  => $row['guardian_id'],
                    'name'         => $row['guardian_name'],
                    'contact'      => $row['guardian_contact'],
                    'relationship' => $row['relationship'],
                    'email'        => $row['guardian_email']
                ];
            }

            return [
                'patient_id'          => $row['patient_id'],
                'patient_code'        => $row['patient_code'],
                'profile_picture'     => $profilePicture,
                'status'              => $row['status'],
                'created_at'          => $row['created_at'],
                'updated_at'          => $row['updated_at'],
                'total_appointments'  => (int)$row['total_appointments'],

                'personal_info' => [
                    'first_name'  => $row['first_name'],
                    'last_name'   => $row['last_name'],
                    'middle_name' => $row['middle_name'],
                    'full_name'   => trim($row['first_name'] . ' ' . $row['last_name']),
                    'birthdate'   => $row['birthdate'],
                    'age'         => (int)$row['age'],
                    'gender'      => $row['gender'],
                    'phone'       => $row['phone'],
                    'email'       => $row['email'],
                    'address'     => $row['address']
                ],

                'hmo'      => $hmo,
                'guardian' => $guardian
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $params = [
            'search'   => $_GET['search']   ?? '',
            'order_by' => $_GET['order_by'] ?? 'alphabetical',
            'page'     => $_GET['page']     ?? null,
            'limit'    => $_GET['limit']    ?? 10
        ];

        $api    = new GetAllPatientsAPI($conn);
        $result = $api->getAllPatients($params);

        http_response_code(200);
        echo json_encode($result);

    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (Exception $e) {
    error_log("EXCEPTION [get-all-patients]: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>