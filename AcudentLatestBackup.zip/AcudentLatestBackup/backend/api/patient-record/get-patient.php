<?php
/**
 * Get Single Patient by ID API
 * Retrieves a specific patient's complete information
 * including HMO, guardian, and medical history data
 *
 * Query Parameters:
 * - patient_id (required): The ID of the patient to retrieve
 */

error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET PATIENT BY ID API CLASS ===================== */
    class GetPatientByIdAPI {
        private $conn;

        public function __construct($db) {
            $this->conn = $db;
        }

        public function getPatientById($patientId) {
            if (empty($patientId)) {
                throw new Exception("Patient ID is required");
            }

            if (!is_numeric($patientId)) {
                throw new Exception("Invalid patient ID format");
            }

            $sql = "
                SELECT
                    p.patient_id,
                    p.patient_code,
                    p.first_name,
                    p.last_name,
                    p.middle_name,
                    p.phone,
                    p.birthdate,
                    p.age,
                    p.gender,
                    p.address,
                    p.email,
                    p.profile_picture,
                    p.status,
                    p.created_at,
                    p.updated_at,

                    -- HMO (NULL if none)
                    h.hmo_id,
                    h.hmo_provider,
                    h.member_id      AS hmo_member_id,
                    h.is_valid       AS hmo_is_valid,
                    h.notes          AS hmo_notes,

                    -- Guardian (NULL if none)
                    g.guardian_id,
                    g.guardian_name,
                    g.contact_number AS guardian_contact,
                    g.relationship,
                    g.email          AS guardian_email,

                    -- Medical History (NULL if none)
                    m.history_id,
                    m.allergies,
                    m.medical_conditions,
                    m.menstruation_details,
                    m.current_medications,
                    m.past_surgeries,
                    m.notes          AS medical_notes,

                    -- Total appointments
                    COUNT(DISTINCT a.appointment_id) AS total_appointments

                FROM patients_tb p
                LEFT JOIN patient_hmo_tb             h ON p.patient_id = h.patient_id
                LEFT JOIN patient_guardian_tb         g ON p.patient_id = g.patient_id
                LEFT JOIN patient_medical_history_tb  m ON p.patient_id = m.patient_id
                LEFT JOIN appointments_tb             a ON p.patient_id = a.patient_id
                WHERE p.patient_id = ?
                GROUP BY p.patient_id
                LIMIT 1
            ";

            $stmt = $this->conn->prepare($sql);

            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $this->conn->error);
            }

            $stmt->bind_param("i", $patientId);

            if (!$stmt->execute()) {
                throw new Exception("Failed to execute query: " . $stmt->error);
            }

            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                throw new Exception("Patient not found with ID: " . $patientId);
            }

            $row = $result->fetch_assoc();
            $stmt->close();

            return [
                'success' => true,
                'message' => 'Patient retrieved successfully',
                'data'    => $this->formatPatientData($row)
            ];
        }

        private function formatPatientData($row) {
            // Profile picture
            $profilePicture = null;
            if (!empty($row['profile_picture'])) {
                if (ctype_print($row['profile_picture']) && strpos($row['profile_picture'], '/') !== false) {
                    $profilePicture = $row['profile_picture'];
                } else {
                    $profilePicture = 'data:image/jpeg;base64,' . base64_encode($row['profile_picture']);
                }
            }

            // HMO block
            $hmo = null;
            if (!empty($row['hmo_id'])) {
                $hmo = [
                    'hmo_id'    => $row['hmo_id'],
                    'provider'  => $row['hmo_provider'],
                    'member_id' => $row['hmo_member_id'],
                    'is_valid'  => (bool)$row['hmo_is_valid'],
                    'notes'     => $row['hmo_notes']
                ];
            }

            // Guardian block
            $guardian = null;
            if (!empty($row['guardian_id'])) {
                $guardian = [
                    'guardian_id'  => $row['guardian_id'],
                    'name'         => $row['guardian_name'],
                    'contact'      => $row['guardian_contact'],
                    'relationship' => $row['relationship'],
                    'email'        => $row['guardian_email']
                ];
            }

            // Medical history block
            $medicalHistory = null;
            if (!empty($row['history_id'])) {
                $medicalHistory = [
                    'history_id'           => $row['history_id'],
                    'allergies'            => $row['allergies'],
                    'medical_conditions'   => $row['medical_conditions'],
                    'menstruation_details' => $row['menstruation_details'],
                    'current_medications'  => $row['current_medications'],
                    'past_surgeries'       => $row['past_surgeries'],
                    'notes'                => $row['medical_notes']
                ];
            }

            return [
                'patient_id'         => (int)$row['patient_id'],
                'patient_code'       => $row['patient_code'],
                'profile_picture'    => $profilePicture,
                'status'             => $row['status'],
                'created_at'         => $row['created_at'],
                'updated_at'         => $row['updated_at'],
                'total_appointments' => (int)$row['total_appointments'],

                'personal_info' => [
                    // ✅ FIX: first_name is stored as last name in DB, swapped here for correct display
                    'first_name'  => $row['last_name']  ?? '',
                    'last_name'   => $row['first_name'] ?? '',
                    'middle_name' => $row['middle_name'] ?? '',
                    'full_name'   => trim(($row['last_name'] ?? '') . ' ' . ($row['first_name'] ?? '')),
                    'birthdate'   => $row['birthdate']   ?? null,
                    'age'         => (int)$row['age'],
                    'gender'      => $row['gender']      ?? 'Not specified',
                    'phone'       => $row['phone']       ?? 'Not provided',
                    'email'       => $row['email']       ?? 'Not provided',
                    'address'     => $row['address']     ?? 'Not provided'
                ],

                'hmo'             => $hmo,
                'guardian'        => $guardian,
                'medical_history' => $medicalHistory
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $patientId = $_GET['patient_id'] ?? null;

        if (!$patientId) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Patient ID is required. Please provide patient_id parameter.'
            ]);
            exit();
        }

        $api    = new GetPatientByIdAPI($conn);
        $result = $api->getPatientById($patientId);

        http_response_code(200);
        echo json_encode($result);

    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed. Use GET request.']);
    }

} catch (Exception $e) {
    error_log("EXCEPTION [get-patient]: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>