<?php
/**
 * Get Single Assistant by ID API
 * Retrieves a specific assistant's complete information including schedule
 * 
 * Query Parameters:
 * - staff_profile_id (required): The Staff Profile ID of the assistant to retrieve
 * - assistant_id (backwards compatibility): Alternative parameter name for staff_profile_id
 * 
 * MATCHES: Frontdesk pattern - queries by role instead of using assistant_tb
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== GET ASSISTANT BY ID API CLASS ===================== */
    class GetAssistantByIdAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function getAssistantById($staffProfileId) {
            try {
                if (empty($staffProfileId)) {
                    throw new Exception("Staff Profile ID is required");
                }
                
                // Validate staff_profile_id is numeric
                if (!is_numeric($staffProfileId)) {
                    throw new Exception("Invalid staff profile ID format");
                }
                
                // Build query to get assistant details - Query by role instead of assistant_tb
                $sql = "SELECT 
                    sp.staff_profile_id,
                    sp.user_id,
                    sp.first_name,
                    sp.last_name,
                    sp.birthdate,
                    sp.gender,
                    sp.address,
                    sp.phone,
                    sp.created_at,
                    u.user_code,
                    u.username,
                    u.email,
                    u.profile_picture_path,
                    u.profile_picture,
                    r.role_name
                FROM Staff_Profile_tb sp
                INNER JOIN Users_tb u ON sp.user_id = u.user_id
                INNER JOIN Roles_tb r ON sp.role_id = r.role_id
                WHERE sp.staff_profile_id = ? AND r.role_name = 'Assistant'
                LIMIT 1";
                
                $stmt = $this->conn->prepare($sql);
                
                if (!$stmt) {
                    throw new Exception("Failed to prepare statement: " . $this->conn->error);
                }
                
                $stmt->bind_param("i", $staffProfileId);
                
                if (!$stmt->execute()) {
                    throw new Exception("Failed to execute query: " . $stmt->error);
                }
                
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    throw new Exception("Assistant staff not found with staff_profile_id: " . $staffProfileId);
                }
                
                $row = $result->fetch_assoc();
                $stmt->close();
                
                // Get schedule for this assistant
                $schedule = $this->getStaffSchedule($row['staff_profile_id']);
                
                // Format assistant data
                $assistantData = $this->formatAssistantData($row, $schedule);
                
                return [
                    'success' => true,
                    'message' => 'Assistant retrieved successfully',
                    'data' => $assistantData
                ];
                
            } catch (Exception $e) {
                throw new Exception("Failed to retrieve assistant: " . $e->getMessage());
            }
        }
        
        private function getStaffSchedule($staffProfileId) {
            try {
                $sql = "SELECT 
                    day_of_week,
                    start_time,
                    end_time,
                    is_working
                FROM Staff_Base_Schedule_tb
                WHERE staff_profile_id = ?
                ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')";
                
                $stmt = $this->conn->prepare($sql);
                
                if (!$stmt) {
                    // Return empty schedule if table doesn't exist or query fails
                    return [];
                }
                
                $stmt->bind_param("i", $staffProfileId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                $schedule = [];
                while ($row = $result->fetch_assoc()) {
                    $schedule[] = [
                        'day' => $row['day_of_week'],
                        'start_time' => $row['start_time'],
                        'end_time' => $row['end_time'],
                        'is_working' => (bool)$row['is_working']
                    ];
                }
                
                $stmt->close();
                return $schedule;
                
            } catch (Exception $e) {
                // Return empty schedule if error
                return [];
            }
        }
        
        private function formatAssistantData($row, $schedule = []) {
            // Handle profile picture
            $profilePicture = null;
            
            // Check if it's a special flag or regular path
            if (!empty($row['profile_picture_path'])) {
                if ($row['profile_picture_path'] === 'generated_default' || 
                    $row['profile_picture_path'] === 'custom_upload') {
                    // Use blob data
                    if (!empty($row['profile_picture'])) {
                        $profilePicture = 'data:image/png;base64,' . base64_encode($row['profile_picture']);
                    }
                } else {
                    // Use file path
                    $profilePicture = $row['profile_picture_path'];
                }
            } elseif (!empty($row['profile_picture'])) {
                $profilePicture = 'data:image/png;base64,' . base64_encode($row['profile_picture']);
            }
            
            // Generate assistant code from user_code
            $assistantCode = !empty($row['user_code']) ? $row['user_code'] : 'AST-' . str_pad($row['staff_profile_id'], 4, '0', STR_PAD_LEFT);
            
            // Extract shift from schedule (MORNING/AFTERNOON/EVENING based on start time)
            $shift = null;
            if (!empty($schedule)) {
                $firstWorkingDay = array_filter($schedule, fn($s) => $s['is_working']);
                if (!empty($firstWorkingDay)) {
                    $firstDay = reset($firstWorkingDay);
                    $startHour = (int)substr($firstDay['start_time'], 0, 2);
                    
                    if ($startHour < 12) {
                        $shift = 'MORNING';
                    } elseif ($startHour < 17) {
                        $shift = 'AFTERNOON';
                    } else {
                        $shift = 'EVENING';
                    }
                }
            }
            
            return [
                'staff_profile_id' => (int)$row['staff_profile_id'],
                'assistant_code' => $assistantCode,
                'user_id' => (int)$row['user_id'],
                'personal_info' => [
                    'first_name' => $row['first_name'] ?? '',
                    'last_name' => $row['last_name'] ?? '',
                    'full_name' => trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')),
                    'birthdate' => $row['birthdate'] ?? null,
                    'gender' => $row['gender'] ?? 'Not specified',
                    'address' => $row['address'] ?? 'Not provided',
                    'phone' => $row['phone'] ?? 'Not provided',
                    'email' => $row['email'] ?? 'Not provided'
                ],
                'work_info' => [
                    'shift' => $shift,
                    'schedule' => $schedule
                ],
                'profile_picture' => $profilePicture,
                'username' => $row['username'] ?? '',
                'role_name' => $row['role_name'] ?? 'Assistant',
                'created_at' => $row['created_at'] ?? null
            ];
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Get staff_profile_id from query parameters (can also accept assistant_id for backwards compatibility)
        $staffProfileId = $_GET['staff_profile_id'] ?? $_GET['assistant_id'] ?? null;
        
        if (!$staffProfileId) {
            http_response_code(400);
            echo json_encode([
                'success' => false, 
                'message' => 'Staff Profile ID is required. Please provide staff_profile_id parameter.'
            ]);
            exit();
        }
        
        $api = new GetAssistantByIdAPI($conn);
        $result = $api->getAssistantById($staffProfileId);
        
        http_response_code(200);
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed. Use GET request.']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server error: ' . $e->getMessage()
    ]);
}

exit;
?>