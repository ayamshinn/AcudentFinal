<?php
/**
 * Add Assistant Record API
 * Creates assistant staff records for existing user accounts
 */

error_reporting(0);
ini_set('display_errors', 0);

header("Content-Type: application/json");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    /* ===================== DATABASE CONNECTION ===================== */
    $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
    if (!file_exists($dbPath)) {
        throw new Exception("Database connection file not found");
    }
    require_once $dbPath;

    if (!isset($conn)) {
        throw new Exception("Database connection not established");
    }

    /* ===================== ASSISTANT RECORD API CLASS ===================== */
    class AssistantRecordAPI {
        private $conn;
        
        public function __construct($db) {
            $this->conn = $db;
        }
        
        public function addAssistantRecord($data) {
            try {
                $this->conn->begin_transaction();
                
                $this->validateAssistantInfo($data);
                $userData = $this->getUserData($data['user_id']);
                $roleId = $this->getAssistantRoleId();
                
                $staffProfileId = $this->getOrCreateStaffProfile(
                    $data['user_id'],
                    $roleId,
                    $userData,
                    $data
                );
                
                // Create assistant-specific record in assistants_tb if needed
                $this->createOrUpdateAssistantRecord($staffProfileId, $data);
                
                // Create work schedule if provided
                if (!empty($data['workingDays']) && is_array($data['workingDays'])) {
                    $this->createWorkSchedule($staffProfileId, $data);
                }
                
                $this->conn->commit();
                
                return [
                    'success' => true,
                    'message' => 'Assistant record created successfully',
                    'data' => [
                        'user_id' => $data['user_id'],
                        'staff_profile_id' => $staffProfileId
                    ]
                ];
                
            } catch (Exception $e) {
                $this->conn->rollback();
                return [
                    'success' => false,
                    'message' => $e->getMessage()
                ];
            }
        }
        
        private function validateAssistantInfo($data) {
            if (empty($data['user_id'])) {
                throw new Exception("User ID is required");
            }
            
            // Required fields
            $required = [
                'firstName' => 'First name',
                'lastName' => 'Last name',
                'dateOfBirth' => 'Date of birth',
                'gender' => 'Gender'
            ];
            
            foreach ($required as $field => $label) {
                if (empty($data[$field] ?? '')) {
                    throw new Exception("$label is required");
                }
            }
            
            // Check if staff profile already exists
            $stmt = $this->conn->prepare("
                SELECT sp.staff_profile_id 
                FROM staff_profile_tb sp
                WHERE sp.user_id = ? 
                LIMIT 1
            ");
            $stmt->bind_param("i", $data['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                throw new Exception("This user already has a staff record");
            }
            $stmt->close();
            
            if (!empty($data['phone']) && !preg_match('/^\+?[0-9\s\-()]+$/', $data['phone'])) {
                throw new Exception("Invalid phone number format");
            }
            
            if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email format");
            }
        }
        
        private function getUserData($userId) {
            $stmt = $this->conn->prepare("
                SELECT user_id, first_name, last_name, email 
                FROM users_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("User account not found");
            }
            
            $userData = $result->fetch_assoc();
            $stmt->close();
            return $userData;
        }
        
        private function getAssistantRoleId() {
            $stmt = $this->conn->prepare("SELECT role_id FROM roles_tb WHERE role_name = 'Assistant' LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                throw new Exception("Assistant role not found in system");
            }
            
            $row = $result->fetch_assoc();
            $stmt->close();
            return $row['role_id'];
        }
        
        private function getOrCreateStaffProfile($userId, $roleId, $userData, $data) {
            $stmt = $this->conn->prepare("
                SELECT staff_profile_id 
                FROM staff_profile_tb 
                WHERE user_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $staffProfileId = $row['staff_profile_id'];
                $stmt->close();
                
                $this->updateStaffProfile($staffProfileId, $data);
                return $staffProfileId;
            }
            $stmt->close();
            
            return $this->createStaffProfile($userId, $roleId, $data);
        }
        
        private function updateStaffProfile($staffProfileId, $data) {
            $updateFields = [];
            $params = [];
            $types = '';
            
            if (!empty($data['firstName'])) {
                $updateFields[] = "first_name = ?";
                $params[] = $data['firstName'];
                $types .= 's';
            }
            
            if (!empty($data['lastName'])) {
                $updateFields[] = "last_name = ?";
                $params[] = $data['lastName'];
                $types .= 's';
            }
            
            if (!empty($data['dateOfBirth'])) {
                $updateFields[] = "birthdate = ?";
                $params[] = $data['dateOfBirth'];
                $types .= 's';
            }
            
            if (!empty($data['gender'])) {
                $updateFields[] = "gender = ?";
                $params[] = $data['gender'];
                $types .= 's';
            }
            
            if (!empty($data['address'])) {
                $updateFields[] = "address = ?";
                $params[] = $data['address'];
                $types .= 's';
            }
            
            if (!empty($data['phone'])) {
                $updateFields[] = "phone = ?";
                $params[] = $data['phone'];
                $types .= 's';
            }
            
            if (!empty($updateFields)) {
                $updateFields[] = "updated_at = NOW()";
                $params[] = $staffProfileId;
                $types .= 'i';
                
                $sql = "UPDATE staff_profile_tb SET " . implode(', ', $updateFields) . " WHERE staff_profile_id = ?";
                $stmt = $this->conn->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();
            }
        }
        
        private function createStaffProfile($userId, $roleId, $data) {
            $stmt = $this->conn->prepare("
                INSERT INTO staff_profile_tb (
                    user_id, role_id, first_name, last_name, 
                    birthdate, gender, address, phone, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $firstName = $data['firstName'];
            $lastName = $data['lastName'];
            $birthdate = $data['dateOfBirth'];
            $gender = $data['gender'];
            $address = $data['address'] ?? '';
            $phone = $data['phone'] ?? '';
            
            $stmt->bind_param(
                "iissssss",
                $userId,
                $roleId,
                $firstName,
                $lastName,
                $birthdate,
                $gender,
                $address,
                $phone
            );
            
            if (!$stmt->execute()) {
                throw new Exception("Failed to create staff profile: " . $stmt->error);
            }
            
            $staffProfileId = $this->conn->insert_id;
            $stmt->close();
            return $staffProfileId;
        }
        
        private function createOrUpdateAssistantRecord($staffProfileId, $data) {
            // Check if assistant record exists
            $stmt = $this->conn->prepare("
                SELECT assistant_id 
                FROM assistants_tb 
                WHERE staff_profile_id = ? LIMIT 1
            ");
            $stmt->bind_param("i", $staffProfileId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing record
                $row = $result->fetch_assoc();
                $assistantId = $row['assistant_id'];
                $stmt->close();
                
                $updateStmt = $this->conn->prepare("
                    UPDATE assistants_tb 
                    SET certification = ?
                    WHERE assistant_id = ?
                ");
                
                $certification = $data['certification'] ?? null;
                
                $updateStmt->bind_param("si", $certification, $assistantId);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                // Create new record
                $stmt->close();
                
                $insertStmt = $this->conn->prepare("
                    INSERT INTO assistants_tb (
                        staff_profile_id, certification, auto_follow_dentist
                    ) VALUES (?, ?, 1)
                ");
                
                $certification = $data['certification'] ?? null;
                
                $insertStmt->bind_param("is", $staffProfileId, $certification);
                
                if (!$insertStmt->execute()) {
                    throw new Exception("Failed to create assistant record: " . $insertStmt->error);
                }
                
                $insertStmt->close();
            }
        }
        
        private function createWorkSchedule($staffProfileId, $data) {
            $dayMapping = [
                'Monday' => 'Mon',
                'Tuesday' => 'Tue',
                'Wednesday' => 'Wed',
                'Thursday' => 'Thu',
                'Friday' => 'Fri',
                'Saturday' => 'Sat',
                'Sunday' => 'Sun'
            ];
            
            $startTime = !empty($data['startTime']) ? $data['startTime'] : '09:00:00';
            $endTime = !empty($data['endTime']) ? $data['endTime'] : '17:00:00';
            
            if (strlen($startTime) === 5) {
                $startTime .= ':00';
            }
            if (strlen($endTime) === 5) {
                $endTime .= ':00';
            }
            
            $deleteStmt = $this->conn->prepare("DELETE FROM staff_base_schedule_tb WHERE staff_profile_id = ?");
            $deleteStmt->bind_param("i", $staffProfileId);
            $deleteStmt->execute();
            $deleteStmt->close();
            
            $stmt = $this->conn->prepare("
                INSERT INTO staff_base_schedule_tb 
                (staff_profile_id, day_of_week, start_time, end_time, is_working) 
                VALUES (?, ?, ?, ?, 1)
            ");
            
            foreach ($data['workingDays'] as $day) {
                if (isset($dayMapping[$day])) {
                    $dbDay = $dayMapping[$day];
                    $stmt->bind_param("isss", $staffProfileId, $dbDay, $startTime, $endTime);
                    
                    if (!$stmt->execute()) {
                        throw new Exception("Failed to create schedule for $day: " . $stmt->error);
                    }
                }
            }
            
            $stmt->close();
        }
    }

    /* ===================== MAIN EXECUTION ===================== */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
            exit;
        }
        
        $api = new AssistantRecordAPI($conn);
        $result = $api->addAssistantRecord($input);
        
        echo json_encode($result);
        
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

exit;
?>